<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SBTE Bihar Hostel Management System</title>
    <meta name="description" content="Official hostel management portal for State Board of Technical Education, Bihar">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>
        :root {
            --navy-blue: #1e3a8a;
            --dark-navy: #0f172a;
            --gold: #f59e0b;
            --light-blue: #dbeafe;
            --white: #ffffff;
            --gray-light: #f1f5f9;
            --gray: #cbd5e1;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            line-height: 1.6;
            color: #1f2937;
            overflow-x: hidden;
        }

        .navbar {
            position: fixed;
            top: 0;
            width: 100%;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            padding: 1rem 0;
        }

        .navbar-container {
            max-width: 1280px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar-brand {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            text-decoration: none;
        }

        .logo-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--navy-blue), var(--gold));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            font-weight: 900;
            box-shadow: 0 4px 15px rgba(30, 58, 138, 0.3);
        }

        .navbar-brand-text .main {
            font-size: 1.4rem;
            font-weight: 900;
            color: var(--navy-blue);
            letter-spacing: -0.5px;
        }

        .navbar-brand-text .sub {
            font-size: 0.75rem;
            color: #64748b;
            font-weight: 600;
            text-transform: uppercase;
        }

        .navbar-menu {
            display: flex;
            list-style: none;
            gap: 2.5rem;
            align-items: center;
        }

        .navbar-link {
            text-decoration: none;
            color: #374151;
            font-weight: 600;
            transition: all 0.3s;
        }

        .navbar-link:hover {
            color: var(--navy-blue);
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--navy-blue), var(--gold));
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 700;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(30, 58, 138, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(30, 58, 138, 0.4);
        }

        /* Hero Section */
        .hero-section {
            min-height: 100vh;
            background: linear-gradient(135deg, var(--dark-navy) 0%, var(--navy-blue) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            padding-top: 80px;
            position: relative;
            overflow: hidden;
        }

        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-image: radial-gradient(circle at 20% 50%, rgba(255, 255, 255, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 80%, rgba(245, 158, 11, 0.1) 0%, transparent 50%);
        }

        .hero-content {
            text-align: center;
            color: white;
            z-index: 10;
            max-width: 1100px;
            padding: 4rem 2rem;
            position: relative;
        }

        .hero-logo {
            margin-bottom: 2rem;
        }

        .hero-title {
            font-size: clamp(2.5rem, 8vw, 5rem);
            font-weight: 900;
            margin-bottom: 1.5rem;
            line-height: 1.1;
            color: var(--white);
            text-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }

        .hero-subtitle {
            font-size: clamp(1.2rem, 2.5vw, 1.6rem);
            margin-bottom: 1rem;
            line-height: 1.6;
            font-weight: 600;
            color: var(--gray-light);
        }

        .hero-tagline {
            font-size: clamp(1rem, 2vw, 1.25rem);
            margin-bottom: 3rem;
            line-height: 1.7;
            font-weight: 500;
            color: var(--gray);
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }

        .hero-buttons {
            display: flex;
            gap: 1.5rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .hero-btn {
            padding: 1.2rem 2.5rem;
            font-size: 1.1rem;
            font-weight: 700;
            border-radius: 50px;
            text-decoration: none;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .hero-btn-primary {
            background: white;
            color: var(--navy-blue);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        .hero-btn-primary:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
        }

        .hero-btn-secondary {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border: 2px solid white;
            backdrop-filter: blur(10px);
        }

        .hero-btn-secondary:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-4px);
        }

        /* Features Section */
        .features-section {
            padding: 6rem 2rem;
            background: linear-gradient(135deg, #f8fafc 0%, var(--light-blue) 100%);
        }

        .section-header {
            text-align: center;
            margin-bottom: 4rem;
        }

        .section-subtitle {
            color: var(--gold);
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }

        .section-title {
            font-size: clamp(2rem, 5vw, 3.5rem);
            font-weight: 900;
            color: var(--navy-blue);
            margin-bottom: 1rem;
        }

        .section-description {
            font-size: 1.2rem;
            color: #64748b;
            max-width: 700px;
            margin: 0 auto;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            max-width: 1280px;
            margin: 0 auto;
        }

        .feature-card {
            background: white;
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            transition: all 0.3s;
            border-top: 4px solid var(--navy-blue);
        }

        .feature-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.12);
        }

        .feature-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--navy-blue), var(--gold));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            margin-bottom: 1.5rem;
        }

        .feature-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--navy-blue);
            margin-bottom: 1rem;
        }

        .feature-description {
            color: #64748b;
            line-height: 1.7;
        }

        /* Footer */
        .footer {
            background: var(--dark-navy);
            color: white;
            padding: 3rem 2rem 2rem;
            text-align: center;
        }

        .footer-content {
            max-width: 1280px;
            margin: 0 auto;
        }

        .footer-text {
            opacity: 0.9;
            margin-bottom: 1rem;
        }

        @media (max-width: 768px) {
            .navbar-menu {
                display: none;
            }

            .hero-buttons {
                flex-direction: column;
                align-items: center;
            }

            .features-grid {
                grid-template-columns: 1fr;
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .hero-content>* {
            animation: fadeIn 0.8s ease-out backwards;
        }

        .hero-title {
            animation-delay: 0.2s;
        }

        .hero-subtitle {
            animation-delay: 0.4s;
        }

        .hero-tagline {
            animation-delay: 0.6s;
        }

        .hero-buttons {
            animation-delay: 0.8s;
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="navbar-container">
            <a href="#" class="navbar-brand">
                <div class="logo-icon">S</div>
                <div class="navbar-brand-text">
                    <div class="main">SBTE Hostel</div>
                    <div class="sub">Management System</div>
                </div>
            </a>
            <ul class="navbar-menu">
                <li><a href="#features" class="navbar-link">Features</a></li>
                <li><a href="#about" class="navbar-link">About</a></li>
                <li><a href="login.php" class="btn-primary">Student Login</a></li>
                <li><a href="admin-login.php" class="btn-primary">Admin Login</a></li>
            </ul>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="hero-content">
            <div class="hero-logo">
                <div class="logo-icon" style="width: 100px; height: 100px; font-size: 48px; margin: 0 auto;">S</div>
            </div>
            <h1 class="hero-title">State Board of Technical Education, Bihar</h1>
            <p class="hero-subtitle">Hostel Management System</p>
            <p class="hero-tagline">Complete digital transformation for polytechnic hostel administration. Streamline operations, enhance student experience, and boost efficiency.</p>
            <div class="hero-buttons">
                <a href="register.php" class="hero-btn hero-btn-primary">
                    📝 Register as Student
                </a>
                <a href="login.php" class="hero-btn hero-btn-secondary">
                    🔑 Login Portal
                </a>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features-section" id="features">
        <div class="section-header">
            <div class="section-subtitle">Why Choose Us</div>
            <h2 class="section-title">Comprehensive Hostel Management</h2>
            <p class="section-description">Modern, efficient, and user-friendly platform designed specifically for SBTE Bihar polytechnic hostels</p>
        </div>

        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">🏠</div>
                <h3 class="feature-title">Room Management</h3>
                <p class="feature-description">Easy room allocation, swapping, and tracking. Real-time availability updates and smart assignment algorithms.</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">💰</div>
                <h3 class="feature-title">Fee Management</h3>
                <p class="feature-description">Transparent fee structure, online payment integration, and automated receipt generation for hassle-free transactions.</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">📋</div>
                <h3 class="feature-title">Complaint System</h3>
                <p class="feature-description">Quick complaint registration and tracking. Efficient resolution workflow with status notifications.</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">👥</div>
                <h3 class="feature-title">Student Portal</h3>
                <p class="feature-description">Personalized dashboard for students to manage their hostel journey, view announcements, and access services.</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">📊</div>
                <h3 class="feature-title">Admin Dashboard</h3>
                <p class="feature-description">Powerful analytics and reporting tools for administrators to make data-driven decisions.</p>
            </div>

            <div class="feature-card">
                <div class="feature-icon">🔔</div>
                <h3 class="feature-title">Announcements</h3>
                <p class="feature-description">Instant communication channel for important updates, events, and notices to all residents.</p>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <p class="footer-text">© 2024 State Board of Technical Education, Bihar. All rights reserved.</p>
            <p class="footer-text">Official Hostel Management System - Government of Bihar</p>
        </div>
    </footer>
</body>

</html>
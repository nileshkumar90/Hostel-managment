-- ═══════════════════════════════════════════════════════════════
-- SBTE Bihar Hostel Management System - Complete Database Setup
-- Version: 1.0 Final
-- ═══════════════════════════════════════════════════════════════

DROP DATABASE IF EXISTS hostelmanagement;
CREATE DATABASE hostelmanagement CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hostelmanagement;

-- ═══════════════════════════════════════════════════════════════
-- TABLE: admin
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ═══════════════════════════════════════════════════════════════
-- TABLE: rooms
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) NOT NULL,
    block VARCHAR(10) NOT NULL,
    floor INT NOT NULL,
    capacity INT NOT NULL DEFAULT 2,
    occupied INT NOT NULL DEFAULT 0,
    fees DECIMAL(10,2) NOT NULL,
    room_type VARCHAR(50) DEFAULT 'Standard',
    facilities TEXT,
    status ENUM('Available', 'Occupied', 'Maintenance', 'Reserved') DEFAULT 'Available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ═══════════════════════════════════════════════════════════════
-- TABLE: students
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    roll_number VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(15),
    branch VARCHAR(100),
    year INT,
    semester INT,
    father_name VARCHAR(100),
    mother_name VARCHAR(100),
    parents_phone VARCHAR(15),
    aadhaar_no VARCHAR(12),
    apar_id VARCHAR(50),
    address TEXT,
    room_id INT NULL,
    blood_group VARCHAR(5),
    guardian_name VARCHAR(100),
    guardian_contact VARCHAR(15),
    emergency_contact VARCHAR(15),
    profile_image VARCHAR(255) DEFAULT NULL,
    is_active TINYINT DEFAULT 1,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    pending_room_id INT NULL,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE SET NULL,
    FOREIGN KEY (pending_room_id) REFERENCES rooms(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ═══════════════════════════════════════════════════════════════
-- TABLE: fees
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE fees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    fee_type VARCHAR(50) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    paid_amount DECIMAL(10,2) DEFAULT 0,
    due_date DATE NOT NULL,
    status ENUM('Pending', 'Paid', 'Overdue') DEFAULT 'Pending',
    payment_date DATETIME NULL,
    payment_method VARCHAR(50) NULL,
    transaction_id VARCHAR(100) NULL,
    receipt_number VARCHAR(50) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ═══════════════════════════════════════════════════════════════
-- TABLE: complaints
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE complaints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    subject VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(50),
    priority ENUM('Low', 'Medium', 'High', 'Urgent') DEFAULT 'Medium',
    status ENUM('Pending', 'In Progress', 'Resolved', 'Closed') DEFAULT 'Pending',
    admin_response TEXT NULL,
    admin_notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL,
    resolved_at TIMESTAMP NULL,
    resolved_by INT NULL,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ═══════════════════════════════════════════════════════════════
-- TABLE: announcements
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    category VARCHAR(50),
    priority ENUM('Low', 'Medium', 'High') DEFAULT 'Medium',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active TINYINT DEFAULT 1,
    FOREIGN KEY (created_by) REFERENCES admin(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ═══════════════════════════════════════════════════════════════
-- TABLE: mess_menu
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE mess_menu (
    id INT AUTO_INCREMENT PRIMARY KEY,
    day_of_week VARCHAR(20) NOT NULL,
    meal_type ENUM('Breakfast', 'Lunch', 'Dinner') NOT NULL,
    menu_items TEXT NOT NULL,
    is_active TINYINT DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ═══════════════════════════════════════════════════════════════
-- TABLE: maintenance_requests
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE maintenance_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    room_id INT DEFAULT NULL,
    category VARCHAR(50) NOT NULL,
    priority ENUM('Low', 'Medium', 'High', 'Urgent') DEFAULT 'Medium',
    description TEXT NOT NULL,
    status ENUM('Pending', 'In Progress', 'Completed', 'Cancelled') DEFAULT 'Pending',
    admin_notes TEXT DEFAULT NULL,
    assigned_to VARCHAR(100) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL DEFAULT NULL,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE SET NULL,
    INDEX idx_student (student_id),
    INDEX idx_status (status),
    INDEX idx_priority (priority),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ═══════════════════════════════════════════════════════════════
-- TABLE: visitors
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE visitors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    visitor_name VARCHAR(100) NOT NULL,
    visitor_phone VARCHAR(15),
    relation VARCHAR(50),
    visit_date DATE NOT NULL,
    in_time TIME NOT NULL,
    out_time TIME NULL,
    purpose TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ═══════════════════════════════════════════════════════════════
-- INSERT DEFAULT DATA
-- ═══════════════════════════════════════════════════════════════

-- Default Admin (password: student123)
INSERT INTO admin (username, email, password) VALUES 
('admin', 'admin@sbte.bihar.gov.in', '$2y$10$4xnRApQPzRYZj3uw7VI5De/R7IzCztmlihoSXGQO4ID6HGkKphYfm');

-- Sample Rooms (100 rooms across 4 blocks)
INSERT INTO rooms (room_number, block, floor, capacity, fees, room_type, facilities, status) VALUES
-- Block A - Single Rooms (25 rooms)
('101', 'A', 1, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('102', 'A', 1, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('103', 'A', 1, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('104', 'A', 1, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('105', 'A', 1, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('201', 'A', 2, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('202', 'A', 2, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('203', 'A', 2, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('204', 'A', 2, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('205', 'A', 2, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('301', 'A', 3, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('302', 'A', 3, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('303', 'A', 3, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('304', 'A', 3, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('305', 'A', 3, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('401', 'A', 4, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('402', 'A', 4, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('403', 'A', 4, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('404', 'A', 4, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('405', 'A', 4, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('501', 'A', 5, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('502', 'A', 5, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('503', 'A', 5, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('504', 'A', 5, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('505', 'A', 5, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),

-- Block B - Double Rooms (25 rooms)  
('101', 'B', 1, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('102', 'B', 1, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('103', 'B', 1, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('104', 'B', 1, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('105', 'B', 1, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('201', 'B', 2, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('202', 'B', 2, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('203', 'B', 2, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('204', 'B', 2, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('205', 'B', 2, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('301', 'B', 3, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('302', 'B', 3, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('303', 'B', 3, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('304', 'B', 3, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('305', 'B', 3, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('401', 'B', 4, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('402', 'B', 4, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('403', 'B', 4, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('404', 'B', 4, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('405', 'B', 4, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('501', 'B', 5, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('502', 'B', 5, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('503', 'B', 5, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('504', 'B', 5, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('505', 'B', 5, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),

-- Block C - Single Rooms (25 rooms)
('101', 'C', 1, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('102', 'C', 1, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('103', 'C', 1, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('104', 'C', 1, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('105', 'C', 1, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('201', 'C', 2, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('202', 'C', 2, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('203', 'C', 2, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('204', 'C', 2, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('205', 'C', 2, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('301', 'C', 3, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('302', 'C', 3, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('303', 'C', 3, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('304', 'C', 3, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('305', 'C', 3, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('401', 'C', 4, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('402', 'C', 4, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('403', 'C', 4, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('404', 'C', 4, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('405', 'C', 4, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('501', 'C', 5, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('502', 'C', 5, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('503', 'C', 5, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('504', 'C', 5, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),
('505', 'C', 5, 1, 10000, 'Single', 'Bed, Study Table, Cupboard, WiFi', 'Available'),

-- Block D - Double Rooms (25 rooms)
('101', 'D', 1, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('102', 'D', 1, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('103', 'D', 1, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('104', 'D', 1, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('105', 'D', 1, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('201', 'D', 2, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('202', 'D', 2, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('203', 'D', 2, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('204', 'D', 2, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('205', 'D', 2, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('301', 'D', 3, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('302', 'D', 3, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('303', 'D', 3, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('304', 'D', 3, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('305', 'D', 3, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('401', 'D', 4, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('402', 'D', 4, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('403', 'D', 4, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('404', 'D', 4, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('405', 'D', 4, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('501', 'D', 5, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('502', 'D', 5, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('503', 'D', 5, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('504', 'D', 5, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available'),
('505', 'D', 5, 2, 12000, 'Double', 'Beds, Study Tables, Cupboards, WiFi', 'Available');

-- Test Students (password: student123)
INSERT INTO students (name, roll_number, phone, branch, email, father_name, mother_name, aadhaar_no, parents_phone, address, password, year, semester, is_active, room_id) VALUES
('Rahul Kumar (Test)', 'TEST2024001', '9876543210', 'Computer Science Engineering', 'test.student@example.com', 'Rajesh Kumar', 'Sunita Kumar', '123456789012', '9876543211', '123 Main Street, Model Town, New Delhi - 110001', '$2y$10$4xnRApQPzRYZj3uw7VI5De/R7IzCztmlihoSXGQO4ID6HGkKphYfm', 1, 1, 1, 1),
('Priya Sharma', 'TEST2024002', '9876543220', 'Electronics Engineering', 'priya.sharma@example.com', 'Suresh Sharma', 'Rani Sharma', '234567890123', '9876543221', '456 Park Avenue, Saket, New Delhi - 110017', '$2y$10$4xnRApQPzRYZj3uw7VI5De/R7IzCztmlihoSXGQO4ID6HGkKphYfm', 2, 3, 1, 26);

-- Update room occupancy
UPDATE rooms SET occupied = 1 WHERE id = 1;
UPDATE rooms SET occupied = 1 WHERE id = 26;

-- Sample Fees
INSERT INTO fees (student_id, fee_type, amount, paid_amount, due_date, status, payment_date, payment_method, transaction_id, receipt_number) VALUES
(1, 'Hostel', 12000, 12000, '2025-12-21', 'Paid', '2025-11-20', 'UPI', '44444444', 'REC-69203B0C00B5C'),
(1, 'Hostel', 10000, 0, '2026-01-21', 'Pending', NULL, NULL, NULL, NULL),
(1, 'Hostel', 10000, 0, '2026-01-21', 'Pending', NULL, NULL, NULL, NULL),
(1, 'Maintenance', 100, 100, '2025-11-21', 'Paid', '2025-11-21', 'UPI', '11111111', NULL),
(1, 'Maintenance', 100, 0, '2025-12-21', 'Pending', NULL, NULL, NULL, NULL),
(2, 'Hostel', 10000, 10000, '2025-12-21', 'Paid', '2025-11-21', 'UPI', '44444444', 'REC-TEST002');

-- Sample Maintenance Requests
INSERT INTO maintenance_requests (student_id, room_id, category, priority, description, status, created_at) VALUES
(1, 1, 'Electrical', 'High', 'Fan not working properly', 'Pending', '2025-11-24 10:00:00'),
(2, 26, 'Plumbing', 'Medium', 'Tap leaking in bathroom', 'In Progress', '2025-11-23 15:30:00');

-- Sample Mess Menu
INSERT INTO mess_menu (day_of_week, meal_type, menu_items, is_active) VALUES
-- Monday
('Monday', 'Breakfast', 'Poha, Jalebi, Tea/Coffee, Milk', 1),
('Monday', 'Lunch', 'Rice, Arhar Dal, Roti, Aloo Gobhi, Curd, Salad', 1),
('Monday', 'Snacks', 'Tea, Biscuits, Samosa', 1),
('Monday', 'Dinner', 'Rice, Mix Veg, Roti, Dal Fry, Kheer', 1),

-- Tuesday
('Tuesday', 'Breakfast', 'Idli, Sambhar, Coconut Chutney, Tea/Coffee', 1),
('Tuesday', 'Lunch', 'Rice, Masoor Dal, Roti, Bhindi Fry, Papad', 1),
('Tuesday', 'Snacks', 'Tea, Bread Pakora', 1),
('Tuesday', 'Dinner', 'Rice, Egg Curry/Paneer Butter Masala, Roti, Salad', 1),

-- Wednesday
('Wednesday', 'Breakfast', 'Aloo Paratha, Curd, Pickle, Tea/Coffee', 1),
('Wednesday', 'Lunch', 'Rice, Rajma, Roti, Jeera Aloo, Raita', 1),
('Wednesday', 'Snacks', 'Tea, Veg Puff', 1),
('Wednesday', 'Dinner', 'Veg Pulao, Dal Makhani, Naan, Gulab Jamun', 1),

-- Thursday
('Thursday', 'Breakfast', 'Sandwich, Boiled Egg/Banana, Tea/Coffee', 1),
('Thursday', 'Lunch', 'Rice, Kadhi Pakora, Roti, Aloo Methi, Salad', 1),
('Thursday', 'Snacks', 'Tea, Chowmein', 1),
('Thursday', 'Dinner', 'Rice, Chana Dal, Roti, Kofta Curry, Sevai', 1),

-- Friday
('Friday', 'Breakfast', 'Puri, Aloo Sabji, Tea/Coffee', 1),
('Friday', 'Lunch', 'Rice, Moong Dal, Roti, Seasonal Veg, Buttermilk', 1),
('Friday', 'Snacks', 'Tea, Maggi', 1),
('Friday', 'Dinner', 'Biryani (Veg/Chicken), Raita, Salad, Sweet', 1),

-- Saturday
('Saturday', 'Breakfast', 'Dosa, Sambhar, Chutney, Tea/Coffee', 1),
('Saturday', 'Lunch', 'Khichdi, Chokha, Papad, Pickle, Curd', 1),
('Saturday', 'Snacks', 'Tea, Pasta', 1),
('Saturday', 'Dinner', 'Rice, Dal Tadka, Roti, Matar Paneer, Halwa', 1),

-- Sunday
('Sunday', 'Breakfast', 'Chole Bhature, Lassi/Tea', 1),
('Sunday', 'Lunch', 'Special Thali: Pulao, Dal, Paneer, Naan, Sweet, Papad', 1),
('Sunday', 'Snacks', 'Tea, Cake/Pastry', 1),
('Sunday', 'Dinner', 'Fried Rice, Manchurian, Soup, Noodles', 1);

-- Sample Announcements
INSERT INTO announcements (title, content, category, priority, created_by) VALUES
('Welcome to New Session', 'Welcome to all new and existing students! We wish you a great academic year ahead.', 'General', 'High', 1),
('Hostel Timings Updated', 'Please note that hostel gate timings have been updated. Entry closes at 10:00 PM on weekdays.', 'General', 'High', 1);

-- ═══════════════════════════════════════════════════════════════
-- TABLE: developer_info
-- ═══════════════════════════════════════════════════════════════
CREATE TABLE developer_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(50),
    role VARCHAR(100) DEFAULT 'Full Stack Developer',
    github_url VARCHAR(255),
    linkedin_url VARCHAR(255),
    portfolio_url VARCHAR(255),
    bio TEXT,
    photo VARCHAR(255),
    is_active TINYINT(1) DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default Developer Info
INSERT INTO developer_info (name, role, email, phone, linkedin_url, github_url, portfolio_url, bio, photo) VALUES
('Your Name', 'Full Stack Web Developer', 'developer@example.com', '+91-XXXXXXXXXX', 'https://linkedin.com/in/yourprofile', 'https://github.com/yourprofile', 'https://yourportfolio.com', 'Passionate full-stack developer specializing in web applications. Created this Hostel Management System for SBTE Bihar.', NULL);

-- ═══════════════════════════════════════════════════════════════
-- SETUP COMPLETE
--  ══════════════════════════════════════════════════════════════

SELECT 'Database setup complete!' as Status,
       (SELECT COUNT(*) FROM rooms) as Total_Rooms,
       (SELECT COUNT(*) FROM students) as Total_Students,
       (SELECT COUNT(*) FROM fees) as Total_Fees;
       
-- ═══════════════════════════════════════════════════════════════
-- LOGIN CREDENTIALS
-- ═══════════════════════════════════════════════════════════════
-- ADMIN: username = admin, password = student123
-- STUDENT 1: email = test.student@example.com, password = student123
-- STUDENT 2: email = priya.sharma@example.com, password = student123
-- ═══════════════════════════════════════════════════════════════

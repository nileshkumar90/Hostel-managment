<?php
require_once 'includes/config.php';
$result = $conn->query("DESCRIBE developer_info");
while ($row = $result->fetch_assoc()) {
    echo $row['Field'] . " - " . $row['Type'] . " - Null: " . $row['Null'] . "\n";
}

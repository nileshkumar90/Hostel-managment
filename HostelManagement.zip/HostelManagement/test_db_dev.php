<?php
require_once 'includes/config.php';

echo "Checking developer_info table...\n";

$result = $conn->query("SELECT * FROM developer_info ORDER BY id DESC");

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"] . " - Name: " . $row["name"] . " - Role: " . $row["role"] . " - Active: " . $row["is_active"] . "\n";
    }
} else {
    echo "0 results";
}

$conn->close();

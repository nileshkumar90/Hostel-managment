<?php
// Quick test to see registration error
require_once 'includes/config.php';

echo "<h2>Testing Registration Issue</h2>";

// Test data
$test_data = [
    'name' => 'Test Student',
    'roll_number' => 'TEST123',
    'phone' => '9876543210',
    'branch' => 'Computer Science',
    'email' => 'test' . time() . '@example.com',
    'father_name' => 'Test Father',
    'aadhaar_no' => '123456789012',
    'apar_id' => 'APAR123',
    'mother_name' => 'Test Mother',
    'parents_phone' => '9876543211',
    'address' => 'Test Address',
    'guardian_name' => NULL,
    'guardian_contact' => NULL,
    'password' => password_hash('test123', PASSWORD_DEFAULT),
    'profile_image' => NULL
];

// Try to insert
$sql = "INSERT INTO students 
(name, roll_number, phone, branch, email, father_name, aadhaar_no, apar_id, mother_name, parents_phone, address, guardian_name, guardian_contact, password, profile_image)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo "<p style='color:red'>ERROR: " . $conn->error . "</p>";
    exit;
}

$stmt->bind_param(
    "sssssssssssssss",
    $test_data['name'],
    $test_data['roll_number'],
    $test_data['phone'],
    $test_data['branch'],
    $test_data['email'],
    $test_data['father_name'],
    $test_data['aadhaar_no'],
    $test_data['apar_id'],
    $test_data['mother_name'],
    $test_data['parents_phone'],
    $test_data['address'],
    $test_data['guardian_name'],
    $test_data['guardian_contact'],
    $test_data['password'],
    $test_data['profile_image']
);

if ($stmt->execute()) {
    echo "<p style='color:green'>✅ Test registration successful! Student ID: " . $stmt->insert_id . "</p>";
    echo "<p>The registration form should work now.</p>";

    // Clean up test data
    $conn->query("DELETE FROM students WHERE email = '{$test_data['email']}'");
    echo "<p>Test data cleaned up.</p>";
} else {
    echo "<p style='color:red'>❌ Registration failed: " . $stmt->error . "</p>";
}

$stmt->close();
$conn->close();

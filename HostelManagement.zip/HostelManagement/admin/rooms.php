<?php
require_once '../includes/config.php';
requireAdminLogin();

$page_title = 'Manage Rooms';

// Handle room creation
if (isset($_POST['create_room'])) {
    $room_number = sanitize($_POST['room_number']);
    $block = sanitize($_POST['block']);
    $floor = (int)$_POST['floor'];
    $capacity = (int)$_POST['capacity'];
    $fees = (float)$_POST['fees'];
    $room_type = sanitize($_POST['room_type']);
    $facilities = sanitize($_POST['facilities']);

    $sql = "INSERT INTO rooms (room_number, block, floor, capacity, fees, room_type, facilities) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssiidss", $room_number, $block, $floor, $capacity, $fees, $room_type, $facilities);

    if ($stmt->execute()) {
        $success = "Room created successfully!";
    } else {
        $error = "Error creating room: " . $conn->error;
    }
}

// Handle room update
if (isset($_POST['update_room'])) {
    $id = (int)$_POST['room_id'];
    $room_number = sanitize($_POST['room_number']);
    $block = sanitize($_POST['block']);
    $floor = (int)$_POST['floor'];
    $capacity = (int)$_POST['capacity'];
    $fees = (float)$_POST['fees'];
    $room_type = sanitize($_POST['room_type']);
    $facilities = sanitize($_POST['facilities']);
    $status = sanitize($_POST['status']);

    $sql = "UPDATE rooms SET room_number=?, block=?, floor=?, capacity=?, fees=?, room_type=?, facilities=?, status=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssiidsssi", $room_number, $block, $floor, $capacity, $fees, $room_type, $facilities, $status, $id);

    if ($stmt->execute()) {
        $success = "Room updated successfully!";
    } else {
        $error = "Error updating room: " . $conn->error;
    }
}

// Handle room deletion
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    // Check if room has students
    $check = $conn->query("SELECT COUNT(*) as count FROM students WHERE room_id = $id");
    if ($check->fetch_assoc()['count'] > 0) {
        $error = "Cannot delete room with assigned students!";
    } else {
        $conn->query("DELETE FROM rooms WHERE id = $id");
        $success = "Room deleted successfully!";
    }
}

// Get all rooms with occupancy count
$rooms = $conn->query("SELECT r.*, COUNT(s.id) as occupied FROM rooms r LEFT JOIN students s ON r.id = s.room_id GROUP BY r.id ORDER BY r.block, r.room_number");

// Get statistics
$total_rooms = $conn->query("SELECT COUNT(*) as count FROM rooms")->fetch_assoc()['count'];
$available_rooms = $conn->query("SELECT COUNT(*) as count FROM rooms WHERE status = 'Available'")->fetch_assoc()['count'];
$occupied_rooms = $conn->query("SELECT COUNT(DISTINCT room_id) as count FROM students WHERE room_id IS NOT NULL")->fetch_assoc()['count'];

include '../includes/header.php';
include '../includes/admin-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            Room Management
        </h1>
        <p style="color: var(--color-gray-600);">Manage hostel rooms and their availability</p>
    </div>

    <?php if (isset($success)): ?>
        <div class="alert alert-success" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✓</span>
            <div class="alert-content"><?php echo $success; ?></div>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="alert alert-error" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✕</span>
            <div class="alert-content"><?php echo $error; ?></div>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-2xl);">
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-primary-light);">🏠</div>
            <div class="stat-details">
                <div class="stat-label">Total Rooms</div>
                <div class="stat-value"><?php echo $total_rooms; ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-success-light);">✓</div>
            <div class="stat-details">
                <div class="stat-label">Available Rooms</div>
                <div class="stat-value"><?php echo $available_rooms; ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-warning-light);">👥</div>
            <div class="stat-details">
                <div class="stat-label">Occupied Rooms</div>
                <div class="stat-value"><?php echo $occupied_rooms; ?></div>
            </div>
        </div>
    </div>

    <!-- Create Room Form -->
    <div class="card" style="margin-bottom: var(--space-2xl);">
        <div class="card-header">
            <h2 class="card-title">➕ Add New Room</h2>
        </div>
        <div class="card-body">
            <form method="POST">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: var(--space-lg);">
                    <div class="form-group">
                        <label class="form-label required">Room Number</label>
                        <input type="text" name="room_number" class="form-input" placeholder="e.g., 101" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label required">Block</label>
                        <select name="block" class="form-select" required>
                            <option value="A">Block A</option>
                            <option value="B">Block B</option>
                            <option value="C">Block C</option>
                            <option value="D">Block D</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label required">Floor</label>
                        <input type="number" name="floor" class="form-input" min="0" max="10" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label required">Capacity</label>
                        <input type="number" name="capacity" class="form-input" min="1" max="6" value="2" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label required">Monthly Fees (₹)</label>
                        <input type="number" name="fees" class="form-input" step="0.01" placeholder="5000" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label required">Room Type</label>
                        <select name="room_type" class="form-select" required>
                            <option value="Standard">Standard</option>
                            <option value="Deluxe">Deluxe</option>
                            <option value="AC">AC</option>
                            <option value="Non-AC">Non-AC</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Facilities</label>
                    <input type="text" name="facilities" class="form-input" placeholder="Bed, Cupboard, Study Table, WiFi">
                    <span class="form-helper">Comma-separated list of facilities</span>
                </div>

                <button type="submit" name="create_room" class="btn btn-primary">
                    ➕ Create Room
                </button>
            </form>
        </div>
    </div>

    <!-- Rooms Table -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">All Rooms</h2>
        </div>
        <div class="card-body">
            <?php if ($rooms->num_rows > 0): ?>
                <div style="overflow-x: auto;">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Room</th>
                                <th>Block</th>
                                <th>Floor</th>
                                <th>Type</th>
                                <th>Capacity</th>
                                <th>Occupied</th>
                                <th>Fees</th>
                                <th>Status</th>
                                <th>Facilities</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($room = $rooms->fetch_assoc()): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($room['room_number']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($room['block']); ?></td>
                                    <td><?php echo $room['floor']; ?></td>
                                    <td><?php echo htmlspecialchars($room['room_type']); ?></td>
                                    <td><?php echo $room['capacity']; ?></td>
                                    <td>
                                        <span style="color: <?php echo ($room['occupied'] >= $room['capacity']) ? 'var(--color-error)' : 'var(--color-success)'; ?>;">
                                            <?php echo $room['occupied']; ?>/<?php echo $room['capacity']; ?>
                                        </span>
                                    </td>
                                    <td>₹<?php echo number_format($room['fees'], 2); ?></td>
                                    <td><?php echo getStatusBadge($room['status']); ?></td>
                                    <td style="max-width: 200px; font-size: var(--text-sm);">
                                        <?php echo htmlspecialchars($room['facilities'] ?? 'N/A'); ?>
                                    </td>
                                    <td>
                                        <div style="display: flex; gap: var(--space-xs);">
                                            <button onclick="openModal('edit-modal-<?php echo $room['id']; ?>')" class="btn btn-sm btn-secondary">
                                                Edit
                                            </button>
                                            <a href="?delete=<?php echo $room['id']; ?>" class="btn btn-sm btn-error" onclick="return confirm('Are you sure you want to delete this room?');">
                                                Delete
                                            </a>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Edit Modal -->
                                <div id="edit-modal-<?php echo $room['id']; ?>" class="modal">
                                    <div class="modal-content" style="max-width: 800px;">
                                        <div class="modal-header">
                                            <h2 style="margin: 0;">Edit Room <?php echo htmlspecialchars($room['room_number']); ?></h2>
                                            <button onclick="closeModal('edit-modal-<?php echo $room['id']; ?>')" class="modal-close">×</button>
                                        </div>
                                        <form method="POST">
                                            <input type="hidden" name="room_id" value="<?php echo $room['id']; ?>">
                                            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: var(--space-lg); padding: var(--space-xl);">
                                                <div class="form-group">
                                                    <label class="form-label required">Room Number</label>
                                                    <input type="text" name="room_number" class="form-input" value="<?php echo htmlspecialchars($room['room_number']); ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="form-label required">Block</label>
                                                    <select name="block" class="form-select" required>
                                                        <option value="A" <?php echo ($room['block'] == 'A') ? 'selected' : ''; ?>>Block A</option>
                                                        <option value="B" <?php echo ($room['block'] == 'B') ? 'selected' : ''; ?>>Block B</option>
                                                        <option value="C" <?php echo ($room['block'] == 'C') ? 'selected' : ''; ?>>Block C</option>
                                                        <option value="D" <?php echo ($room['block'] == 'D') ? 'selected' : ''; ?>>Block D</option>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label class="form-label required">Floor</label>
                                                    <input type="number" name="floor" class="form-input" value="<?php echo $room['floor']; ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="form-label required">Capacity</label>
                                                    <input type="number" name="capacity" class="form-input" value="<?php echo $room['capacity']; ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="form-label required">Monthly Fees</label>
                                                    <input type="number" name="fees" class="form-input" step="0.01" value="<?php echo $room['fees']; ?>" required>
                                                </div>
                                                <div class="form-group">
                                                    <label class="form-label required">Room Type</label>
                                                    <select name="room_type" class="form-select" required>
                                                        <option value="Standard" <?php echo ($room['room_type'] == 'Standard') ? 'selected' : ''; ?>>Standard</option>
                                                        <option value="Deluxe" <?php echo ($room['room_type'] == 'Deluxe') ? 'selected' : ''; ?>>Deluxe</option>
                                                        <option value="AC" <?php echo ($room['room_type'] == 'AC') ? 'selected' : ''; ?>>AC</option>
                                                        <option value="Non-AC" <?php echo ($room['room_type'] == 'Non-AC') ? 'selected' : ''; ?>>Non-AC</option>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label class="form-label required">Status</label>
                                                    <select name="status" class="form-select" required>
                                                        <option value="Available" <?php echo ($room['status'] == 'Available') ? 'selected' : ''; ?>>Available</option>
                                                        <option value="Occupied" <?php echo ($room['status'] == 'Occupied') ? 'selected' : ''; ?>>Occupied</option>
                                                        <option value="Maintenance" <?php echo ($room['status'] == 'Maintenance') ? 'selected' : ''; ?>>Maintenance</option>
                                                        <option value="Reserved" <?php echo ($room['status'] == 'Reserved') ? 'selected' : ''; ?>>Reserved</option>
                                                    </select>
                                                </div>
                                                <div class="form-group" style="grid-column: 1 / -1;">
                                                    <label class="form-label">Facilities</label>
                                                    <input type="text" name="facilities" class="form-input" value="<?php echo htmlspecialchars($room['facilities'] ?? ''); ?>">
                                                </div>
                                            </div>
                                            <div style="padding: 0 var(--space-xl) var(--space-xl); display: flex; gap: var(--space-md); justify-content: flex-end;">
                                                <button type="button" onclick="closeModal('edit-modal-<?php echo $room['id']; ?>')" class="btn btn-secondary">Cancel</button>
                                                <button type="submit" name="update_room" class="btn btn-primary">Update Room</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div style="padding: var(--space-3xl); text-align: center; color: var(--color-gray-500);">
                    <div style="font-size: 4rem; margin-bottom: var(--space-lg);">🏠</div>
                    <h3>No Rooms Found</h3>
                    <p>Create your first room using the form above.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
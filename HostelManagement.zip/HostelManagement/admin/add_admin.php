<?php
require_once '../includes/config.php';
session_start();

// Check admin login
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validation
    if (empty($username) || empty($password) || empty($confirm_password)) {
        $message = '<div class="error">All fields are required</div>';
    } elseif ($password !== $confirm_password) {
        $message = '<div class="error">Passwords do not match</div>';
    } elseif (strlen($password) < 6) {
        $message = '<div class="error">Password must be at least 6 characters</div>';
    } else {
        // Check if username already exists
        $stmt = $conn->prepare("SELECT id FROM admin WHERE username=?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $message = '<div class="error">Username already exists</div>';
        } else {
            // Hash password and insert
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("INSERT INTO admin (username, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $username, $hash);

            if ($stmt->execute()) {
                $message = '<div class="success">Admin user created successfully!</div>';
            } else {
                $message = '<div class="error">Error creating admin user: ' . $stmt->error . '</div>';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Add New Admin - Hostel Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f2f5;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background: #007BFF;
            padding: 10px 20px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .nav-left {
            font-size: 18px;
            font-weight: bold;
        }

        .nav-right a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
        }

        .nav-right a.active {
            text-decoration: underline;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }

        button:hover {
            background: #218838;
        }

        .success {
            color: green;
            background: #d4edda;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .error {
            color: red;
            background: #f8d7da;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            color: #007BFF;
            text-decoration: none;
        }

        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="navbar">
        <div class="nav-left">🏠 Hostel Management</div>
        <div class="nav-right">
            <a href="manage_students.php">View Students</a>
            <a href="add_admin.php" class="active">Add Admin</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>

    <div class="container">
        <h1>👤 Add New Admin User</h1>

        <?php echo $message; ?>

        <form method="post">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required
                    placeholder="Enter admin username">
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required
                    placeholder="Enter password (min 6 characters)">
            </div>

            <div class="form-group">
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" required
                    placeholder="Re-enter password">
            </div>

            <button type="submit">Create Admin User</button>
        </form>

        <div class="back-link">
            <a href="manage_students.php">← Back to Admin Panel</a>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>
</body>

</html>
<?php
require_once '../includes/config.php';
requireAdminLogin();

$page_title = 'Admin Dashboard';

// Get statistics
$stats = [];

// Total students
$result = $conn->query("SELECT COUNT(*) as count FROM students WHERE is_active = 1");
$stats['total_students'] = $result->fetch_assoc()['count'];

// Total rooms
$result = $conn->query("SELECT COUNT(*) as count FROM rooms");
$stats['total_rooms'] = $result->fetch_assoc()['count'];

// Available rooms
$result = $conn->query("SELECT COUNT(*) as count FROM rooms WHERE occupied < capacity");
$stats['available_rooms'] = $result->fetch_assoc()['count'];

// Pending complaints
$result = $conn->query("SELECT COUNT(*) as count FROM complaints WHERE status = 'Pending'");
$stats['pending_complaints'] = $result->fetch_assoc()['count'];

// Total fee collection (this month)
$result = $conn->query("SELECT SUM(amount) as total FROM fees WHERE status = 'Paid' AND MONTH(payment_date) = MONTH(CURRENT_DATE())");
$row = $result->fetch_assoc();
$stats['monthly_revenue'] = $row['total'] ?? 0;

// Get recent students
$recent_students = $conn->query("SELECT s.*, r.room_number, r.block FROM students s LEFT JOIN rooms r ON s.room_id = r.id ORDER BY s.registration_date DESC LIMIT 5");

// Get recent complaints
$recent_complaints = $conn->query("SELECT c.*, s.name as student_name FROM complaints c JOIN students s ON c.student_id = s.id ORDER BY c.created_at DESC LIMIT 5");

include '../includes/header.php';
include '../includes/admin-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <!-- Professional Page Header -->
    <div class="page-header">
        <div style="display: flex; align-items: center; gap: var(--space-lg); margin-bottom: var(--space-md);">
            <div style="width: 64px; height: 64px; background: linear-gradient(135deg, var(--sbte-blue), var(--sbte-saffron)); border-radius: var(--radius-xl); display: flex; align-items: center; justify-content: center; color: white; font-size: 2rem; box-shadow: var(--shadow-lg);">
                📊
            </div>
            <div>
                <h1 class="page-title">Admin Dashboard</h1>
                <p class="page-subtitle">
                    Welcome back, <strong><?php echo htmlspecialchars($_SESSION['admin_username']); ?></strong>! Here's what's happening today.
                </p>
            </div>
        </div>
        <div style="display: flex; gap: var(--space-md); align-items: center; margin-top: var(--space-lg);">
            <span style="padding: 0.5rem 1rem; background: var(--sbte-light-blue); color: var(--sbte-dark-blue); border-radius: var(--radius-full); font-size: var(--text-sm); font-weight: var(--font-bold);">
                🏛️ SBTE Bihar HMS
            </span>
            <span style="color: var(--color-gray-500); font-size: var(--text-sm);">
                📅 <?php echo date('l, F j, Y'); ?>
            </span>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <!-- Total Students -->
        <div class="stat-card animate-fadeInUp">
            <div class="stat-icon icon-primary">👥</div>
            <div class="stat-content">
                <div class="stat-label">Total Students</div>
                <div class="stat-value" data-target="<?php echo $stats['total_students']; ?>">
                    <?php echo $stats['total_students']; ?>
                </div>
            </div>
        </div>

        <!-- Available Rooms -->
        <div class="stat-card animate-fadeInUp" style="animation-delay: 0.1s;">
            <div class="stat-icon icon-success">🏠</div>
            <div class="stat-content">
                <div class="stat-label">Available Rooms</div>
                <div class="stat-value" data-target="<?php echo $stats['available_rooms']; ?>">
                    <?php echo $stats['available_rooms']; ?>
                </div>
                <div class="stat-change" style="color: var(--color-gray-600); font-size: var(--text-sm);">
                    of <?php echo $stats['total_rooms']; ?> total
                </div>
            </div>
        </div>

        <!-- Monthly Revenue -->
        <div class="stat-card animate-fadeInUp" style="animation-delay: 0.2s;">
            <div class="stat-icon icon-success">💰</div>
            <div class="stat-content">
                <div class="stat-label">Monthly Revenue</div>
                <div class="stat-value" style="font-size: var(--text-3xl);">
                    ₹<?php echo number_format($stats['monthly_revenue'], 0); ?>
                </div>
            </div>
        </div>

        <!-- Pending Complaints -->
        <div class="stat-card animate-fadeInUp" style="animation-delay: 0.3s;">
            <div class="stat-icon icon-warning">📝</div>
            <div class="stat-content">
                <div class="stat-label">Pending Complaints</div>
                <div class="stat-value" data-target="<?php echo $stats['pending_complaints']; ?>">
                    <?php echo $stats['pending_complaints']; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Two Column Layout -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(500px, 1fr)); gap: var(--space-2xl);">
        <!-- Recent Students -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Recent Registrations</h2>
                <a href="students.php" class="btn btn-sm btn-secondary">View All</a>
            </div>
            <div class="card-body">
                <?php if ($recent_students->num_rows > 0): ?>
                    <div style="display: flex; flex-direction: column; gap: var(--space-md);">
                        <?php while ($student = $recent_students->fetch_assoc()): ?>
                            <div style="display: flex; align-items: center; gap: var(--space-md); padding: var(--space-md); border-radius: var(--radius-lg); background: var(--color-gray-50);">
                                <div style="width: 50px; height: 50px; border-radius: var(--radius-full); background: var(--gradient-primary); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                    <?php
                                    if (!empty($student['profile_image']) && file_exists('../' . $student['profile_image'])) {
                                        echo "<img src='../{$student['profile_image']}' style='width: 100%; height: 100%; object-fit: cover; border-radius: var(--radius-full);'>";
                                    } else {
                                        echo strtoupper(substr($student['name'], 0, 1));
                                    }
                                    ?>
                                </div>
                                <div style="flex: 1;">
                                    <div style="font-weight: var(--font-semibold); color: var(--color-gray-900);">
                                        <?php echo htmlspecialchars($student['name']); ?>
                                    </div>
                                    <div style="font-size: var(--text-sm); color: var(--color-gray-600);">
                                        <?php echo htmlspecialchars($student['roll_number']); ?> •
                                        <?php echo htmlspecialchars($student['branch']); ?>
                                    </div>
                                </div>
                                <div style="text-align: right;">
                                    <div style="font-size: var(--text-xs); color: var(--color-gray-500);">
                                        <?php echo formatDate($student['registration_date']); ?>
                                    </div>
                                    <?php if ($student['room_number']): ?>
                                        <span class="badge badge-success">
                                            <?php echo $student['block'] . '-' . $student['room_number']; ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="badge badge-warning">No Room</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <p style="text-align: center; color: var(--color-gray-500); padding: var(--space-xl);">
                        No recent registrations
                    </p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Complaints -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Recent Complaints</h2>
                <a href="complaints.php" class="btn btn-sm btn-secondary">View All</a>
            </div>
            <div class="card-body">
                <?php if ($recent_complaints->num_rows > 0): ?>
                    <div style="display: flex; flex-direction: column; gap: var(--space-md);">
                        <?php while ($complaint = $recent_complaints->fetch_assoc()): ?>
                            <div style="padding: var(--space-md); border-radius: var(--radius-lg); background: var(--color-gray-50); border-left: 4px solid 
                                <?php
                                echo match ($complaint['priority']) {
                                    'Urgent' => 'var(--color-error)',
                                    'High' => 'var(--color-warning)',
                                    'Medium' => 'var(--color-info)',
                                    default => 'var(--color-gray-400)'
                                };
                                ?>;">
                                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: var(--space-sm);">
                                    <div style="font-weight: var(--font-semibold); color: var(--color-gray-900);">
                                        <?php echo htmlspecialchars($complaint['subject']); ?>
                                    </div>
                                    <?php echo getStatusBadge($complaint['status']); ?>
                                </div>
                                <div style="font-size: var(--text-sm); color: var(--color-gray-600); margin-bottom: var(--space-xs);">
                                    By: <?php echo htmlspecialchars($complaint['student_name']); ?>
                                </div>
                                <div style="display: flex; gap: var(--space-md); font-size: var(--text-xs); color: var(--color-gray-500);">
                                    <span>📁 <?php echo $complaint['category']; ?></span>
                                    <span>⚠️ <?php echo $complaint['priority']; ?></span>
                                    <span>🕐 <?php echo formatDateTime($complaint['created_at']); ?></span>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <p style="text-align: center; color: var(--color-gray-500); padding: var(--space-xl);">
                        No recent complaints
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card" style="margin-top: var(--space-2xl);">
        <div class="card-header">
            <h2 class="card-title">Quick Actions</h2>
        </div>
        <div class="card-body">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: var(--space-lg);">
                <a href="students.php" class="btn btn-primary">
                    👥 Manage Students
                </a>
                <a href="rooms.php" class="btn btn-primary">
                    🏠 Manage Rooms
                </a>
                <a href="announcements.php" class="btn btn-primary">
                    📢 Post Announcement
                </a>
                <a href="fees.php" class="btn btn-primary">
                    💳 View Fees
                </a>
                <a href="maintenance.php" class="btn btn-primary">
                    🔧 Maintenance Requests
                </a>
                <a href="reports.php" class="btn btn-primary">
                    📊 Generate Reports
                </a>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
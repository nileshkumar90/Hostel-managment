<?php
require_once '../includes/config.php';
requireAdminLogin();

$page_title = 'Maintenance Requests';

// Handle Status Update
if (isset($_POST['update_status'])) {
    $request_id = (int)$_POST['request_id'];
    $status = sanitize($_POST['status']);

    // Simple status update - only update the status field
    $sql = "UPDATE maintenance_requests SET status = ?";

    if ($status == 'Completed') {
        $sql .= ", completed_at = NOW()";
    }

    $sql .= " WHERE id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $status, $request_id);

    if ($stmt->execute()) {
        $success = "Maintenance request updated successfully!";
    } else {
        $error = "Error updating request.";
    }
}

// Get all requests
$sql = "SELECT m.*, s.name as student_name, s.roll_number, r.room_number, r.block 
        FROM maintenance_requests m 
        JOIN students s ON m.student_id = s.id 
        JOIN rooms r ON m.room_id = r.id 
        ORDER BY 
        CASE m.status 
            WHEN 'Pending' THEN 1 
            WHEN 'In Progress' THEN 2 
            WHEN 'Completed' THEN 3 
            ELSE 4 
        END, m.created_at DESC";
$requests = $conn->query($sql);

// Statistics
$total_pending = $conn->query("SELECT COUNT(*) as count FROM maintenance_requests WHERE status = 'Pending'")->fetch_assoc()['count'];
$in_progress = $conn->query("SELECT COUNT(*) as count FROM maintenance_requests WHERE status = 'In Progress'")->fetch_assoc()['count'];
$completed_month = $conn->query("SELECT COUNT(*) as count FROM maintenance_requests WHERE status = 'Completed' AND MONTH(completed_at) = MONTH(CURRENT_DATE())")->fetch_assoc()['count'];

include '../includes/header.php';
include '../includes/admin-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            Maintenance Management
        </h1>
        <p style="color: var(--color-gray-600);">Track and resolve hostel maintenance issues</p>
    </div>

    <?php if (isset($success)): ?>
        <div class="alert alert-success" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✓</span>
            <div class="alert-content"><?php echo $success; ?></div>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-2xl);">
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-error-light);">🔧</div>
            <div class="stat-details">
                <div class="stat-label">Pending Requests</div>
                <div class="stat-value"><?php echo $total_pending; ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-warning-light);">⚙️</div>
            <div class="stat-details">
                <div class="stat-label">In Progress</div>
                <div class="stat-value"><?php echo $in_progress; ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-success-light);">✓</div>
            <div class="stat-details">
                <div class="stat-label">Completed (This Month)</div>
                <div class="stat-value"><?php echo $completed_month; ?></div>
            </div>
        </div>
    </div>

    <!-- Requests List -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Maintenance Requests</h2>
        </div>
        <div class="card-body">
            <?php if ($requests->num_rows > 0): ?>
                <div style="display: flex; flex-direction: column; gap: var(--space-lg);">
                    <?php while ($req = $requests->fetch_assoc()): ?>
                        <div style="border: 1px solid var(--color-gray-200); border-radius: var(--radius-lg); padding: var(--space-lg); background: <?php echo ($req['status'] == 'Pending') ? 'var(--color-error-light)' : 'white'; ?>;">
                            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: var(--space-md);">
                                <div>
                                    <h3 style="font-weight: var(--font-bold); color: var(--color-gray-900); margin-bottom: var(--space-xs);">
                                        <?php echo htmlspecialchars($req['category']); ?>
                                    </h3>
                                    <div style="font-size: var(--text-sm); color: var(--color-gray-600);">
                                        Room: <strong><?php echo $req['block'] . '-' . $req['room_number']; ?></strong> •
                                        Reported by: <?php echo htmlspecialchars($req['student_name']); ?>
                                    </div>
                                </div>
                                <?php echo getStatusBadge($req['status']); ?>
                            </div>

                            <p style="color: var(--color-gray-700); margin-bottom: var(--space-md);">
                                <?php echo nl2br(htmlspecialchars($req['description'])); ?>
                            </p>

                            <div style="display: flex; justify-content: flex-end;">
                                <button onclick="openModal('update-req-<?php echo $req['id']; ?>')" class="btn btn-sm btn-primary">
                                    Update Status
                                </button>
                            </div>
                        </div>

                        <!-- Update Modal -->
                        <div id="update-req-<?php echo $req['id']; ?>" class="modal">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h2>Update Request #<?php echo $req['id']; ?></h2>
                                    <button onclick="closeModal('update-req-<?php echo $req['id']; ?>')" class="modal-close">×</button>
                                </div>
                                <form method="POST">
                                    <input type="hidden" name="request_id" value="<?php echo $req['id']; ?>">
                                    <div style="padding: var(--space-xl); display: grid; gap: var(--space-lg);">
                                        <div class="form-group">
                                            <label class="form-label">Status</label>
                                            <select name="status" class="form-select" required>
                                                <option value="Pending" <?php echo ($req['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                                <option value="In Progress" <?php echo ($req['status'] == 'In Progress') ? 'selected' : ''; ?>>In Progress</option>
                                                <option value="Completed" <?php echo ($req['status'] == 'Completed') ? 'selected' : ''; ?>>Completed</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div style="padding: 0 var(--space-xl) var(--space-xl); text-align: right;">
                                        <button type="submit" name="update_status" class="btn btn-primary">Save Changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: var(--space-3xl); color: var(--color-gray-500);">
                    <h3>No Maintenance Requests</h3>
                    <p>All systems are running smoothly!</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<?php
include "../includes/config.php";

// Check current admin users
$result = $conn->query("SELECT id, username, created_at FROM admin");
echo "<h2>Current Admin Users:</h2>";
if ($result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse; margin: 20px 0;'>";
    echo "<tr><th>ID</th><th>Username</th><th>Created At</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['username']) . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No admin users found.</p>";
}

// Try to create admin if doesn't exist
$username = 'admin';
$password_plain = 'admin123';
$hash = password_hash($password_plain, PASSWORD_BCRYPT);

$stmt = $conn->prepare("INSERT IGNORE INTO admin (username, password) VALUES (?, ?)");
$stmt->bind_param("ss", $username, $hash);
if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo "<p style='color: green;'>✅ Admin user 'admin' created successfully!</p>";
        echo "<p><strong>Username:</strong> admin</p>";
        echo "<p><strong>Password:</strong> admin123</p>";
    } else {
        echo "<p style='color: orange;'>ℹ️ Admin user 'admin' already exists.</p>";
    }
} else {
    echo "<p style='color: red;'>❌ Error: " . $stmt->error . "</p>";
}

// Test login
$test_username = 'admin';
$test_password = 'admin123';

$stmt = $conn->prepare("SELECT password FROM admin WHERE username=?");
$stmt->bind_param("s", $test_username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    if (password_verify($test_password, $row['password'])) {
        echo "<p style='color: green;'>✅ Login test successful! Password is correct.</p>";
    } else {
        echo "<p style='color: red;'>❌ Password verification failed! Resetting password...</p>";

        // Reset the password
        $new_hash = password_hash($test_password, PASSWORD_BCRYPT);
        $update_stmt = $conn->prepare("UPDATE admin SET password=? WHERE username=?");
        $update_stmt->bind_param("ss", $new_hash, $test_username);

        if ($update_stmt->execute()) {
            echo "<p style='color: green;'>✅ Password reset successful! Now try logging in.</p>";
        } else {
            echo "<p style='color: red;'>❌ Failed to reset password: " . $update_stmt->error . "</p>";
        }
    }
} else {
    echo "<p style='color: red;'>❌ Admin user not found in database!</p>";
}

echo "<hr>";
echo "<p><strong>🔐 Admin Login URL:</strong> <a href='login.php' target='_blank'>http://localhost/HostelManagementSystem/admin/login.php</a></p>";
echo "<p><strong>👤 Username:</strong> admin</p>";
echo "<p><strong>🔑 Password:</strong> admin123</p>";
?>

    exit();
    }

    $page_title = 'Manage Students';

    // Handle deletion
    if (isset($_GET['delete_id'])) {
    $student_id = (int)$_GET['delete_id'];

    // Get student's room_id
    $res = $conn->query("SELECT room_id FROM students WHERE id=$student_id");
    if ($res->num_rows === 1) {
    $row = $res->fetch_assoc();
    $room_id = $row['room_id'];

    // Delete student
    $conn->query("DELETE FROM students WHERE id=$student_id");

    // Decrease room occupancy
    if ($room_id) {
    $conn->query("UPDATE rooms SET occupied = occupied - 1 WHERE id=$room_id");
    }
    }

    // Redirect to avoid resubmission
    header("Location: hostel_students.php");
    exit();
    }

    // Fetch students with room booking
    $res = $conn->query("
    SELECT students.*, rooms.room_number, rooms.block, rooms.floor
    FROM students
    LEFT JOIN rooms ON students.room_id = rooms.id
    ORDER BY students.id DESC
    ");

    // Get statistics
    $total_students = $conn->query("SELECT COUNT(*) as count FROM students")->fetch_assoc()['count'];
    $active_students = $conn->query("SELECT COUNT(*) as count FROM students WHERE is_active = 1")->fetch_assoc()['count'];
    $students_with_rooms = $conn->query("SELECT COUNT(*) as count FROM students WHERE room_id IS NOT NULL")->fetch_assoc()['count'];

    include '../includes/header.php';
    ?>

    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: var(--space-xl) var(--space-md);
        }

        .students-container {
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Header Section */
        .page-header {
            background: var(--color-white);
            border-radius: var(--radius-2xl);
            padding: var(--space-2xl);
            margin-bottom: var(--space-xl);
            box-shadow: var(--shadow-2xl);
            animation: slideDown 0.4s ease-out;
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: var(--space-xl);
            flex-wrap: wrap;
            gap: var(--space-md);
        }

        .page-title {
            font-size: var(--text-4xl);
            font-weight: var(--font-extrabold);
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .header-actions {
            display: flex;
            gap: var(--space-md);
        }

        /* Statistics Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: var(--space-lg);
            margin-bottom: var(--space-xl);
        }

        .stat-card {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.7) 100%);
            padding: var(--space-lg);
            border-radius: var(--radius-xl);
            display: flex;
            align-items: center;
            gap: var(--space-md);
            transition: all var(--transition-base);
        }

        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
        }

        .stat-icon {
            font-size: 3rem;
            width: 70px;
            height: 70px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: var(--radius-lg);
            background: var(--gradient-primary);
        }

        .stat-details {
            flex: 1;
        }

        .stat-label {
            font-size: var(--text-sm);
            color: var(--color-gray-600);
            margin-bottom: var(--space-xs);
        }

        .stat-value {
            font-size: var(--text-3xl);
            font-weight: var(--font-extrabold);
            color: var(--color-gray-900);
        }

        /* Search and Filter Section */
        .controls-section {
            display: flex;
            gap: var(--space-md);
            flex-wrap: wrap;
            align-items: center;
        }

        .search-box {
            flex: 1;
            min-width: 300px;
            position: relative;
        }

        .search-input {
            width: 100%;
            padding: var(--space-md) var(--space-md) var(--space-md) 45px;
            border: 2px solid var(--color-gray-200);
            border-radius: var(--radius-lg);
            font-size: var(--text-base);
            transition: all var(--transition-base);
        }

        .search-input:focus {
            outline: none;
            border-color: var(--color-primary);
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.2rem;
            color: var(--color-gray-400);
        }

        .filter-select {
            padding: var(--space-md) var(--space-lg);
            border: 2px solid var(--color-gray-200);
            border-radius: var(--radius-lg);
            font-size: var(--text-base);
            background: var(--color-white);
            cursor: pointer;
            transition: all var(--transition-base);
        }

        .filter-select:focus {
            outline: none;
            border-color: var(--color-primary);
        }

        /* Table Section */
        .table-container {
            background: var(--color-white);
            border-radius: var(--radius-2xl);
            box-shadow: var(--shadow-2xl);
            overflow: hidden;
            animation: fadeInUp 0.4s ease-out 0.1s backwards;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .students-table {
            width: 100%;
            border-collapse: collapse;
        }

        .students-table thead {
            background: var(--gradient-primary);
            color: var(--color-white);
        }

        .students-table th {
            padding: var(--space-lg);
            text-align: left;
            font-weight: var(--font-semibold);
            font-size: var(--text-sm);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .students-table td {
            padding: var(--space-lg);
            border-bottom: 1px solid var(--color-gray-100);
        }

        .students-table tbody tr {
            transition: all var(--transition-fast);
        }

        .students-table tbody tr:hover {
            background: var(--color-gray-50);
        }

        .student-name {
            display: flex;
            align-items: center;
            gap: var(--space-md);
        }

        .student-avatar {
            width: 40px;
            height: 40px;
            border-radius: var(--radius-full);
            background: var(--gradient-primary);
            color: var(--color-white);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: var(--font-bold);
            font-size: var(--text-sm);
        }

        .student-avatar img {
            width: 100%;
            height: 100%;
            border-radius: var(--radius-full);
            object-fit: cover;
        }

        .student-info {
            flex: 1;
        }

        .student-info-name {
            font-weight: var(--font-semibold);
            color: var(--color-gray-900);
            margin-bottom: 2px;
        }

        .student-info-roll {
            font-size: var(--text-sm);
            color: var(--color-gray-500);
        }

        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: var(--radius-full);
            font-size: var(--text-xs);
            font-weight: var(--font-semibold);
        }

        .status-active {
            background: var(--color-success-light);
            color: var(--color-success);
        }

        .status-inactive {
            background: var(--color-error-light);
            color: var(--color-error);
        }

        .room-badge {
            display: inline-flex;
            align-items: center;
            gap: var(--space-xs);
            padding: 4px 10px;
            background: var(--color-primary-lighter);
            color: var(--color-primary);
            border-radius: var(--radius-md);
            font-size: var(--text-sm);
            font-weight: var(--font-medium);
        }

        .no-room {
            color: var(--color-gray-400);
            font-style: italic;
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: var(--space-xs);
        }

        .action-btn {
            padding: 6px 12px;
            border-radius: var(--radius-md);
            text-decoration: none;
            font-size: var(--text-sm);
            font-weight: var(--font-medium);
            transition: all var(--transition-base);
            display: inline-flex;
            align-items: center;
            gap: 4px;
            border: none;
            cursor: pointer;
        }

        .btn-view {
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            color: var(--color-white);
        }

        .btn-view:hover {
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
            transform: translateY(-2px);
        }

        .btn-edit {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: var(--color-white);
        }

        .btn-edit:hover {
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4);
            transform: translateY(-2px);
        }

        .btn-delete {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: var(--color-white);
        }

        .btn-delete:hover {
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4);
            transform: translateY(-2px);
        }

        /* Primary Button */
        .btn-primary {
            padding: var(--space-md) var(--space-xl);
            background: var(--gradient-primary);
            color: var(--color-white);
            border-radius: var(--radius-lg);
            text-decoration: none;
            font-weight: var(--font-semibold);
            display: inline-flex;
            align-items: center;
            gap: var(--space-sm);
            transition: all var(--transition-base);
            box-shadow: var(--shadow-md);
            border: none;
            cursor: pointer;
        }

        .btn-primary:hover {
            box-shadow: var(--shadow-xl), var(--shadow-glow);
            transform: translateY(-2px);
        }

        .btn-secondary {
            padding: var(--space-md) var(--space-lg);
            background: var(--color-white);
            color: var(--color-primary);
            border: 2px solid var(--color-primary);
            border-radius: var(--radius-lg);
            text-decoration: none;
            font-weight: var(--font-semibold);
            display: inline-flex;
            align-items: center;
            gap: var(--space-sm);
            transition: all var(--transition-base);
        }

        .btn-secondary:hover {
            background: var(--color-primary);
            color: var(--color-white);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: var(--space-3xl);
            color: var(--color-gray-500);
        }

        .empty-icon {
            font-size: 5rem;
            margin-bottom: var(--space-lg);
            opacity: 0.5;
        }

        .empty-title {
            font-size: var(--text-2xl);
            font-weight: var(--font-bold);
            color: var(--color-gray-700);
            margin-bottom: var(--space-sm);
        }

        .empty-text {
            color: var(--color-gray-500);
        }

        /* Animations */
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive */
        @media (max-width: 768px) {
            .page-title {
                font-size: var(--text-2xl);
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .search-box {
                min-width: 100%;
            }

            .students-table th,
            .students-table td {
                padding: var(--space-md);
                font-size: var(--text-sm);
            }

            .action-buttons {
                flex-direction: column;
            }
        }
    </style>

    <div class="students-container">
        <!-- Page Header -->
        <div class="page-header">
            <div class="header-top">
                <h1 class="page-title">👥 Manage Students</h1>
                <div class="header-actions">
                    <a href="manage_students.php" class="btn-secondary">← Back to Dashboard</a>
                    <a href="../register.php" class="btn-primary">
                        ➕ Add New Student
                    </a>
                </div>
            </div>

            <!-- Statistics -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">👨‍🎓</div>
                    <div class="stat-details">
                        <div class="stat-label">Total Students</div>
                        <div class="stat-value"><?php echo $total_students; ?></div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">✅</div>
                    <div class="stat-details">
                        <div class="stat-label">Active Students</div>
                        <div class="stat-value"><?php echo $active_students; ?></div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">🏠</div>
                    <div class="stat-details">
                        <div class="stat-label">With Rooms</div>
                        <div class="stat-value"><?php echo $students_with_rooms; ?></div>
                    </div>
                </div>
            </div>

            <!-- Search and Filters -->
            <div class="controls-section">
                <div class="search-box">
                    <span class="search-icon">🔍</span>
                    <input type="text" id="searchInput" class="search-input" placeholder="Search by name, email, roll number...">
                </div>

                <select id="statusFilter" class="filter-select">
                    <option value="">All Status</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>

                <select id="roomFilter" class="filter-select">
                    <option value="">All Rooms</option>
                    <option value="with-room">With Room</option>
                    <option value="no-room">No Room</option>
                </select>
            </div>
        </div>

        <!-- Students Table -->
        <div class="table-container">
            <div class="table-responsive">
                <table class="students-table" id="studentsTable">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Contact</th>
                            <th>Branch</th>
                            <th>Room</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody">
                        <?php if ($res->num_rows > 0): ?>
                            <?php while ($student = $res->fetch_assoc()): ?>
                                <tr class="student-row"
                                    data-name="<?php echo strtolower($student['name']); ?>"
                                    data-email="<?php echo strtolower($student['email']); ?>"
                                    data-roll="<?php echo strtolower($student['roll_number']); ?>"
                                    data-status="<?php echo $student['is_active'] ? 'active' : 'inactive'; ?>"
                                    data-room="<?php echo $student['room_id'] ? 'with-room' : 'no-room'; ?>">
                                    <td>
                                        <div class="student-name">
                                            <div class="student-avatar">
                                                <?php if (!empty($student['profile_image']) && file_exists($student['profile_image'])): ?>
                                                    <img src="<?php echo htmlspecialchars($student['profile_image']); ?>" alt="Avatar">
                                                <?php else: ?>
                                                    <?php echo strtoupper(substr($student['name'], 0, 1)); ?>
                                                <?php endif; ?>
                                            </div>
                                            <div class="student-info">
                                                <div class="student-info-name"><?php echo htmlspecialchars($student['name']); ?></div>
                                                <div class="student-info-roll"><?php echo htmlspecialchars($student['roll_number']); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div><?php echo htmlspecialchars($student['email']); ?></div>
                                        <div style="font-size: var(--text-sm); color: var(--color-gray-500); margin-top: 4px;">
                                            <?php echo htmlspecialchars($student['phone']); ?>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($student['branch']); ?></td>
                                    <td>
                                        <?php if ($student['room_number']): ?>
                                            <span class="room-badge">
                                                🏠 <?php echo htmlspecialchars($student['room_number']); ?> - <?php echo htmlspecialchars($student['block']); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="no-room">Not Assigned</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="status-badge <?php echo $student['is_active'] ? 'status-active' : 'status-inactive'; ?>">
                                            <?php echo $student['is_active'] ? '✓ Active' : '✕ Inactive'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="view_student.php?id=<?php echo $student['id']; ?>" class="action-btn btn-view" title="View Details">
                                                👁️ View
                                            </a>
                                            <a href="edit_student.php?id=<?php echo $student['id']; ?>" class="action-btn btn-edit" title="Edit Student">
                                                ✏️ Edit
                                            </a>
                                            <a href="hostel_students.php?delete_id=<?php echo $student['id']; ?>"
                                                class="action-btn btn-delete"
                                                onclick="return confirm('Are you sure you want to delete this student? This action cannot be undone.')"
                                                title="Delete Student">
                                                🗑️ Delete
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6">
                                    <div class="empty-state">
                                        <div class="empty-icon">👥</div>
                                        <div class="empty-title">No Students Found</div>
                                        <div class="empty-text">Start by adding your first student to the system</div>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Live Search Functionality
        const searchInput = document.getElementById('searchInput');
        const statusFilter = document.getElementById('statusFilter');
        const roomFilter = document.getElementById('roomFilter');
        const tableRows = document.querySelectorAll('.student-row');

        function filterTable() {
            const searchTerm = searchInput.value.toLowerCase();
            const statusValue = statusFilter.value;
            const roomValue = roomFilter.value;

            tableRows.forEach(row => {
                const name = row.dataset.name;
                const email = row.dataset.email;
                const roll = row.dataset.roll;
                const status = row.dataset.status;
                const room = row.dataset.room;

                const matchesSearch = name.includes(searchTerm) ||
                    email.includes(searchTerm) ||
                    roll.includes(searchTerm);

                const matchesStatus = !statusValue || status === statusValue;
                const matchesRoom = !roomValue || room === roomValue;

                if (matchesSearch && matchesStatus && matchesRoom) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        searchInput.addEventListener('input', filterTable);
        statusFilter.addEventListener('change', filterTable);
        roomFilter.addEventListener('change', filterTable);

        // Add animation on load
        document.addEventListener('DOMContentLoaded', function() {
            const rows = document.querySelectorAll('.student-row');
            rows.forEach((row, index) => {
                setTimeout(() => {
                    row.style.animation = 'fadeInUp 0.3s ease-out forwards';
                }, index * 50);
            });
        });
    </script>

    <?php include '../includes/footer.php'; ?>
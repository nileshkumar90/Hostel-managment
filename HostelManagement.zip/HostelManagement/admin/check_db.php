<?php
require_once '../includes/config.php';
$result = $conn->query("SHOW COLUMNS FROM developer_info LIKE 'cv_file'");
if ($result->num_rows == 0) {
    echo "Column does not exist";
} else {
    echo "Column exists";
}

<?php
require_once '../includes/config.php';
requireAdminLogin();

echo "<!DOCTYPE html><html><head><title>Add Payment Status Column</title></head><body>";
echo "<h2>Adding payment_status Column to Fees Table</h2>";

// Add payment_status column
$sql = "ALTER TABLE fees ADD COLUMN payment_status ENUM('Not Paid', 'Pending Verification', 'Verified', 'Rejected') DEFAULT 'Not Paid' AFTER status";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green;'>✓ Column 'payment_status' added successfully!</p>";

    // Update existing paid records to 'Verified' status
    $update_sql = "UPDATE fees SET payment_status = 'Verified' WHERE status = 'Paid'";
    if ($conn->query($update_sql) === TRUE) {
        $affected = $conn->affected_rows;
        echo "<p style='color: green;'>✓ Updated $affected existing paid records to 'Verified' status</p>";
    } else {
        echo "<p style='color: orange;'>⚠ Warning: Could not update existing records: " . $conn->error . "</p>";
    }

    echo "<p><strong>Migration completed successfully!</strong></p>";
    echo "<p><a href='fees.php'>Go to Fees Management</a></p>";
} else {
    if (strpos($conn->error, "Duplicate column name") !== false) {
        echo "<p style='color: orange;'>⚠ Column 'payment_status' already exists. Skipping...</p>";
        echo "<p><a href='fees.php'>Go to Fees Management</a></p>";
    } else {
        echo "<p style='color: red;'>✗ Error: " . $conn->error . "</p>";
    }
}

echo "</body></html>";

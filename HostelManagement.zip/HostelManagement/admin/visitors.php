<?php
require_once '../includes/config.php';
requireAdminLogin();

$page_title = 'Visitor Log';

// Handle visitor checkout
if (isset($_GET['checkout'])) {
    $id = (int)$_GET['checkout'];
    $conn->query("UPDATE visitors SET out_time = NOW() WHERE id = $id");
    $success = "Visitor checked out successfully!";
}

// Get filter
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'today';

// Build query based on filter
$sql = "SELECT v.*, s.name as student_name, s.roll_number, r.room_number, r.block 
        FROM visitors v 
        JOIN students s ON v.student_id = s.id 
        LEFT JOIN rooms r ON s.room_id = r.id 
        WHERE 1=1";

switch ($filter) {
    case 'today':
        $sql .= " AND v.visit_date = CURDATE()";
        break;
    case 'active':
        $sql .= " AND v.out_time IS NULL";
        break;
    case 'week':
        $sql .= " AND v.visit_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
        break;
}

$sql .= " ORDER BY v.visit_date DESC, v.in_time DESC";
$visitors = $conn->query($sql);

// Get statistics
$today_visitors = $conn->query("SELECT COUNT(*) as count FROM visitors WHERE visit_date = CURDATE()")->fetch_assoc()['count'];
$active_visitors = $conn->query("SELECT COUNT(*) as count FROM visitors WHERE out_time IS NULL")->fetch_assoc()['count'];
$total_today = $conn->query("SELECT COUNT(*) as count FROM visitors WHERE visit_date = CURDATE()")->fetch_assoc()['count'];

include '../includes/header.php';
include '../includes/admin-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            Visitor Log
        </h1>
        <p style="color: var(--color-gray-600);">Track and manage hostel visitors</p>
    </div>

    <?php if (isset($success)): ?>
        <div class="alert alert-success" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✓</span>
            <div class="alert-content"><?php echo $success; ?></div>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-2xl);">
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-primary-light);">👥</div>
            <div class="stat-details">
                <div class="stat-label">Today's Visitors</div>
                <div class="stat-value"><?php echo $today_visitors; ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-success-light);">🟢</div>
            <div class="stat-details">
                <div class="stat-label">Currently In Hostel</div>
                <div class="stat-value"><?php echo $active_visitors; ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-info-light);">📊</div>
            <div class="stat-details">
                <div class="stat-label">Total Today</div>
                <div class="stat-value"><?php echo $total_today; ?></div>
            </div>
        </div>
    </div>

    <!-- Filter Tabs -->
    <div style="display: flex; gap: var(--space-md); margin-bottom: var(--space-2xl); flex-wrap: wrap;">
        <a href="?filter=today" class="btn <?php echo ($filter == 'today') ? 'btn-primary' : 'btn-secondary'; ?>">
            Today's Visitors
        </a>
        <a href="?filter=active" class="btn <?php echo ($filter == 'active') ? 'btn-success' : 'btn-secondary'; ?>">
            Currently In Hostel
        </a>
        <a href="?filter=week" class="btn <?php echo ($filter == 'week') ? 'btn-info' : 'btn-secondary'; ?>">
            Last 7 Days
        </a>
        <a href="?filter=all" class="btn <?php echo ($filter == 'all') ? 'btn-warning' : 'btn-secondary'; ?>">
            All Visitors
        </a>
    </div>

    <!-- Visitors Table -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Visitor Records</h2>
        </div>
        <div class="card-body">
            <?php if ($visitors->num_rows > 0): ?>
                <div style="overflow-x: auto;">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Visitor Name</th>
                                <th>Contact</th>
                                <th>Student</th>
                                <th>Room</th>
                                <th>Purpose</th>
                                <th>Check In</th>
                                <th>Check Out</th>
                                <th>Duration</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($visitor = $visitors->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($visitor['visitor_name']); ?></strong>
                                        <?php if (!$visitor['out_time']): ?>
                                            <span class="badge badge-success" style="margin-left: var(--space-xs);">Active</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($visitor['visitor_phone']); ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($visitor['student_name']); ?><br>
                                        <small style="color: var(--color-gray-600);"><?php echo htmlspecialchars($visitor['roll_number']); ?></small>
                                    </td>
                                    <td>
                                        <?php if ($visitor['room_number']): ?>
                                            <?php echo $visitor['block'] . '-' . $visitor['room_number']; ?>
                                        <?php else: ?>
                                            <span style="color: var(--color-gray-500);">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($visitor['purpose']); ?></td>
                                    <td>
                                        <div style="font-size: var(--text-sm);">
                                            <?php echo date('d M Y', strtotime($visitor['visit_date'])); ?><br>
                                            <span style="color: var(--color-gray-600);"><?php echo date('h:i A', strtotime($visitor['in_time'])); ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ($visitor['out_time']): ?>
                                            <div style="font-size: var(--text-sm);">
                                                <?php echo date('d M Y', strtotime($visitor['visit_date'])); ?><br>
                                                <span style="color: var(--color-gray-600);"><?php echo date('h:i A', strtotime($visitor['out_time'])); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <span class="badge badge-warning">In Hostel</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        $checkin = new DateTime($visitor['visit_date'] . ' ' . $visitor['in_time']);
                                        if ($visitor['out_time']) {
                                            $checkout = new DateTime($visitor['visit_date'] . ' ' . $visitor['out_time']);
                                        } else {
                                            $checkout = new DateTime();
                                        }
                                        $interval = $checkin->diff($checkout);

                                        if ($interval->days > 0) {
                                            echo $interval->days . 'd ' . $interval->h . 'h';
                                        } else {
                                            echo $interval->h . 'h ' . $interval->i . 'm';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php if (!$visitor['out_time']): ?>
                                            <a href="?checkout=<?php echo $visitor['id']; ?>&filter=<?php echo $filter; ?>" class="btn btn-sm btn-primary" onclick="return confirm('Check out this visitor?');">
                                                Check Out
                                            </a>
                                        <?php else: ?>
                                            <span style="color: var(--color-gray-500);">Completed</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div style="padding: var(--space-3xl); text-align: center; color: var(--color-gray-500);">
                    <div style="font-size: 4rem; margin-bottom: var(--space-lg);">👥</div>
                    <h3>No Visitors Found</h3>
                    <p>No visitor records match your filter criteria.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
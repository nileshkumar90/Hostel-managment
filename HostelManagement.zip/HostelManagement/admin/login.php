    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    $query = "SELECT * FROM admin WHERE username='$username'";
    $res = $conn->query($query);

    if ($res->num_rows === 1) {
    $row = $res->fetch_assoc();
    if (password_verify($password, $row['password'])) {
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['admin_id'] = $row['id'];
    $_SESSION['admin_username'] = $row['username'];
    header("Location: manage_students.php");
    exit();
    } else {
    $error = "Invalid password";
    }
    } else {
    $error = "Admin not found";
    }
    }

    $page_title = 'Admin Login';
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $page_title; ?> - HMS</title>

        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            :root {
                --color-primary: #667eea;
                --color-primary-dark: #5a67d8;
                --color-white: #ffffff;
                --color-gray-50: #f9fafb;
                --color-gray-100: #f3f4f6;
                --color-gray-600: #4b5563;
                --color-gray-900: #111827;
                --color-error: #ef4444;
                --color-error-light: #fee2e2;
                --radius-lg: 12px;
                --radius-xl: 16px;
                --radius-2xl: 24px;
                --radius-full: 9999px;
                --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
                --shadow-2xl: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
                --shadow-glow: 0 0 30px rgba(102, 126, 234, 0.4);
                --gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                --transition-base: 0.3s ease;
            }

            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: var(--gradient-primary);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
                position: relative;
                overflow: hidden;
            }

            /* Animated Background */
            body::before {
                content: '';
                position: absolute;
                top: -50%;
                right: -50%;
                width: 200%;
                height: 200%;
                background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 1px, transparent 1px);
                background-size: 50px 50px;
                animation: moveBackground 20s linear infinite;
            }

            @keyframes moveBackground {
                0% {
                    transform: translate(0, 0);
                }

                100% {
                    transform: translate(50px, 50px);
                }
            }

            .login-container {
                width: 100%;
                max-width: 450px;
                position: relative;
                z-index: 1;
            }

            .back-link {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                color: var(--color-white);
                text-decoration: none;
                margin-bottom: 24px;
                font-weight: 500;
                transition: gap var(--transition-base);
                text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            }

            .back-link:hover {
                gap: 12px;
            }

            .login-card {
                background: var(--color-white);
                border-radius: var(--radius-2xl);
                box-shadow: var(--shadow-2xl);
                overflow: hidden;
                animation: slideUp 0.5s ease-out;
            }

            @keyframes slideUp {
                from {
                    opacity: 0;
                    transform: translateY(30px);
                }

                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .login-header {
                background: var(--gradient-primary);
                padding: 48px 32px;
                text-align: center;
                position: relative;
                overflow: hidden;
            }

            .login-header::before {
                content: '';
                position: absolute;
                top: -50%;
                right: -50%;
                width: 200%;
                height: 200%;
                background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
                animation: pulse 3s ease-in-out infinite;
            }

            @keyframes pulse {

                0%,
                100% {
                    transform: scale(1);
                    opacity: 1;
                }

                50% {
                    transform: scale(1.1);
                    opacity: 0.8;
                }
            }

            .login-icon {
                width: 80px;
                height: 80px;
                background: rgba(255, 255, 255, 0.2);
                backdrop-filter: blur(10px);
                border-radius: var(--radius-full);
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 0 auto 20px;
                font-size: 40px;
                position: relative;
                z-index: 1;
            }

            .login-title {
                font-size: 32px;
                font-weight: 800;
                color: var(--color-white);
                margin-bottom: 8px;
                position: relative;
                z-index: 1;
            }

            .login-subtitle {
                font-size: 16px;
                color: rgba(255, 255, 255, 0.95);
                position: relative;
                z-index: 1;
            }

            .login-body {
                padding: 40px 32px;
            }

            .form-group {
                margin-bottom: 24px;
            }

            .form-label {
                display: block;
                font-size: 14px;
                font-weight: 600;
                color: var(--color-gray-900);
                margin-bottom: 8px;
            }

            .form-input {
                width: 100%;
                padding: 14px 16px;
                border: 2px solid var(--color-gray-100);
                border-radius: var(--radius-lg);
                font-size: 16px;
                transition: all var(--transition-base);
            }

            .form-input:focus {
                outline: none;
                border-color: var(--color-primary);
                box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            }

            .error-message {
                background: var(--color-error-light);
                color: var(--color-error);
                padding: 12px 16px;
                border-radius: var(--radius-lg);
                margin-bottom: 20px;
                display: flex;
                align-items: center;
                gap: 8px;
                font-size: 14px;
                animation: shake 0.4s ease-in-out;
            }

            @keyframes shake {

                0%,
                100% {
                    transform: translateX(0);
                }

                25% {
                    transform: translateX(-10px);
                }

                75% {
                    transform: translateX(10px);
                }
            }

            .btn-login {
                width: 100%;
                padding: 16px;
                background: var(--gradient-primary);
                color: var(--color-white);
                border: none;
                border-radius: var(--radius-lg);
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                transition: all var(--transition-base);
                box-shadow: var(--shadow-lg);
                position: relative;
                overflow: hidden;
            }

            .btn-login::before {
                content: '';
                position: absolute;
                top: 50%;
                left: 50%;
                width: 0;
                height: 0;
                border-radius: var(--radius-full);
                background: rgba(255, 255, 255, 0.2);
                transform: translate(-50%, -50%);
                transition: width 0.6s, height 0.6s;
            }

            .btn-login:hover::before {
                width: 300px;
                height: 300px;
            }

            .btn-login:hover {
                box-shadow: var(--shadow-2xl), var(--shadow-glow);
                transform: translateY(-2px);
            }

            .btn-login:active {
                transform: translateY(0);
            }

            .btn-text {
                position: relative;
                z-index: 1;
            }

            .login-footer {
                text-align: center;
                margin-top: 24px;
                padding-top: 24px;
                border-top: 1px solid var(--color-gray-100);
            }

            .login-footer p {
                color: var(--color-gray-600);
                font-size: 14px;
            }

            .login-footer a {
                color: var(--color-primary);
                text-decoration: none;
                font-weight: 600;
                transition: color var(--transition-base);
            }

            .login-footer a:hover {
                color: var(--color-primary-dark);
                text-decoration: underline;
            }

            /* Info Box */
            .info-box {
                background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
                color: var(--color-white);
                padding: 16px;
                border-radius: var(--radius-lg);
                margin-bottom: 24px;
                font-size: 14px;
                display: flex;
                align-items: start;
                gap: 12px;
            }

            .info-icon {
                font-size: 20px;
                flex-shrink: 0;
            }

            /* Responsive */
            @media (max-width: 480px) {
                .login-header {
                    padding: 32px 24px;
                }

                .login-body {
                    padding: 32px 24px;
                }

                .login-title {
                    font-size: 24px;
                }
            }
        </style>
    </head>

    <body>
        <div class="login-container">
            <a href="../index.php" class="back-link">← Back to Home</a>

            <div class="login-card">
                <div class="login-header">
                    <div class="login-icon">🔐</div>
                    <h1 class="login-title">Admin Login</h1>
                    <p class="login-subtitle">Access the hostel management system</p>
                </div>

                <div class="login-body">
                    <?php if ($error): ?>
                        <div class="error-message">
                            <span>⚠️</span>
                            <span><?php echo htmlspecialchars($error); ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="info-box">
                        <span class="info-icon">ℹ️</span>
                        <div>
                            <strong>For Testing:</strong><br>
                            Username: admin<br>
                            Password: admin123
                        </div>
                    </div>

                    <form method="POST" action="">
                        <div class="form-group">
                            <label class="form-label">Username</label>
                            <input
                                type="text"
                                name="username"
                                class="form-input"
                                placeholder="Enter your username"
                                required
                                autofocus>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Password</label>
                            <input
                                type="password"
                                name="password"
                                class="form-input"
                                placeholder="Enter your password"
                                required>
                        </div>

                        <button type="submit" class="btn-login">
                            <span class="btn-text">Login to Dashboard</span>
                        </button>
                    </form>

                    <div class="login-footer">
                        <p>
                            Looking for student login? <a href="../login.php">Click here</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <script>
            // Add ripple effect on button click
            document.querySelector('.btn-login').addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                ripple.style.position = 'absolute';
                ripple.style.borderRadius = '50%';
                ripple.style.background = 'rgba(255, 255, 255, 0.6)';
                ripple.style.width = ripple.style.height = '100px';
                ripple.style.left = e.offsetX - 50 + 'px';
                ripple.style.top = e.offsetY - 50 + 'px';
                ripple.style.animation = 'ripple 0.6s';
                ripple.style.pointerEvents = 'none';

                this.appendChild(ripple);

                setTimeout(() => ripple.remove(), 600);
            });

            // Auto focus on input
            document.addEventListener('DOMContentLoaded', function() {
                const firstInput = document.querySelector('input[name="username"]');
                if (firstInput) {
                    firstInput.focus();
                }
            });
        </script>
    </body>

    </html>
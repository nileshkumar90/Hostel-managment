<?php
require_once '../includes/config.php';
requireAdminLogin();

$page_title = 'Mess Menu Management';

// Handle Menu Update/Create
if (isset($_POST['save_menu'])) {
    $day = sanitize($_POST['day_of_week']);
    $meal = sanitize($_POST['meal_type']);
    $items = sanitize($_POST['menu_items']);
    $admin_id = $_SESSION['admin_id'];

    // Check if exists
    $check = $conn->query("SELECT id FROM mess_menu WHERE day_of_week = '$day' AND meal_type = '$meal'");

    if ($check->num_rows > 0) {
        $id = $check->fetch_assoc()['id'];
        $stmt = $conn->prepare("UPDATE mess_menu SET menu_items = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("si", $items, $id);
    } else {
        $stmt = $conn->prepare("INSERT INTO mess_menu (day_of_week, meal_type, menu_items, created_by) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $day, $meal, $items, $admin_id);
    }

    if ($stmt->execute()) {
        $success = "Menu updated successfully!";
    } else {
        $error = "Error updating menu.";
    }
}

// Fetch current menu
$menu_data = [];
$result = $conn->query("SELECT * FROM mess_menu WHERE is_active = 1");
while ($row = $result->fetch_assoc()) {
    $menu_data[$row['day_of_week']][$row['meal_type']] = $row['menu_items'];
}

$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
$meals = ['Breakfast', 'Lunch', 'Snacks', 'Dinner'];

include '../includes/header.php';
include '../includes/admin-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            Mess Menu
        </h1>
        <p style="color: var(--color-gray-600);">Manage weekly food menu</p>
    </div>

    <?php if (isset($success)): ?>
        <div class="alert alert-success" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✓</span>
            <div class="alert-content"><?php echo $success; ?></div>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
            <h2 class="card-title">Weekly Schedule</h2>
            <button onclick="openModal('edit-menu')" class="btn btn-primary">
                ✏️ Edit Menu
            </button>
        </div>
        <div class="card-body">
            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Day</th>
                            <th>Breakfast</th>
                            <th>Lunch</th>
                            <th>Snacks</th>
                            <th>Dinner</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($days as $day): ?>
                            <tr>
                                <td style="font-weight: bold; color: var(--color-primary);"><?php echo $day; ?></td>
                                <?php foreach ($meals as $meal): ?>
                                    <td>
                                        <?php
                                        echo isset($menu_data[$day][$meal])
                                            ? htmlspecialchars($menu_data[$day][$meal])
                                            : '<span style="color: var(--color-gray-400); font-style: italic;">Not set</span>';
                                        ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Edit Menu Modal -->
<div id="edit-menu" class="modal">
    <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
            <h2>Update Menu Item</h2>
            <button onclick="closeModal('edit-menu')" class="modal-close">×</button>
        </div>
        <form method="POST">
            <div style="padding: var(--space-xl); display: grid; gap: var(--space-lg);">
                <div class="form-group">
                    <label class="form-label">Day of Week</label>
                    <select name="day_of_week" class="form-select" required>
                        <?php foreach ($days as $day): ?>
                            <option value="<?php echo $day; ?>"><?php echo $day; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Meal Type</label>
                    <select name="meal_type" class="form-select" required>
                        <?php foreach ($meals as $meal): ?>
                            <option value="<?php echo $meal; ?>"><?php echo $meal; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Menu Items</label>
                    <textarea name="menu_items" class="form-textarea" rows="4" placeholder="e.g., Aloo Paratha, Curd, Pickle" required></textarea>
                </div>
            </div>
            <div style="padding: 0 var(--space-xl) var(--space-xl); text-align: right;">
                <button type="submit" name="save_menu" class="btn btn-primary">Save Item</button>
            </div>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
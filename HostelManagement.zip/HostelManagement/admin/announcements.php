<?php
require_once '../includes/config.php';
requireAdminLogin();

$page_title = 'Manage Announcements';

// Handle announcement creation
if (isset($_POST['create_announcement'])) {
    $title = sanitize($_POST['title']);
    $content = sanitize($_POST['content']);
    $category = sanitize($_POST['category']);
    $priority = sanitize($_POST['priority']);
    $expires_at = !empty($_POST['expires_at']) ? sanitize($_POST['expires_at']) : NULL;

    $sql = "INSERT INTO announcements (title, content, category, priority, created_by, expires_at) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssiss", $title, $content, $category, $priority, $_SESSION['admin_id'], $expires_at);

    if ($stmt->execute()) {
        $success = "Announcement created successfully!";
    }
}

// Handle announcement deletion
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM announcements WHERE id = $id");
    $success = "Announcement deleted successfully!";
}

// Handle toggle active status
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $conn->query("UPDATE announcements SET is_active = NOT is_active WHERE id = $id");
    $success = "Announcement status updated!";
}

// Get allannouncements
$announcements = $conn->query("SELECT a.*, ad.username as created_by_name FROM announcements a JOIN admin ad ON a.created_by = ad.id ORDER BY a.created_at DESC");

include '../includes/header.php';
include '../includes/admin-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            Announcements
        </h1>
        <p style="color: var(--color-gray-600);">Create and manage hostel announcements</p>
    </div>

    <?php if (isset($success)): ?>
        <div class="alert alert-success" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✓</span>
            <div class="alert-content"><?php echo $success; ?></div>
        </div>
    <?php endif; ?>

    <!-- Create Announcement Form -->
    <div class="card" style="margin-bottom: var(--space-2xl);">
        <div class="card-header">
            <h2 class="card-title">📢 Create New Announcement</h2>
        </div>
        <div class="card-body">
            <form method="POST">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: var(--space-lg);">
                    <div class="form-group">
                        <label class="form-label required">Title</label>
                        <input type="text" name="title" class="form-input" placeholder="Announcement title" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label required">Category</label>
                        <select name="category" class="form-select" required>
                            <option value="General">General</option>
                            <option value="Emergency">Emergency</option>
                            <option value="Event">Event</option>
                            <option value="Maintenance">Maintenance</option>
                            <option value="Fee">Fee</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label required">Priority</label>
                        <select name="priority" class="form-select" required>
                            <option value="Low">Low</option>
                            <option value="Medium" selected>Medium</option>
                            <option value="High">High</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Expires At</label>
                        <input type="date" name="expires_at" class="form-input">
                        <span class="form-helper">Leave empty for no expiration</span>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label required">Content</label>
                    <textarea name="content" class="form-textarea" rows="5" placeholder="Announcement content..." required></textarea>
                </div>

                <button type="submit" name="create_announcement" class="btn btn-primary">
                    📢 Post Announcement
                </button>
            </form>
        </div>
    </div>

    <!-- Announcements List -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">All Announcements</h2>
        </div>
        <div class="card-body">
            <?php if ($announcements->num_rows > 0): ?>
                <div style="display: grid; gap: var(--space-lg);">
                    <?php while ($announcement = $announcements->fetch_assoc()): ?>
                        <div style="padding: var(--space-xl); border: 2px solid var(--color-gray-200); border-radius: var(--radius-xl); <?php echo !$announcement['is_active'] ? 'opacity: 0.6;' : ''; ?>">
                            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: var(--space-md);">
                                <div style="flex: 1;">
                                    <div style="display: flex; gap: var(--space-md); align-items: center; margin-bottom: var(--space-sm);">
                                        <h3 style="font-size: var(--text-xl); font-weight: var(--font-bold); margin: 0;">
                                            <?php echo htmlspecialchars($announcement['title']); ?>
                                        </h3>
                                        <span class="badge <?php echo $announcement['is_active'] ? 'badge-success' : 'badge-error'; ?>">
                                            <?php echo $announcement['is_active'] ? 'Active' : 'Inactive'; ?>
                                        </span>
                                        <span class="badge <?php
                                                            echo match ($announcement['priority']) {
                                                                'High' => 'badge-error',
                                                                'Medium' => 'badge-warning',
                                                                default => 'badge-info'
                                                            };
                                                            ?>">
                                            <?php echo $announcement['priority']; ?>
                                        </span>
                                        <span class="badge badge-primary">
                                            <?php echo $announcement['category']; ?>
                                        </span>
                                    </div>
                                    <div style="font-size: var(--text-sm); color: var(--color-gray-600);">
                                        Posted by: <?php echo htmlspecialchars($announcement['created_by_name']); ?> •
                                        <?php echo formatDateTime($announcement['created_at']); ?>
                                        <?php if ($announcement['expires_at']): ?>
                                            • Expires: <?php echo formatDate($announcement['expires_at']); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div style="display: flex; gap: var(--space-sm);">
                                    <a href="?toggle=<?php echo $announcement['id']; ?>" class="btn btn-sm btn-secondary">
                                        <?php echo $announcement['is_active'] ? 'Deactivate' : 'Activate'; ?>
                                    </a>
                                    <a href="?delete=<?php echo $announcement['id']; ?>" class="btn btn-sm btn-error" onclick="return confirm('Are you sure you want to delete this announcement?');">
                                        Delete
                                    </a>
                                </div>
                            </div>

                            <div style="background: var(--color-gray-50); padding: var(--space-lg); border-radius: var(--radius-lg);">
                                <?php echo nl2br(htmlspecialchars($announcement['content'])); ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div style="padding: var(--space-3xl); text-align: center; color: var(--color-gray-500);">
                    <div style="font-size: 4rem; margin-bottom: var(--space-lg);">📢</div>
                    <h3>No Announcements Yet</h3>
                    <p>Create your first announcement using the form above.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
<?php
require_once '../includes/config.php';
requireAdminLogin();

$page_title = 'Manage Students';

// Handle deletion
if (isset($_GET['delete_id'])) {
    $student_id = (int)$_GET['delete_id'];

    // Get student's room_id
    $res = $conn->query("SELECT room_id FROM students WHERE id=$student_id");
    if ($res->num_rows === 1) {
        $row = $res->fetch_assoc();
        $room_id = $row['room_id'];

        // Delete student
        $conn->query("DELETE FROM students WHERE id=$student_id");

        // Decrease room occupancy and update status
        if ($room_id) {
            $conn->query("UPDATE rooms SET occupied = occupied - 1 WHERE id=$room_id");

            // Check if room should be set to Available
            $check_room = $conn->query("SELECT occupied, capacity, status FROM rooms WHERE id=$room_id");
            if ($check_room && $row = $check_room->fetch_assoc()) {
                if ($row['occupied'] < $row['capacity'] && $row['status'] != 'Maintenance') {
                    $conn->query("UPDATE rooms SET status = 'Available' WHERE id=$room_id");
                }
            }
        }
    }

    // Redirect to avoid resubmission
    header("Location: students.php");
    exit();
}

// Fetch students with room booking
$res = $conn->query("
    SELECT students.*, rooms.room_number, rooms.block, rooms.floor
    FROM students 
    LEFT JOIN rooms ON students.room_id = rooms.id
    ORDER BY students.id DESC
");

// Get statistics
$total_students = $conn->query("SELECT COUNT(*) as count FROM students")->fetch_assoc()['count'];
$active_students = $conn->query("SELECT COUNT(*) as count FROM students WHERE is_active = 1")->fetch_assoc()['count'];
$students_with_rooms = $conn->query("SELECT COUNT(*) as count FROM students WHERE room_id IS NOT NULL")->fetch_assoc()['count'];

include '../includes/header.php';
include '../includes/admin-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <!-- Page Header -->
    <div style="margin-bottom: var(--space-2xl);">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: var(--space-md);">
            <div>
                <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
                    👥 Manage Students
                </h1>
                <p style="color: var(--color-gray-600);">View and manage all registered students</p>
            </div>
            <div style="display: flex; gap: var(--space-md);">
                <a href="../register.php" class="btn btn-primary">
                    ➕ Add New Student
                </a>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-2xl);">
        <div class="stat-card animate-fadeInUp">
            <div class="stat-icon" style="background: var(--color-primary-light);">👨‍🎓</div>
            <div class="stat-details">
                <div class="stat-label">Total Students</div>
                <div class="stat-value"><?php echo $total_students; ?></div>
            </div>
        </div>

        <div class="stat-card animate-fadeInUp" style="animation-delay: 0.1s;">
            <div class="stat-icon" style="background: var(--color-success-light);">✅</div>
            <div class="stat-details">
                <div class="stat-label">Active Students</div>
                <div class="stat-value"><?php echo $active_students; ?></div>
            </div>
        </div>

        <div class="stat-card animate-fadeInUp" style="animation-delay: 0.2s;">
            <div class="stat-icon" style="background: var(--color-warning-light);">🏠</div>
            <div class="stat-details">
                <div class="stat-label">With Rooms</div>
                <div class="stat-value"><?php echo $students_with_rooms; ?></div>
            </div>
        </div>
    </div>

    <!-- Search and Filter Section -->
    <div class="card" style="margin-bottom: var(--space-xl);">
        <div class="card-body">
            <div style="display: flex; gap: var(--space-md); flex-wrap: wrap; align-items: center;">
                <div style="flex: 1; min-width: 300px; position: relative;">
                    <span style="position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: var(--color-gray-400);">🔍</span>
                    <input type="text" id="searchInput" class="form-input" style="padding-left: 45px;" placeholder="Search by name, email, roll number...">
                </div>

                <select id="statusFilter" class="form-select" style="width: auto;">
                    <option value="">All Status</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>

                <select id="roomFilter" class="form-select" style="width: auto;">
                    <option value="">All Rooms</option>
                    <option value="with-room">With Room</option>
                    <option value="no-room">No Room</option>
                </select>
            </div>
        </div>
    </div>

    <!-- Students Table -->
    <div class="card">
        <div class="card-body" style="padding: 0;">
            <div style="overflow-x: auto;">
                <table class="table" id="studentsTable">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Contact</th>
                            <th>Branch</th>
                            <th>Room</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody">
                        <?php if ($res->num_rows > 0): ?>
                            <?php while ($student = $res->fetch_assoc()): ?>
                                <tr class="student-row"
                                    data-name="<?php echo strtolower($student['name']); ?>"
                                    data-email="<?php echo strtolower($student['email']); ?>"
                                    data-roll="<?php echo strtolower($student['roll_number']); ?>"
                                    data-status="<?php echo $student['is_active'] ? 'active' : 'inactive'; ?>"
                                    data-room="<?php echo $student['room_id'] ? 'with-room' : 'no-room'; ?>">
                                    <td>
                                        <div style="display: flex; align-items: center; gap: var(--space-md);">
                                            <div style="width: 40px; height: 40px; border-radius: var(--radius-full); background: var(--gradient-primary); color: white; display: flex; align-items: center; justify-content: center; font-weight: bold;">
                                                <?php if (!empty($student['profile_image']) && file_exists('../' . $student['profile_image'])): ?>
                                                    <img src="../<?php echo htmlspecialchars($student['profile_image']); ?>" style="width: 100%; height: 100%; border-radius: var(--radius-full); object-fit: cover;">
                                                <?php else: ?>
                                                    <?php echo strtoupper(substr($student['name'], 0, 1)); ?>
                                                <?php endif; ?>
                                            </div>
                                            <div>
                                                <div style="font-weight: var(--font-semibold); color: var(--color-gray-900);"><?php echo htmlspecialchars($student['name']); ?></div>
                                                <div style="font-size: var(--text-sm); color: var(--color-gray-500);"><?php echo htmlspecialchars($student['roll_number']); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div><?php echo htmlspecialchars($student['email']); ?></div>
                                        <div style="font-size: var(--text-sm); color: var(--color-gray-500); margin-top: 4px;">
                                            <?php echo htmlspecialchars($student['phone']); ?>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($student['branch']); ?></td>
                                    <td>
                                        <?php if ($student['room_number']): ?>
                                            <span class="badge badge-primary">
                                                🏠 <?php echo htmlspecialchars($student['room_number']); ?> - <?php echo htmlspecialchars($student['block']); ?>
                                            </span>
                                        <?php else: ?>
                                            <span style="color: var(--color-gray-400); font-style: italic;">Not Assigned</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $student['is_active'] ? 'badge-success' : 'badge-error'; ?>">
                                            <?php echo $student['is_active'] ? 'Active' : 'Inactive'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div style="display: flex; gap: var(--space-xs);">
                                            <a href="../view_student.php?id=<?php echo $student['id']; ?>" class="btn btn-sm btn-secondary" title="View Details">
                                                👁️ View
                                            </a>
                                            <a href="../edit_student.php?id=<?php echo $student['id']; ?>" class="btn btn-sm btn-secondary" title="Edit Student">
                                                ✏️ Edit
                                            </a>
                                            <a href="students.php?delete_id=<?php echo $student['id']; ?>"
                                                class="btn btn-sm btn-error"
                                                onclick="return confirm('Are you sure you want to delete this student? This action cannot be undone.')"
                                                title="Delete Student">
                                                🗑️ Delete
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6">
                                    <div style="text-align: center; padding: var(--space-3xl); color: var(--color-gray-500);">
                                        <div style="font-size: 4rem; margin-bottom: var(--space-lg);">👥</div>
                                        <h3>No Students Found</h3>
                                        <p>Start by adding your first student to the system</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    // Live Search Functionality
    const searchInput = document.getElementById('searchInput');
    const statusFilter = document.getElementById('statusFilter');
    const roomFilter = document.getElementById('roomFilter');
    const tableRows = document.querySelectorAll('.student-row');

    function filterTable() {
        const searchTerm = searchInput.value.toLowerCase();
        const statusValue = statusFilter.value;
        const roomValue = roomFilter.value;

        tableRows.forEach(row => {
            const name = row.dataset.name;
            const email = row.dataset.email;
            const roll = row.dataset.roll;
            const status = row.dataset.status;
            const room = row.dataset.room;

            const matchesSearch = name.includes(searchTerm) ||
                email.includes(searchTerm) ||
                roll.includes(searchTerm);

            const matchesStatus = !statusValue || status === statusValue;
            const matchesRoom = !roomValue || room === roomValue;

            if (matchesSearch && matchesStatus && matchesRoom) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    searchInput.addEventListener('input', filterTable);
    statusFilter.addEventListener('change', filterTable);
    roomFilter.addEventListener('change', filterTable);
</script>

<?php include '../includes/footer.php'; ?>
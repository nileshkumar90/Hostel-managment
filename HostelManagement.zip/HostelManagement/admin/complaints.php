<?php
require_once '../includes/config.php';
requireAdminLogin();

$page_title = 'Manage Complaints';

// Handle status update
if (isset($_POST['update_status'])) {
    $complaint_id = (int)$_POST['complaint_id'];
    $status = sanitize($_POST['status']);
    $admin_notes = sanitize($_POST['admin_notes']);

    $sql = "UPDATE complaints SET status = ?, admin_notes = ?, updated_at = NOW()";
    $params = [$status, $admin_notes];

    if ($status == 'Resolved') {
        $sql .= ", resolved_at = NOW(), resolved_by = ?";
        $params[] = $_SESSION['admin_id'];
    }

    $sql .= " WHERE id = ?";
    $params[] = $complaint_id;

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(str_repeat('s', count($params) - 1) . 'i', ...$params);
    $stmt->execute();

    $success = "Complaint updated successfully!";
}

// Get all complaints
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$sql = "SELECT c.*, s.name as student_name, s.roll_number, r.room_number, r.block 
        FROM complaints c 
        JOIN students s ON c.student_id = s.id 
        LEFT JOIN rooms r ON s.room_id = r.id";

if ($filter != 'all') {
    $sql .= " WHERE c.status = '$filter'";
}

$sql .= " ORDER BY 
    CASE c.priority 
        WHEN 'Urgent' THEN 1
        WHEN 'High' THEN 2
        WHEN 'Medium' THEN 3
        ELSE 4
    END,
    c.created_at DESC";

$complaints = $conn->query($sql);

// Get counts for filters
$counts = [];
$counts['all'] = $conn->query("SELECT COUNT(*) as count FROM complaints")->fetch_assoc()['count'];
$counts['Pending'] = $conn->query("SELECT COUNT(*) as count FROM complaints WHERE status = 'Pending'")->fetch_assoc()['count'];
$counts['In Progress'] = $conn->query("SELECT COUNT(*) as count FROM complaints WHERE status = 'In Progress'")->fetch_assoc()['count'];
$counts['Resolved'] = $conn->query("SELECT COUNT(*) as count FROM complaints WHERE status = 'Resolved'")->fetch_assoc()['count'];

include '../includes/header.php';
include '../includes/admin-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            Complaint Management
        </h1>
        <p style="color: var(--color-gray-600);">View and manage all student complaints</p>
    </div>

    <?php if (isset($success)): ?>
        <div class="alert alert-success" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✓</span>
            <div class="alert-content"><?php echo $success; ?></div>
        </div>
    <?php endif; ?>

    <!-- Filter Tabs -->
    <div style="display: flex; gap: var(--space-md); margin-bottom: var(--space-2xl); flex-wrap: wrap;">
        <a href="?filter=all" class="btn <?php echo ($filter == 'all') ? 'btn-primary' : 'btn-secondary'; ?>">
            All (<?php echo $counts['all']; ?>)
        </a>
        <a href="?filter=Pending" class="btn <?php echo ($filter == 'Pending') ? 'btn-warning' : 'btn-secondary'; ?>">
            Pending (<?php echo $counts['Pending']; ?>)
        </a>
        <a href="?filter=In Progress" class="btn <?php echo ($filter == 'In Progress') ? 'btn-info' : 'btn-secondary'; ?>">
            In Progress (<?php echo $counts['In Progress']; ?>)
        </a>
        <a href="?filter=Resolved" class="btn <?php echo ($filter == 'Resolved') ? 'btn-success' : 'btn-secondary'; ?>">
            Resolved (<?php echo $counts['Resolved']; ?>)
        </a>
    </div>

    <!-- Complaints List -->
    <?php if ($complaints->num_rows > 0): ?>
        <div style="display: grid; gap: var(--space-lg);">
            <?php while ($complaint = $complaints->fetch_assoc()): ?>
                <div class="card">
                    <div style="padding: var(--space-xl);">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: var(--space-lg);">
                            <div style="flex: 1;">
                                <div style="display: flex; gap: var(--space-md); align-items: center; margin-bottom: var(--space-sm);">
                                    <h3 style="font-size: var(--text-xl); font-weight: var(--font-bold); margin: 0;">
                                        <?php echo htmlspecialchars($complaint['subject']); ?>
                                    </h3>
                                    <?php echo getStatusBadge($complaint['status']); ?>
                                    <span class="badge <?php
                                                        echo match ($complaint['priority']) {
                                                            'Urgent' => 'badge-error',
                                                            'High' => 'badge-warning',
                                                            'Medium' => 'badge-info',
                                                            default => 'badge-primary'
                                                        };
                                                        ?>">
                                        <?php echo $complaint['priority']; ?>
                                    </span>
                                </div>
                                <div style="font-size: var(--text-sm); color: var(--color-gray-600);">
                                    <strong><?php echo htmlspecialchars($complaint['student_name']); ?></strong>
                                    (<?php echo htmlspecialchars($complaint['roll_number']); ?>) •
                                    Room: <?php echo $complaint['room_number'] ? $complaint['block'] . '-' . $complaint['room_number'] : 'N/A'; ?> •
                                    Category: <?php echo $complaint['category']; ?> •
                                    Filed: <?php echo formatDateTime($complaint['created_at']); ?>
                                </div>
                            </div>
                        </div>

                        <div style="background: var(--color-gray-50); padding: var(--space-lg); border-radius: var(--radius-lg); margin-bottom: var(--space-lg);">
                            <div style="font-weight: var(--font-semibold); margin-bottom: var(--space-xs);">Description:</div>
                            <div style="color: var(--color-gray-700);">
                                <?php echo nl2br(htmlspecialchars($complaint['description'])); ?>
                            </div>
                        </div>

                        <?php if (!empty($complaint['admin_notes'] ?? '')): ?>
                            <div style="background: var(--color-info-light); padding: var(--space-lg); border-radius: var(--radius-lg); margin-bottom: var(--space-lg); border-left: 4px solid var(--color-info);">
                                <div style="font-weight: var(--font-semibold); margin-bottom: var(--space-xs);">Admin Notes:</div>
                                <div style="color: var(--color-gray-700);">
                                    <?php echo nl2br(htmlspecialchars($complaint['admin_notes'])); ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <details>
                            <summary style="cursor: pointer; font-weight: var(--font-semibold); padding: var(--space-sm); color: var(--color-primary);">
                                Update Complaint Status
                            </summary>
                            <form method="POST" style="margin-top: var(--space-lg); padding: var(--space-lg); background: var(--color-gray-50); border-radius: var(--radius-lg);">
                                <input type="hidden" name="complaint_id" value="<?php echo $complaint['id']; ?>">

                                <div class="form-group">
                                    <label class="form-label">Status</label>
                                    <select name="status" class="form-select" required>
                                        <option value="Pending" <?php echo ($complaint['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                        <option value="In Progress" <?php echo ($complaint['status'] == 'In Progress') ? 'selected' : ''; ?>>In Progress</option>
                                        <option value="Resolved" <?php echo ($complaint['status'] == 'Resolved') ? 'selected' : ''; ?>>Resolved</option>
                                        <option value="Closed" <?php echo ($complaint['status'] == 'Closed') ? 'selected' : ''; ?>>Closed</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Admin Notes</label>
                                    <textarea name="admin_notes" class="form-textarea" rows="3" placeholder="Add notes about this complaint..."><?php echo htmlspecialchars($complaint['admin_notes'] ?? ''); ?></textarea>
                                </div>

                                <button type="submit" name="update_status" class="btn btn-primary">
                                    Update Status
                                </button>
                            </form>
                        </details>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="card">
            <div style="padding: var(--space-3xl); text-align: center; color: var(--color-gray-500);">
                <div style="font-size: 4rem; margin-bottom: var(--space-lg);">📝</div>
                <h3>No Complaints Found</h3>
                <p>There are no complaints matching your filter criteria.</p>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
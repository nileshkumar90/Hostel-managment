<?php
require_once '../includes/config.php';
requireAdminLogin();

// Handle fee actions  
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'add_fee':
            $student_id = intval($_POST['student_id']);
            $amount = floatval($_POST['amount']);
            $fee_type = sanitize($_POST['fee_type']);
            $due_date = sanitize($_POST['due_date']);

            $stmt = $conn->prepare("INSERT INTO fees (student_id, amount, fee_type, due_date, status, created_at) VALUES (?, ?, ?, ?, 'Pending', NOW())");
            $stmt->bind_param("idss", $student_id, $amount, $fee_type, $due_date);
            $stmt->execute();
            header("Location: fees.php?success=added");
            exit();

        case 'update_fee':
            $fee_id = intval($_POST['fee_id']);
            $student_id = intval($_POST['student_id']);
            $amount = floatval($_POST['amount']);
            $fee_type = sanitize($_POST['fee_type']);
            $due_date = sanitize($_POST['due_date']);

            $stmt = $conn->prepare("UPDATE fees SET student_id = ?, amount = ?, fee_type = ?, due_date = ? WHERE id = ?");
            $stmt->bind_param("idssi", $student_id, $amount, $fee_type, $due_date, $fee_id);
            $stmt->execute();
            header("Location: fees.php?success=updated");
            exit();

        case 'mark_paid':
            $fee_id = intval($_POST['fee_id']);

            // First, get the student_id associated with this fee
            $fee_query = $conn->query("SELECT student_id FROM fees WHERE id = $fee_id");
            if ($fee_query && $fee_query->num_rows > 0) {
                $fee_data = $fee_query->fetch_assoc();
                $student_id = $fee_data['student_id'];

                // Update fee status
                $stmt = $conn->prepare("UPDATE fees SET status = 'Paid', payment_date = NOW() WHERE id = ?");
                $stmt->bind_param("i", $fee_id);
                $stmt->execute();

                // CHECK FOR PENDING ROOM ASSIGNMENT
                // If this student has a pending_room_id, assign it now
                $student_query = $conn->query("SELECT pending_room_id FROM students WHERE id = $student_id");
                if ($student_query && $student_query->num_rows > 0) {
                    $student_data = $student_query->fetch_assoc();
                    $pending_room_id = $student_data['pending_room_id'];

                    if ($pending_room_id) {
                        // 1. Assign room to student and clear pending
                        $assign_stmt = $conn->prepare("UPDATE students SET room_id = ?, pending_room_id = NULL WHERE id = ?");
                        $assign_stmt->bind_param("ii", $pending_room_id, $student_id);
                        $assign_stmt->execute();

                        // 2. Update room occupancy
                        $conn->query("UPDATE rooms SET occupied = occupied + 1 WHERE id = $pending_room_id");

                        // 3. Update room status if full
                        $conn->query("UPDATE rooms SET status = 'Occupied' WHERE id = $pending_room_id AND occupied >= capacity");
                    }
                }
                header("Location: fees.php?success=paid_and_assigned");
            } else {
                header("Location: fees.php?error=fee_not_found");
            }
            exit();

        case 'delete_fee':
            $fee_id = intval($_POST['fee_id']);
            $stmt = $conn->prepare("DELETE FROM fees WHERE id = ? AND status = 'Pending'");
            $stmt->bind_param("i", $fee_id);
            $stmt->execute();
            header("Location: fees.php?success=deleted");
            exit();

        case 'verify_payment':
            $fee_id = intval($_POST['fee_id']);
            $stmt = $conn->prepare("UPDATE fees SET status = 'Paid', payment_status = 'Verified', payment_date = NOW() WHERE id = ?");
            $stmt->bind_param("i", $fee_id);
            if ($stmt->execute()) {
                header("Location: fees.php?success=verified");
            } else {
                header("Location: fees.php?error=verify_failed");
            }
            exit();

        case 'reject_payment':
            $fee_id = intval($_POST['fee_id']);
            $stmt = $conn->prepare("UPDATE fees SET payment_status = 'Rejected', transaction_id = NULL, payment_method = NULL, payment_date = NULL, paid_amount = 0, status = 'Pending' WHERE id = ?");
            $stmt->bind_param("i", $fee_id);
            if ($stmt->execute()) {
                header("Location: fees.php?success=rejected");
            } else {
                header("Location: fees.php?error=reject_failed");
            }
            exit();
    }
}

// Get filters
$status_filter = $_GET['status'] ?? '';
$search = $_GET['search'] ?? '';

// Build query
$sql = "SELECT f.*, s.name as student_name, s.email, s.roll_number, s.profile_image 
        FROM fees f 
        JOIN students s ON f.student_id = s.id WHERE 1=1";

if ($status_filter) $sql .= " AND f.status = '" . $conn->real_escape_string($status_filter) . "'";
if ($search) $sql .= " AND (s.name LIKE '%" . $conn->real_escape_string($search) . "%' OR s.roll_number LIKE '%" . $conn->real_escape_string($search) . "%')";

$sql .= " ORDER BY f.created_at DESC";
$result = $conn->query($sql);

// Statistics
$total_fees = $conn->query("SELECT COUNT(*) as c FROM fees")->fetch_assoc()['c'];
$pending_fees = $conn->query("SELECT COUNT(*) as c FROM fees WHERE status = 'Pending'")->fetch_assoc()['c'];
$paid_fees = $conn->query("SELECT COUNT(*) as c FROM fees WHERE status = 'Paid'")->fetch_assoc()['c'];
$total_amount = $conn->query("SELECT COALESCE(SUM(amount), 0) as t FROM fees")->fetch_assoc()['t'];
$collected_amount = $conn->query("SELECT COALESCE(SUM(amount), 0) as t FROM fees WHERE status = 'Paid'")->fetch_assoc()['t'];

$students = $conn->query("SELECT id, name, roll_number FROM students ORDER BY name");
$students2 = $conn->query("SELECT id, name, roll_number FROM students ORDER BY name");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fee Management | Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4F46E5;
            --primary-hover: #4338ca;
            --success: #10B981;
            --warning: #F59E0B;
            --danger: #EF4444;
            --bg-body: #F3F4F6;
            --bg-card: #FFFFFF;
            --text-main: #111827;
            --text-muted: #6B7280;
            --border: #E5E7EB;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: var(--bg-body);
            color: var(--text-main);
            min-height: 100vh;
            padding-bottom: 40px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header */
        .page-header {
            background: linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%);
            padding: 40px 0 80px;
            margin-bottom: -40px;
            color: white;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-title {
            font-size: 28px;
            font-weight: 700;
        }

        .btn-add {
            background: white;
            color: var(--primary);
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }

        .btn-add:hover {
            transform: translateY(-2px);
        }

        /* Stats */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--bg-card);
            padding: 24px;
            border-radius: 16px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .stat-icon {
            width: 56px;
            height: 56px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .icon-blue {
            background: #E0E7FF;
            color: #4F46E5;
        }

        .icon-yellow {
            background: #FEF3C7;
            color: #D97706;
        }

        .icon-green {
            background: #D1FAE5;
            color: #059669;
        }

        .icon-purple {
            background: #EDE9FE;
            color: #7C3AED;
        }

        .stat-info h3 {
            font-size: 14px;
            color: var(--text-muted);
            font-weight: 500;
        }

        .stat-info p {
            font-size: 24px;
            font-weight: 700;
            margin-top: 4px;
        }

        /* Main Content */
        .content-card {
            background: var(--bg-card);
            border-radius: 16px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .filters {
            padding: 20px;
            border-bottom: 1px solid var(--border);
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
        }

        .search-wrapper {
            flex: 1;
            position: relative;
            min-width: 300px;
        }

        .search-input {
            width: 100%;
            padding: 12px 16px 12px 44px;
            border: 1px solid var(--border);
            border-radius: 10px;
            font-size: 14px;
            outline: none;
        }

        .search-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
        }

        .filter-select {
            padding: 12px 20px;
            border: 1px solid var(--border);
            border-radius: 10px;
            font-size: 14px;
            outline: none;
            background: white;
            cursor: pointer;
        }

        /* Table */
        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #F9FAFB;
            padding: 16px 24px;
            text-align: left;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--text-muted);
            letter-spacing: 0.05em;
        }

        td {
            padding: 16px 24px;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover {
            background: #F9FAFB;
        }

        .student-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .student-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #E0E7FF;
            color: #4F46E5;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 14px;
        }

        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .badge-pending {
            background: #FEF3C7;
            color: #92400E;
        }

        .badge-paid {
            background: #D1FAE5;
            color: #065F46;
        }

        .badge-overdue {
            background: #FEE2E2;
            color: #991B1B;
        }

        .actions {
            display: flex;
            gap: 8px;
        }

        .btn-icon {
            padding: 8px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-edit {
            background: #EFF6FF;
            color: #3B82F6;
        }

        .btn-edit:hover {
            background: #DBEAFE;
        }

        .btn-delete {
            background: #FEF2F2;
            color: #EF4444;
        }

        .btn-delete:hover {
            background: #FEE2E2;
        }

        .btn-check {
            background: #ECFDF5;
            color: #10B981;
        }

        .btn-check:hover {
            background: #D1FAE5;
        }

        .btn-disabled {
            opacity: 0.5;
            cursor: not-allowed;
            background: #F3F4F6;
            color: #9CA3AF;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(4px);
        }

        .modal.active {
            display: flex;
            animation: fadeIn 0.2s ease-out;
        }

        .modal-content {
            background: white;
            width: 100%;
            max-width: 550px;
            border-radius: 20px;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transform: scale(0.95);
            transition: transform 0.2s;
        }

        .modal.active .modal-content {
            transform: scale(1);
        }

        .modal-header {
            background: var(--primary);
            padding: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
        }

        .modal-title {
            font-size: 20px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .close-btn {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            color: white;
            cursor: pointer;
            font-size: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s;
        }

        .close-btn:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .modal-body {
            padding: 24px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-main);
            font-size: 14px;
        }

        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid var(--border);
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.2s;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
            outline: none;
        }

        .modal-footer {
            padding: 20px 24px;
            background: #F9FAFB;
            border-top: 1px solid var(--border);
            display: flex;
            justify-content: flex-end;
            gap: 12px;
        }

        .btn-modal-cancel {
            padding: 10px 20px;
            border-radius: 8px;
            border: 1px solid var(--border);
            background: white;
            color: var(--text-main);
            font-weight: 500;
            cursor: pointer;
        }

        .btn-modal-submit {
            padding: 10px 20px;
            border-radius: 8px;
            border: none;
            background: var(--primary);
            color: white;
            font-weight: 500;
            cursor: pointer;
            box-shadow: 0 2px 4px rgba(79, 70, 229, 0.2);
        }

        .btn-modal-submit:hover {
            background: var(--primary-hover);
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        /* Alert */
        .alert {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 16px 24px;
            border-radius: 12px;
            background: white;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            gap: 12px;
            z-index: 1100;
            animation: slideIn 0.3s ease-out;
            border-left: 4px solid var(--success);
        }

        @keyframes slideIn {
            from {
                transform: translateX(100%);
            }

            to {
                transform: translateX(0);
            }
        }
    </style>
</head>

<body>
    <?php include '../includes/header.php';
    include '../includes/admin-nav.php'; ?>

    <div class="page-header">
        <div class="container">
            <div class="header-content">
                <div>
                    <h1 class="page-title">Fee Management</h1>
                    <p style="opacity: 0.8; margin-top: 8px;">Manage student fees, payments, and records</p>
                </div>
                <button class="btn-add" onclick="openAddModal()">
                    <span style="font-size: 20px;">+</span> Add New Fee
                </button>
            </div>
        </div>
    </div>

    <div class="container" style="margin-top: -40px;">
        <!-- Stats -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-icon icon-blue">📊</div>
                <div class="stat-info">
                    <h3>Total Fees</h3>
                    <p><?= $total_fees ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon icon-yellow">⏳</div>
                <div class="stat-info">
                    <h3>Pending</h3>
                    <p><?= $pending_fees ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon icon-green">✅</div>
                <div class="stat-info">
                    <h3>Paid</h3>
                    <p><?= $paid_fees ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon icon-purple">💰</div>
                <div class="stat-info">
                    <h3>Collected</h3>
                    <p>₹<?= number_format($collected_amount, 2) ?></p>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="content-card">
            <div class="filters">
                <div class="search-wrapper">
                    <span class="search-icon">🔍</span>
                    <input type="text" id="searchInput" class="search-input" placeholder="Search student name, roll no..." value="<?= htmlspecialchars($search) ?>">
                </div>
                <select class="filter-select" id="statusFilter" onchange="applyFilters()">
                    <option value="">All Status</option>
                    <option value="Pending" <?= $status_filter === 'Pending' ? 'selected' : '' ?>>Pending</option>
                    <option value="Paid" <?= $status_filter === 'Paid' ? 'selected' : '' ?>>Paid</option>
                </select>
            </div>

            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Fee Type</th>
                            <th>Amount</th>
                            <th>Due Date</th>
                            <th>Payment Details</th>
                            <th>Status</th>
                            <th>Paid Date</th>
                            <th style="text-align: right;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && $result->num_rows > 0): while ($fee = $result->fetch_assoc()):
                                $is_overdue = ($fee['status'] === 'Pending' && strtotime($fee['due_date']) < time());
                                $badge_class = $is_overdue ? 'badge-overdue' : ($fee['status'] === 'Paid' ? 'badge-paid' : 'badge-pending');
                                $status_text = $is_overdue ? 'Overdue' : $fee['status'];
                                $initials = strtoupper(substr($fee['student_name'], 0, 2));
                        ?>
                                <tr>
                                    <td>
                                        <div class="student-info">
                                            <div class="student-avatar"><?= $initials ?></div>
                                            <div>
                                                <div style="font-weight: 600;"><?= htmlspecialchars($fee['student_name']) ?></div>
                                                <div style="color: var(--text-muted); font-size: 12px;"><?= htmlspecialchars($fee['roll_number']) ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?= htmlspecialchars($fee['fee_type'] ?? 'N/A') ?></td>
                                    <td>₹<?= number_format($fee['amount'], 2) ?></td>
                                    <td><?= date('M d, Y', strtotime($fee['due_date'])) ?></td>
                                    <td>
                                        <?php if (!empty($fee['transaction_id'])): ?>
                                            <div style="font-size: 13px; font-weight: 500;"><?= htmlspecialchars($fee['payment_method']) ?></div>
                                            <div style="font-size: 11px; color: var(--text-muted); font-family: monospace;">
                                                <?= htmlspecialchars($fee['transaction_id']) ?>
                                            </div>
                                        <?php else: ?>
                                            <span style="color: var(--text-muted);">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><span class="badge <?= $badge_class ?>"><?= $status_text ?></span></td>
                                    <td><?= $fee['payment_date'] ? date('M d, Y', strtotime($fee['payment_date'])) : '-' ?></td>
                                    <td>
                                        <div class="actions" style="justify-content: flex-end;">
                                            <?php if ($fee['status'] === 'Pending'): ?>
                                                <form method="POST" style="display:inline">
                                                    <input type="hidden" name="action" value="mark_paid">
                                                    <input type="hidden" name="fee_id" value="<?= $fee['id'] ?>">
                                                    <button type="submit" class="btn-icon btn-check" title="Mark Paid" onclick="return confirm('Mark as paid?')">✓</button>
                                                </form>
                                                <button class="btn-icon btn-edit" title="Edit" onclick='openEditModal(<?= json_encode($fee) ?>)'>✏️</button>
                                                <form method="POST" style="display:inline">
                                                    <input type="hidden" name="action" value="delete_fee">
                                                    <input type="hidden" name="fee_id" value="<?= $fee['id'] ?>">
                                                    <button type="submit" class="btn-icon btn-delete" title="Delete" onclick="return confirm('Delete this fee?')">🗑️</button>
                                                </form>
                                            <?php else: ?>
                                                <button class="btn-icon btn-edit" title="Edit" onclick='openEditModal(<?= json_encode($fee) ?>)'>✏️</button>
                                                <button class="btn-icon btn-disabled" title="Paid (Locked)">🔒</button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile;
                        else: ?>
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 60px;">
                                    <div style="font-size: 48px; margin-bottom: 16px; opacity: 0.5;">📝</div>
                                    <h3 style="margin-bottom: 8px;">No fees found</h3>
                                    <p style="color: var(--text-muted);">Add a new fee record to get started</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add Modal -->
    <div class="modal" id="addModal">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">➕ Add New Fee</div>
                <button class="close-btn" onclick="closeAddModal()">×</button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add_fee">

                    <div class="form-group">
                        <label class="form-label">Select Student *</label>
                        <select name="student_id" class="form-control" required>
                            <option value="">Choose a student...</option>
                            <?php while ($s = $students->fetch_assoc()): ?>
                                <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name'] . ' (' . $s['roll_number'] . ')') ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Fee Type *</label>
                        <select name="fee_type" class="form-control" required>
                            <option value="Hostel Fee">Hostel Fee</option>
                            <option value="Mess Fee">Mess Fee</option>
                            <option value="Security Deposit">Security Deposit</option>
                            <option value="Maintenance">Maintenance</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label class="form-label">Amount (₹) *</label>
                            <input type="number" name="amount" class="form-control" step="0.01" min="0" required placeholder="0.00">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Due Date *</label>
                            <input type="date" name="due_date" class="form-control" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-modal-cancel" onclick="closeAddModal()">Cancel</button>
                    <button type="submit" class="btn-modal-submit">Create Fee Record</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal" id="editModal">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">✏️ Edit Fee Details</div>
                <button class="close-btn" onclick="closeEditModal()">×</button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="update_fee">
                    <input type="hidden" name="fee_id" id="edit_fee_id">

                    <div class="form-group">
                        <label class="form-label">Student *</label>
                        <select name="student_id" id="edit_student_id" class="form-control" required>
                            <option value="">Choose a student...</option>
                            <?php while ($s = $students2->fetch_assoc()): ?>
                                <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name'] . ' (' . $s['roll_number'] . ')') ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Fee Type *</label>
                        <select name="fee_type" id="edit_fee_type" class="form-control" required>
                            <option value="Hostel Fee">Hostel Fee</option>
                            <option value="Mess Fee">Mess Fee</option>
                            <option value="Security Deposit">Security Deposit</option>
                            <option value="Maintenance">Maintenance</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label class="form-label">Amount (₹) *</label>
                            <input type="number" name="amount" id="edit_amount" class="form-control" step="0.01" min="0" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Due Date *</label>
                            <input type="date" name="due_date" id="edit_due_date" class="form-control" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn-modal-cancel" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="btn-modal-submit">Update Changes</button>
                </div>
            </form>
        </div>
    </div>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert">
            <span style="font-size: 20px;">✓</span>
            <div>
                <div style="font-weight: 600; color: var(--success);">Success</div>
                <div style="font-size: 14px; color: var(--text-muted);">
                    <?php
                    if ($_GET['success'] === 'added') echo 'New fee record has been created.';
                    elseif ($_GET['success'] === 'updated') echo 'Fee details have been updated.';
                    elseif ($_GET['success'] === 'paid') echo 'Fee marked as paid successfully.';
                    elseif ($_GET['success'] === 'deleted') echo 'Fee record has been deleted.';
                    elseif ($_GET['success'] === 'verified') echo 'Payment verified successfully.';
                    elseif ($_GET['success'] === 'rejected') echo 'Payment rejected.';
                    ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php include '../includes/footer.php'; ?>

    <script>
        // Modal Logic
        const addModal = document.getElementById('addModal');
        const editModal = document.getElementById('editModal');

        function openAddModal() {
            addModal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeAddModal() {
            addModal.classList.remove('active');
            document.body.style.overflow = '';
        }

        function openEditModal(fee) {
            document.getElementById('edit_fee_id').value = fee.id;
            document.getElementById('edit_student_id').value = fee.student_id;
            document.getElementById('edit_fee_type').value = fee.fee_type || 'Hostel Fee';
            document.getElementById('edit_amount').value = fee.amount;
            document.getElementById('edit_due_date').value = fee.due_date;

            editModal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeEditModal() {
            editModal.classList.remove('active');
            document.body.style.overflow = '';
        }

        // Close on outside click
        window.onclick = function(e) {
            if (e.target == addModal) closeAddModal();
            if (e.target == editModal) closeEditModal();
        }

        // Search Logic
        let timeout;
        document.getElementById('searchInput').addEventListener('input', function() {
            clearTimeout(timeout);
            timeout = setTimeout(applyFilters, 500);
        });

        function applyFilters() {
            const search = document.getElementById('searchInput').value;
            const status = document.getElementById('statusFilter').value;
            window.location.href = `fees.php?search=${encodeURIComponent(search)}&status=${encodeURIComponent(status)}`;
        }

        // Auto hide alert
        setTimeout(() => {
            const alert = document.querySelector('.alert');
            if (alert) {
                alert.style.opacity = '0';
                alert.style.transition = 'opacity 0.5s';
                setTimeout(() => alert.remove(), 500);
            }
        }, 3000);
    </script>
</body>

</html>
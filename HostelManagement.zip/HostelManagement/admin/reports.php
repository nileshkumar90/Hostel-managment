<?php
require_once '../includes/config.php';
requireAdminLogin();

$page_title = 'Reports & Analytics';

// Helper to get monthly data
function getMonthlyData($table, $date_col)
{
    global $conn;
    $sql = "SELECT DATE_FORMAT($date_col, '%Y-%m') as month, COUNT(*) as count 
            FROM $table 
            WHERE $date_col >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
            GROUP BY month 
            ORDER BY month ASC";
    return $conn->query($sql);
}

// Get Data
$registrations = getMonthlyData('students', 'registration_date');
$complaints = getMonthlyData('complaints', 'created_at');
$fees = $conn->query("SELECT DATE_FORMAT(payment_date, '%Y-%m') as month, SUM(amount) as total 
                      FROM fees 
                      WHERE status = 'Paid' AND payment_date >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
                      GROUP BY month 
                      ORDER BY month ASC");

// Room Occupancy
$room_stats = $conn->query("SELECT 
    COUNT(*) as total_rooms,
    SUM(capacity) as total_capacity,
    SUM(occupied) as total_occupied
    FROM rooms")->fetch_assoc();

$occupancy_rate = ($room_stats['total_capacity'] > 0)
    ? round(($room_stats['total_occupied'] / $room_stats['total_capacity']) * 100, 1)
    : 0;

include '../includes/header.php';
include '../includes/admin-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            Reports & Analytics
        </h1>
        <p style="color: var(--color-gray-600);">System-wide insights and performance metrics</p>
    </div>

    <!-- Key Metrics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-2xl);">
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-primary-light);">📊</div>
            <div class="stat-details">
                <div class="stat-label">Occupancy Rate</div>
                <div class="stat-value"><?php echo $occupancy_rate; ?>%</div>
                <div style="font-size: var(--text-sm); color: var(--color-gray-500);">
                    <?php echo $room_stats['total_occupied']; ?> / <?php echo $room_stats['total_capacity']; ?> Beds
                </div>
            </div>
        </div>

        <!-- Quick Export Actions -->
        <div class="card" style="grid-column: span 2;">
            <div class="card-body" style="display: flex; align-items: center; justify-content: space-between;">
                <div>
                    <h3 style="margin: 0; margin-bottom: var(--space-xs);">Export Data</h3>
                    <p style="margin: 0; color: var(--color-gray-600); font-size: var(--text-sm);">Download reports in CSV format</p>
                </div>
                <div style="display: flex; gap: var(--space-md);">
                    <button onclick="window.print()" class="btn btn-secondary">🖨️ Print Report</button>
                    <button class="btn btn-primary" disabled title="Coming Soon">📥 Download CSV</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: var(--space-xl);">

        <!-- Fee Collection -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">💰 Fee Collection Trend (Last 6 Months)</h2>
            </div>
            <div class="card-body">
                <div style="height: 300px; display: flex; align-items: flex-end; gap: var(--space-md); padding-top: var(--space-xl);">
                    <?php while ($row = $fees->fetch_assoc()): ?>
                        <div style="flex: 1; display: flex; flex-direction: column; align-items: center; gap: var(--space-xs);">
                            <div style="width: 100%; background: var(--color-success-light); border-radius: var(--radius-md) var(--radius-md) 0 0; height: <?php echo ($row['total'] / 50000) * 100; ?>%; min-height: 4px; transition: height 0.5s ease;"></div>
                            <div style="font-size: var(--text-xs); color: var(--color-gray-600); transform: rotate(-45deg); margin-top: 10px;">
                                <?php echo date('M Y', strtotime($row['month'])); ?>
                            </div>
                            <div style="font-weight: bold; font-size: var(--text-xs);">
                                ₹<?php echo number_format($row['total'] / 1000) . 'k'; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>

        <!-- Complaints vs Resolved -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">📉 Complaints Overview</h2>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Month</th>
                            <th>New Complaints</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $complaints->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo date('F Y', strtotime($row['month'])); ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: var(--space-md);">
                                        <span style="font-weight: bold;"><?php echo $row['count']; ?></span>
                                        <div style="flex: 1; height: 6px; background: var(--color-gray-100); border-radius: var(--radius-full); overflow: hidden;">
                                            <div style="height: 100%; background: var(--color-error); width: <?php echo min($row['count'] * 5, 100); ?>%;"></div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
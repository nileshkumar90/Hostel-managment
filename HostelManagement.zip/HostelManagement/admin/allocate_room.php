<?php
require_once '../includes/config.php';
requireAdminLogin();

if (!isset($_GET['student_id'])) {
    header("Location: students.php");
    exit;
}

$student_id = (int)$_GET['student_id'];
$success = $error = '';

// Fetch student details
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

if (!$student) {
    die("Student not found");
}

// Handle Allocation
if (isset($_POST['allocate_room'])) {
    $room_id = (int)$_POST['room_id'];

    // Check if room is still available
    $check_room = $conn->query("SELECT * FROM rooms WHERE id = $room_id AND occupied < capacity");

    if ($check_room->num_rows > 0) {
        // Start transaction
        $conn->begin_transaction();

        try {
            // 1. If student already has a room, decrement its occupancy
            if ($student['room_id']) {
                $conn->query("UPDATE rooms SET occupied = occupied - 1 WHERE id = " . $student['room_id']);
            }

            // 2. Assign new room to student
            $update_student = $conn->prepare("UPDATE students SET room_id = ? WHERE id = ?");
            $update_student->bind_param("ii", $room_id, $student_id);
            $update_student->execute();

            // 3. Increment new room occupancy
            $conn->query("UPDATE rooms SET occupied = occupied + 1 WHERE id = $room_id");

            $conn->commit();
            $success = "Room allocated successfully!";

            // Refresh student data
            $stmt->execute();
            $student = $stmt->get_result()->fetch_assoc();
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Allocation failed: " . $e->getMessage();
        }
    } else {
        $error = "Selected room is no longer available (Full).";
    }
}

// Fetch ONLY available rooms (where occupied < capacity)
$rooms_sql = "SELECT * FROM rooms WHERE occupied < capacity ORDER BY block, room_number";
$rooms = $conn->query($rooms_sql);

$page_title = 'Allocate Room';
include '../includes/header.php';
include '../includes/admin-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="max-width: 600px; margin: 0 auto;">
        <div style="margin-bottom: var(--space-xl);">
            <a href="../view_student.php?id=<?php echo $student_id; ?>" class="btn btn-secondary" style="margin-bottom: var(--space-md);">
                ← Back to Student Profile
            </a>
            <h1 style="font-size: var(--text-3xl); font-weight: var(--font-bold);">
                Allocate Room
            </h1>
            <p style="color: var(--color-gray-600);">
                Assigning room for <strong><?php echo htmlspecialchars($student['name']); ?></strong>
                (Roll: <?php echo htmlspecialchars($student['roll_number']); ?>)
            </p>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success" style="margin-bottom: var(--space-lg);">
                <span class="alert-icon">✓</span>
                <div class="alert-content"><?php echo $success; ?></div>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-error" style="margin-bottom: var(--space-lg);">
                <span class="alert-icon">✕</span>
                <div class="alert-content"><?php echo $error; ?></div>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <form method="POST">
                    <div class="form-group">
                        <label class="form-label required">Select Room</label>
                        <select name="room_id" class="form-select" required>
                            <option value="">-- Select Available Room --</option>
                            <?php if ($rooms->num_rows > 0): ?>
                                <?php while ($room = $rooms->fetch_assoc()): ?>
                                    <option value="<?php echo $room['id']; ?>" <?php echo ($student['room_id'] == $room['id']) ? 'selected' : ''; ?>>
                                        Block <?php echo $room['block']; ?> - <?php echo $room['room_number']; ?>
                                        (<?php echo $room['room_type']; ?>) -
                                        Fees: ₹<?php echo number_format($room['fees']); ?>
                                        [<?php echo $room['capacity'] - $room['occupied']; ?> seats left]
                                    </option>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <option value="" disabled>No rooms available</option>
                            <?php endif; ?>
                        </select>
                        <div style="margin-top: var(--space-xs); font-size: var(--text-sm); color: var(--color-gray-500);">
                            Only rooms with available seats are shown.
                        </div>
                    </div>

                    <div style="margin-top: var(--space-xl);">
                        <button type="submit" name="allocate_room" class="btn btn-primary" style="width: 100%;">
                            Confirm Allocation
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
<?php
require_once '../includes/config.php';
requireAdminLogin();

if (!isset($_GET['id'])) {
    header("Location: students.php");
    exit;
}

$student_id = (int)$_GET['id'];

// Fetch student details
$sql = "SELECT s.*, r.room_number, r.block, r.room_type 
        FROM students s 
        LEFT JOIN rooms r ON s.room_id = r.id 
        WHERE s.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

if (!$student) {
    die("Student not found");
}

$page_title = 'View Student - ' . $student['name'];

// Fetch fees
$fees_sql = "SELECT * FROM fees WHERE student_id = ? ORDER BY due_date DESC";
$fees_stmt = $conn->prepare($fees_sql);
$fees_stmt->bind_param("i", $student_id);
$fees_stmt->execute();
$fees = $fees_stmt->get_result();

// Fetch complaints
$complaints_sql = "SELECT * FROM complaints WHERE student_id = ? ORDER BY created_at DESC";
$complaints_stmt = $conn->prepare($complaints_sql);
$complaints_stmt->bind_param("i", $student_id);
$complaints_stmt->execute();
$complaints = $complaints_stmt->get_result();

include '../includes/header.php';
include '../includes/admin-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl); display: flex; justify-content: space-between; align-items: center;">
        <div class="header-content" style="display: flex; align-items: center; gap: 1.5rem;">
            <img src="../assets/img/sbte_logo.png" alt="SBTE Logo" style="height: 60px; width: auto; background: white; padding: 5px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
            <div>
                <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
                    <?php echo htmlspecialchars($student['name']); ?>
                </h1>
                <p style="color: var(--color-gray-600);">
                    Roll No: <?php echo htmlspecialchars($student['roll_number']); ?> •
                    <?php echo htmlspecialchars($student['branch']); ?> (<?php echo $student['year']; ?> Year)
                </p>
            </div>
        </div>
        <div style="display: flex; gap: var(--space-md);">
            <a href="edit_student.php?id=<?php echo $student['id']; ?>" class="btn btn-primary">
                ✏️ Edit Profile
            </a>
            <a href="students.php" class="btn btn-secondary">
                ← Back to List
            </a>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: var(--space-2xl);">
        <!-- Left Column: Personal Info & Fees -->
        <div style="display: flex; flex-direction: column; gap: var(--space-2xl);">

            <!-- Personal Information -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">Personal Information</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: var(--space-lg);">
                        <div>
                            <label style="color: var(--color-gray-500); font-size: var(--text-sm);">Email</label>
                            <div style="font-weight: var(--font-medium);"><?php echo htmlspecialchars($student['email']); ?></div>
                        </div>
                        <div>
                            <label style="color: var(--color-gray-500); font-size: var(--text-sm);">Phone</label>
                            <div style="font-weight: var(--font-medium);"><?php echo htmlspecialchars($student['phone']); ?></div>
                        </div>
                        <div>
                            <label style="color: var(--color-gray-500); font-size: var(--text-sm);">Father's Name</label>
                            <div style="font-weight: var(--font-medium);"><?php echo htmlspecialchars($student['father_name']); ?></div>
                        </div>
                        <div>
                            <label style="color: var(--color-gray-500); font-size: var(--text-sm);">Mother's Name</label>
                            <div style="font-weight: var(--font-medium);"><?php echo htmlspecialchars($student['mother_name']); ?></div>
                        </div>
                        <div>
                            <label style="color: var(--color-gray-500); font-size: var(--text-sm);">Aadhaar No</label>
                            <div style="font-weight: var(--font-medium);"><?php echo htmlspecialchars($student['aadhaar_no']); ?></div>
                        </div>
                        <div>
                            <label style="color: var(--color-gray-500); font-size: var(--text-sm);">Parent's Phone</label>
                            <div style="font-weight: var(--font-medium);"><?php echo htmlspecialchars($student['parents_phone']); ?></div>
                        </div>
                        <div style="grid-column: span 2;">
                            <label style="color: var(--color-gray-500); font-size: var(--text-sm);">Permanent Address</label>
                            <div style="font-weight: var(--font-medium);"><?php echo nl2br(htmlspecialchars($student['address'])); ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Fee History -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">Fee History</h2>
                </div>
                <div class="card-body">
                    <?php if ($fees->num_rows > 0): ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>Amount</th>
                                    <th>Due Date</th>
                                    <th>Status</th>
                                    <th>Payment Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($fee = $fees->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $fee['fee_type']; ?></td>
                                        <td>₹<?php echo number_format($fee['amount'], 2); ?></td>
                                        <td><?php echo formatDate($fee['due_date']); ?></td>
                                        <td><?php echo getStatusBadge($fee['status']); ?></td>
                                        <td><?php echo $fee['payment_date'] ? formatDate($fee['payment_date']) : '-'; ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p style="color: var(--color-gray-500); text-align: center;">No fee records found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Right Column: Room & Complaints -->
        <div style="display: flex; flex-direction: column; gap: var(--space-2xl);">

            <!-- Room Details -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">🏠 Room Allocation</h2>
                </div>
                <div class="card-body">
                    <?php if ($student['room_id']): ?>
                        <div style="text-align: center; padding: var(--space-lg);">
                            <div style="font-size: var(--text-5xl); font-weight: var(--font-bold); color: var(--color-primary); margin-bottom: var(--space-sm);">
                                <?php echo htmlspecialchars($student['room_number']); ?>
                            </div>
                            <div style="font-size: var(--text-lg); color: var(--color-gray-600);">
                                Block <?php echo htmlspecialchars($student['block']); ?>
                            </div>
                            <div style="margin-top: var(--space-md);">
                                <span class="badge badge-info"><?php echo htmlspecialchars($student['room_type']); ?> Seater</span>
                            </div>
                        </div>
                    <?php else: ?>
                        <div style="text-align: center; padding: var(--space-xl); color: var(--color-gray-500);">
                            <p>No room allocated yet.</p>
                            <a href="allocate_room.php?student_id=<?php echo $student['id']; ?>" class="btn btn-sm btn-primary" style="margin-top: var(--space-md);">
                                Allocate Room
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Recent Complaints -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">⚠️ Complaints</h2>
                </div>
                <div class="card-body">
                    <?php if ($complaints->num_rows > 0): ?>
                        <div style="display: flex; flex-direction: column; gap: var(--space-md);">
                            <?php while ($complaint = $complaints->fetch_assoc()): ?>
                                <div style="padding: var(--space-md); background: var(--color-gray-50); border-radius: var(--radius-md);">
                                    <div style="display: flex; justify-content: space-between; margin-bottom: var(--space-xs);">
                                        <span style="font-weight: var(--font-medium);"><?php echo htmlspecialchars($complaint['title']); ?></span>
                                        <span style="font-size: var(--text-xs); color: var(--color-gray-500);"><?php echo formatDate($complaint['created_at']); ?></span>
                                    </div>
                                    <div style="margin-bottom: var(--space-xs);">
                                        <?php echo getStatusBadge($complaint['status']); ?>
                                    </div>
                                    <p style="font-size: var(--text-sm); color: var(--color-gray-600); margin: 0;">
                                        <?php echo htmlspecialchars(substr($complaint['description'], 0, 100)) . '...'; ?>
                                    </p>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <p style="color: var(--color-gray-500); text-align: center;">No complaints found.</p>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
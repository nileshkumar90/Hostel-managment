<?php
require_once '../includes/config.php';

echo "Starting database schema update for 'students'...\n";

// Check if 'apar_id' column exists
$result = $conn->query("SHOW COLUMNS FROM students LIKE 'apar_id'");
if ($result->num_rows == 0) {
    // Add column
    $sql = "ALTER TABLE students ADD COLUMN apar_id VARCHAR(50) AFTER aadhaar_no";
    if ($conn->query($sql) === TRUE) {
        echo "Column 'apar_id' added successfully.\n";
    } else {
        echo "Error adding column 'apar_id': " . $conn->error . "\n";
    }
} else {
    echo "Column 'apar_id' already exists.\n";
}

echo "Schema update completed.\n";

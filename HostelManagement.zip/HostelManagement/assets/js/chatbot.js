// Chatbot JavaScript
(function () {
    'use strict';

    const chatButton = document.getElementById('chatButton');
    const chatWindow = document.getElementById('chatWindow');
    const closeChat = document.getElementById('closeChat');
    const chatForm = document.getElementById('chatForm');
    const chatInput = document.getElementById('chatInput');
    const chatMessages = document.getElementById('chatMessages');
    const typingIndicator = document.getElementById('typingIndicator');

    // Toggle chat window
    chatButton.addEventListener('click', function () {
        chatWindow.classList.add('active');
        chatInput.focus();

        // Show welcome message if first time
        if (chatMessages.children.length === 0) {
            addBotMessage('Hello! 👋 Welcome to SBTE Hostel Support. How can I help you today?');
        }
    });

    closeChat.addEventListener('click', function () {
        chatWindow.classList.remove('active');
    });

    // Handle form submission
    chatForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const message = chatInput.value.trim();
        if (!message) return;

        // Add user message
        addUserMessage(message);
        chatInput.value = '';

        // Show typing indicator
        showTyping();

        // Send to API
        fetch('chatbot_api.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message: message })
        })
            .then(response => response.json())
            .then(data => {
                hideTyping();
                if (data.success) {
                    addBotMessage(data.response);
                } else {
                    addBotMessage('Sorry, I encountered an error. Please try again.');
                }
            })
            .catch(error => {
                hideTyping();
                console.error('Error:', error);
                addBotMessage('Sorry, I couldn\'t process your message. Please try again.');
            });
    });

    function addUserMessage(text) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'chat-message user';
        messageDiv.innerHTML = `
            <div class="message-bubble">
                ${escapeHtml(text)}
                <div class="message-time">${getCurrentTime()}</div>
            </div>
        `;
        chatMessages.appendChild(messageDiv);
        scrollToBottom();
    }

    function addBotMessage(text) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'chat-message bot';

        let actionHtml = '';

        // Smart Actions Detection
        if (text.toLowerCase().includes('pay') && text.toLowerCase().includes('fees')) {
            actionHtml = '<a href="fees.php" class="chat-action-btn">💳 Pay Now</a>';
        } else if (text.toLowerCase().includes('book') && text.toLowerCase().includes('room')) {
            actionHtml = '<a href="book_room.php" class="chat-action-btn">🏠 Book Room</a>';
        } else if (text.toLowerCase().includes('complaint')) {
            actionHtml = '<a href="complaints.php" class="chat-action-btn">📝 New Complaint</a>';
        } else if (text.toLowerCase().includes('mess') || text.toLowerCase().includes('menu')) {
            actionHtml = '<a href="mess-menu.php" class="chat-action-btn">🍽️ View Menu</a>';
        }

        messageDiv.innerHTML = `
            <div class="message-bubble">
                ${text}
                ${actionHtml}
                <div class="message-time">${getCurrentTime()}</div>
            </div>
        `;
        chatMessages.appendChild(messageDiv);
        scrollToBottom();
    }

    function showTyping() {
        typingIndicator.classList.add('active');
        scrollToBottom();
    }

    function hideTyping() {
        typingIndicator.classList.remove('active');
    }

    function scrollToBottom() {
        setTimeout(() => {
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }, 100);
    }

    function getCurrentTime() {
        const now = new Date();
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        return `${hours}:${minutes}`;
    }

    function escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, m => map[m]);
    }

    // Enter to send, Shift+Enter for new line
    chatInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            chatForm.dispatchEvent(new Event('submit'));
        }
    });

    // Close chat when clicking outside
    document.addEventListener('click', function (e) {
        if (!chatWindow.contains(e.target) && !chatButton.contains(e.target)) {
            if (chatWindow.classList.contains('active')) {
                chatWindow.classList.remove('active');
            }
        }
    });
})();

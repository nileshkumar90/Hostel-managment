// Portal Enhancements - Professional JavaScript Features

document.addEventListener('DOMContentLoaded', function () {

    /* ═══ Scroll Reveal Animations ═══ */
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe all cards, stat-cards, and table rows
    document.querySelectorAll('.card, .stat-card, .table tbody tr').forEach(el => {
        el.classList.add('scroll-reveal');
        observer.observe(el);
    });

    /* ═══ Enhanced Hover Effects for Cards ═══ */
    document.querySelectorAll('.card, .stat-card').forEach(card => {
        card.addEventListener('mouseenter', function (e) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            this.style.setProperty('--mouse-x', x + 'px');
            this.style.setProperty('--mouse-y', y + 'px');
        });
    });

    /* ═══ Smooth Number Counting Animation ═══ */
    function animateValue(element, start, end, duration) {
        const range = end - start;
        const increment = range / (duration / 16);
        let current = start;

        const timer = setInterval(function () {
            current += increment;
            if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
                element.textContent = Math.round(end);
                clearInterval(timer);
            } else {
                element.textContent = Math.round(current);
            }
        }, 16);
    }

    // Animate stat card numbers
    const statValueObserver = new IntersectionObserver(function (entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = entry.target;
                const value = parseInt(target.textContent.replace(/[^0-9]/g, ''));
                if (!isNaN(value) && value > 0) {
                    animateValue(target, 0, value, 1000);
                }
                statValueObserver.unobserve(target);
            }
        });
    }, { threshold: 0.5 });

    document.querySelectorAll('.stat-value').forEach(el => {
        statValueObserver.observe(el);
    });

    /* ═══ Table Row Highlight ═══ */
    document.querySelectorAll('.table tbody tr').forEach(row => {
        row.addEventListener('click', function () {
            // Remove previous highlights
            document.querySelectorAll('.table tbody tr').forEach(r => {
                r.style.backgroundColor = '';
            });
            // Highlight clicked row
            this.style.backgroundColor = 'rgba(99, 102, 241, 0.1)';
        });
    });

    /* ═══ Auto-dismiss Alerts ═══ */
    setTimeout(() => {
        document.querySelectorAll('.alert').forEach(alert => {
            alert.style.transition = 'all 0.5s ease-out';
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-20px)';
            setTimeout(() => alert.remove(), 500);
        });
    }, 5000);

    /* ═══ Form Input Enhancement ═══ */
    document.querySelectorAll('.form-input, .form-select, .form-textarea').forEach(input => {
        // Add floating label effect
        input.addEventListener('focus', function () {
            this.parentElement.classList.add('focused');
        });

        input.addEventListener('blur', function () {
            if (!this.value) {
                this.parentElement.classList.remove('focused');
            }
        });

        // Initialize state
        if (input.value) {
            input.parentElement.classList.add('focused');
        }
    });

    /* ═══ Ripple Effect on Buttons ═══ */
    document.querySelectorAll('.btn').forEach(button => {
        button.addEventListener('click', function (e) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            const ripple = document.createElement('span');
            ripple.style.cssText = `
                position: absolute;
                left: ${x}px;
                top: ${y}px;
                width: 0;
                height: 0;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.5);
                transform: translate(-50%, -50%);
                animation: ripple-animation 0.6s ease-out;
                pointer-events: none;
            `;

            this.appendChild(ripple);
            setTimeout(() => ripple.remove(), 600);
        });
    });

    // Add keyframe animation for ripple
    if (!document.querySelector('#ripple-keyframes')) {
        const style = document.createElement('style');
        style.id = 'ripple-keyframes';
        style.textContent = `
            @keyframes ripple-animation {
                to {
                    width: 300px;
                    height: 300px;
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }

    /* ═══ Confirmation Dialogs ═══ */
    document.querySelectorAll('[data-confirm]').forEach(element => {
        element.addEventListener('click', function (e) {
            const message = this.getAttribute('data-confirm');
            if (!confirm(message)) {
                e.preventDefault();
                return false;
            }
        });
    });

    /* ═══ Copy to Clipboard ═══ */
    document.querySelectorAll('[data-copy]').forEach(element => {
        element.addEventListener('click', function () {
            const text = this.getAttribute('data-copy');
            navigator.clipboard.writeText(text).then(() => {
                showToast('Copied to clipboard!', 'success');
            });
        });
    });

    /* ═══ Auto-resize Textareas ═══ */
    document.querySelectorAll('.form-textarea').forEach(textarea => {
        textarea.addEventListener('input', function () {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
    });

    /* ═══ Enhanced Search/Filter ═══ */
    document.querySelectorAll('[data-search]').forEach(searchInput => {
        const targetSelector = searchInput.getAttribute('data-search');

        searchInput.addEventListener('input', function () {
            const searchTerm = this.value.toLowerCase();
            const items = document.querySelectorAll(targetSelector);

            items.forEach(item => {
                const text = item.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    item.style.display = '';
                    item.classList.add('animate-fadeIn');
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });

    /* ═══ Page Load Animation ═══ */
    document.body.classList.add('animate-fadeIn');

    /* ═══ Smooth Scroll for Anchor Links ═══ */
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    console.log('✨ Portal enhancements loaded successfully!');
});

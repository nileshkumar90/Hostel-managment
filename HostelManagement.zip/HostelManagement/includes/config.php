<?php
/* ═══════════════════════════════════════════════════════════════
   DATABASE CONFIGURATION
   ═══════════════════════════════════════════════════════════════ */

// Database credentials
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'hostelmanagement');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8mb4
$conn->set_charset("utf8mb4");

/* ═══════════════════════════════════════════════════════════════
   SYSTEM CONFIGURATION
   ═══════════════════════════════════════════════════════════════ */

// Site settings
define('SITE_NAME', 'Hostel Management System');
define('SITE_URL', 'http://localhost/HostelManagement');

// File upload settings
define('MAX_FILE_SIZE', 2097152); // 2MB in bytes
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'pdf']);

// Upload directories
define('UPLOAD_DIR_STUDENTS', 'uploads/students/');
define('UPLOAD_DIR_DOCUMENTS', 'uploads/documents/');
define('UPLOAD_DIR_ANNOUNCEMENTS', 'uploads/announcements/');

// Create upload directories if they don't exist
$upload_dirs = [UPLOAD_DIR_STUDENTS, UPLOAD_DIR_DOCUMENTS, UPLOAD_DIR_ANNOUNCEMENTS];
foreach ($upload_dirs as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0777, true);
    }
}

// Session settings
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Timezone
date_default_timezone_set('Asia/Kolkata');

/* ═══════════════════════════════════════════════════════════════
   HELPER FUNCTIONS
   ═══════════════════════════════════════════════════════════════ */

// Sanitize input
function sanitize($data)
{
    global $conn;
    return mysqli_real_escape_string($conn, trim(htmlspecialchars($data)));
}

// Check if user is logged in (Student)
function isStudentLoggedIn()
{
    return isset($_SESSION['student_id']);
}

// Check if admin is logged in
function isAdminLoggedIn()
{
    return isset($_SESSION['admin_id']);
}

// Redirect if not logged in (Student)
function requireStudentLogin()
{
    if (!isStudentLoggedIn()) {
        header("Location: " . SITE_URL . "/login.php");
        exit();
    }
}

// Redirect if not logged in (Admin)
function requireAdminLogin()
{
    if (!isAdminLoggedIn()) {
        header("Location: " . SITE_URL . "/admin-login.php");
        exit();
    }
}

// Upload file helper
function uploadFile($file, $directory, $prefix = '')
{
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }

    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($file_extension, ALLOWED_EXTENSIONS)) {
        return false;
    }

    if ($file['size'] > MAX_FILE_SIZE) {
        return false;
    }

    $unique_name = $prefix . uniqid() . '_' . time() . '.' . $file_extension;
    $target_path = $directory . $unique_name;

    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        return $target_path;
    }

    return false;
}

// Format date
function formatDate($date)
{
    return date('d M Y', strtotime($date));
}

// Format date with time
function formatDateTime($datetime)
{
    return date('d M Y, h:i A', strtotime($datetime));
}

// Generate badge HTML based on status
function getStatusBadge($status)
{
    $badges = [
        'Paid' => 'badge-success',
        'Pending' => 'badge-warning',
        'Overdue' => 'badge-error',
        'Resolved' => 'badge-success',
        'In Progress' => 'badge-info',
        'Approved' => 'badge-success',
        'Rejected' => 'badge-error',
        'Completed' => 'badge-success',
        'Cancelled' => 'badge-error'
    ];

    $class = $badges[$status] ?? 'badge-primary';
    return "<span class='badge {$class}'>{$status}</span>";
}

// Get student by ID
function getStudentById($student_id)
{
    global $conn;
    $sql = "SELECT s.*, r.room_number, r.block 
            FROM students s 
            LEFT JOIN rooms r ON s.room_id = r.id 
            WHERE s.id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Get admin by ID
function getAdminById($admin_id)
{
    global $conn;
    $sql = "SELECT * FROM admin WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

<?php
// Get current page name for active state
$current_page = basename($_SERVER['PHP_SELF'], ".php");
?>

<!-- Sidebar Navigation -->
<aside class="sidebar" id="studentSidebar">
    <div class="sidebar-header">
        <div class="logo-icon">S</div>
        <div class="sidebar-brand">
            SBTE HOSTEL<br>
            <span style="font-size: 0.8rem; font-weight: normal; opacity: 0.8;">Student Portal</span>
        </div>
    </div>

    <nav class="sidebar-menu">
        <a href="<?php echo SITE_URL; ?>/student/index.php"
            class="sidebar-link <?php echo ($current_page == 'index') ? 'active' : ''; ?>">
            <span class="sidebar-icon">📊</span>
            <span>Dashboard</span>
        </a>

        <a href="<?php echo SITE_URL; ?>/student/profile.php"
            class="sidebar-link <?php echo ($current_page == 'profile') ? 'active' : ''; ?>">
            <span class="sidebar-icon">👤</span>
            <span>My Profile</span>
        </a>

        <a href="<?php echo SITE_URL; ?>/student/room.php"
            class="sidebar-link <?php echo ($current_page == 'room') ? 'active' : ''; ?>">
            <span class="sidebar-icon">🏠</span>
            <span>My Room</span>
        </a>

        <a href="<?php echo SITE_URL; ?>/student/fees.php"
            class="sidebar-link <?php echo ($current_page == 'fees') ? 'active' : ''; ?>">
            <span class="sidebar-icon">💳</span>
            <span>Fees</span>
        </a>

        <a href="<?php echo SITE_URL; ?>/student/complaints.php"
            class="sidebar-link <?php echo ($current_page == 'complaints') ? 'active' : ''; ?>">
            <span class="sidebar-icon">📝</span>
            <span>Complaints</span>
        </a>

        <a href="<?php echo SITE_URL; ?>/student/announcements.php"
            class="sidebar-link <?php echo ($current_page == 'announcements') ? 'active' : ''; ?>">
            <span class="sidebar-icon">📢</span>
            <span>Announcements</span>
        </a>

        <a href="<?php echo SITE_URL; ?>/student/visitors.php"
            class="sidebar-link <?php echo ($current_page == 'visitors') ? 'active' : ''; ?>">
            <span class="sidebar-icon">👁️</span>
            <span>Visitors</span>
        </a>

        <a href="<?php echo SITE_URL; ?>/student/maintenance.php"
            class="sidebar-link <?php echo ($current_page == 'maintenance') ? 'active' : ''; ?>">
            <span class="sidebar-icon">🔧</span>
            <span>Maintenance</span>
        </a>

        <a href="<?php echo SITE_URL; ?>/student/mess-menu.php"
            class="sidebar-link <?php echo ($current_page == 'mess-menu') ? 'active' : ''; ?>">
            <span class="sidebar-icon">🍽️</span>
            <span>Mess Menu</span>
        </a>

        <div style="margin-top: auto; padding-top: 1rem; border-top: 1px solid rgba(255,255,255,0.1);">
            <a href="<?php echo SITE_URL; ?>/student/logout.php" class="sidebar-link" style="color: #ff9999;">
                <span class="sidebar-icon">🚪</span>
                <span>Logout</span>
            </a>
        </div>
    </nav>
</aside>

<!-- Main Content Wrapper Style -->
<style>
    /* Desktop: Push content to right */
    @media (min-width: 992px) {
        body {
            margin-left: 280px;
            /* Width of sidebar */
            transition: margin-left 0.3s ease;
        }
    }

    /* Mobile: Sidebar hidden by default */
    @media (max-width: 991px) {
        .sidebar {
            transform: translateX(-100%);
            transition: transform 0.3s ease;
        }

        .sidebar.active {
            transform: translateX(0);
        }

        body {
            margin-left: 0;
        }
    }
</style>

<!-- Mobile Toggle Script -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Create toggle button for mobile if it doesn't exist
        if (window.innerWidth <= 991 && !document.getElementById('sidebarToggle')) {
            const toggleBtn = document.createElement('button');
            toggleBtn.id = 'sidebarToggle';
            toggleBtn.innerHTML = '☰';
            toggleBtn.style.cssText = `
                position: fixed;
                top: 1rem;
                left: 1rem;
                z-index: 1300;
                background: var(--sbte-blue);
                color: white;
                border: none;
                padding: 0.5rem 1rem;
                border-radius: 0.5rem;
                font-size: 1.5rem;
                cursor: pointer;
                box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            `;

            document.body.appendChild(toggleBtn);

            toggleBtn.addEventListener('click', function() {
                document.getElementById('studentSidebar').classList.toggle('active');
            });

            // Close sidebar when clicking outside on mobile
            document.addEventListener('click', function(e) {
                const sidebar = document.getElementById('studentSidebar');
                const toggle = document.getElementById('sidebarToggle');

                if (window.innerWidth <= 991 &&
                    sidebar.classList.contains('active') &&
                    !sidebar.contains(e.target) &&
                    e.target !== toggle) {
                    sidebar.classList.remove('active');
                }
            });
        }
    });
</script>
    <!-- Toast Container -->
    <!-- Toast Container -->
    <!-- Toast Container -->
    <!-- Toast Container -->
    <div class="toast-container"></div>

    <!-- Scripts -->
    <script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>
    <script src="<?php echo SITE_URL; ?>/assets/js/portal-enhancements.js"></script>

    <!-- Additional page-specific scripts -->
    <?php if (isset($additional_js)): ?>
        <?php echo $additional_js; ?>
    <?php endif; ?>

    <!-- Professional Chatbot (Student Pages Only) -->
    <?php if (stripos($_SERVER['PHP_SELF'], '/student/') !== false): ?>
        <link rel="stylesheet" href="<?php echo SITE_URL; ?>/student/css/chatbot.css">
        <script src="<?php echo SITE_URL; ?>/student/js/chatbot.js"></script>
    <?php endif; ?>

    </body>

    </html>
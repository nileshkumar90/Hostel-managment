<?php
require_once 'includes/config.php';
requireAdminLogin();

if (!isset($_GET['id'])) {
    header("Location: admin/students.php");
    exit;
}

$student_id = (int)$_GET['id'];
$success = $error = '';

// Handle Update
if (isset($_POST['update_student'])) {
    $name = sanitize($_POST['name']);
    $roll_number = sanitize($_POST['roll_number']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $branch = sanitize($_POST['branch']);
    $year = (int)$_POST['year'];
    $semester = (int)$_POST['semester'];
    $father_name = sanitize($_POST['father_name']);
    $mother_name = sanitize($_POST['mother_name']);
    $parents_phone = sanitize($_POST['parents_phone']);
    $address = sanitize($_POST['address']);
    $aadhaar_no = sanitize($_POST['aadhaar_no']);

    $sql = "UPDATE students SET 
            name = ?, roll_number = ?, email = ?, phone = ?, branch = ?, 
            year = ?, semester = ?, father_name = ?, mother_name = ?, 
            parents_phone = ?, address = ?, aadhaar_no = ? 
            WHERE id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sssssiisssssi",
        $name,
        $roll_number,
        $email,
        $phone,
        $branch,
        $year,
        $semester,
        $father_name,
        $mother_name,
        $parents_phone,
        $address,
        $aadhaar_no,
        $student_id
    );

    if ($stmt->execute()) {
        $success = "Student profile updated successfully!";
    } else {
        $error = "Error updating profile: " . $conn->error;
    }
}

// Fetch student details
$sql = "SELECT * FROM students WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

if (!$student) {
    die("Student not found");
}

$page_title = 'Edit Student - ' . $student['name'];
include 'includes/header.php';
include 'includes/admin-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl); display: flex; justify-content: space-between; align-items: center;">
        <div>
            <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
                Edit Student Profile
            </h1>
            <p style="color: var(--color-gray-600);">Update information for <?php echo htmlspecialchars($student['name']); ?></p>
        </div>
        <a href="view_student.php?id=<?php echo $student['id']; ?>" class="btn btn-secondary">
            ← Back to Profile
        </a>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✓</span>
            <div class="alert-content"><?php echo $success; ?></div>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">⚠️</span>
            <div class="alert-content"><?php echo $error; ?></div>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form method="POST">
                <h3 style="margin-bottom: var(--space-lg); padding-bottom: var(--space-sm); border-bottom: 1px solid var(--color-gray-200);">Academic Information</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-2xl);">
                    <div class="form-group">
                        <label class="form-label required">Full Name</label>
                        <input type="text" name="name" class="form-input" value="<?php echo htmlspecialchars($student['name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label required">Roll Number</label>
                        <input type="text" name="roll_number" class="form-input" value="<?php echo htmlspecialchars($student['roll_number']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label required">Branch</label>
                        <select name="branch" class="form-select" required>
                            <option value="CSE" <?php echo ($student['branch'] == 'CSE') ? 'selected' : ''; ?>>Computer Science</option>
                            <option value="ECE" <?php echo ($student['branch'] == 'ECE') ? 'selected' : ''; ?>>Electronics</option>
                            <option value="ME" <?php echo ($student['branch'] == 'ME') ? 'selected' : ''; ?>>Mechanical</option>
                            <option value="CE" <?php echo ($student['branch'] == 'CE') ? 'selected' : ''; ?>>Civil</option>
                            <option value="EE" <?php echo ($student['branch'] == 'EE') ? 'selected' : ''; ?>>Electrical</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label required">Year</label>
                        <select name="year" class="form-select" required>
                            <?php for ($i = 1; $i <= 4; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo ($student['year'] == $i) ? 'selected' : ''; ?>><?php echo $i; ?> Year</option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label required">Semester</label>
                        <select name="semester" class="form-select" required>
                            <?php for ($i = 1; $i <= 8; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo ($student['semester'] == $i) ? 'selected' : ''; ?>><?php echo $i; ?> Semester</option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>

                <h3 style="margin-bottom: var(--space-lg); padding-bottom: var(--space-sm); border-bottom: 1px solid var(--color-gray-200);">Contact Information</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-2xl);">
                    <div class="form-group">
                        <label class="form-label required">Email</label>
                        <input type="email" name="email" class="form-input" value="<?php echo htmlspecialchars($student['email']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label required">Phone Number</label>
                        <input type="tel" name="phone" class="form-input" value="<?php echo htmlspecialchars($student['phone']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label required">Aadhaar Number</label>
                        <input type="text" name="aadhaar_no" class="form-input" value="<?php echo htmlspecialchars($student['aadhaar_no']); ?>" required>
                    </div>
                </div>

                <h3 style="margin-bottom: var(--space-lg); padding-bottom: var(--space-sm); border-bottom: 1px solid var(--color-gray-200);">Family & Address</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-2xl);">
                    <div class="form-group">
                        <label class="form-label required">Father's Name</label>
                        <input type="text" name="father_name" class="form-input" value="<?php echo htmlspecialchars($student['father_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label required">Mother's Name</label>
                        <input type="text" name="mother_name" class="form-input" value="<?php echo htmlspecialchars($student['mother_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label required">Parent's Phone</label>
                        <input type="tel" name="parents_phone" class="form-input" value="<?php echo htmlspecialchars($student['parents_phone']); ?>" required>
                    </div>
                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label class="form-label required">Permanent Address</label>
                        <textarea name="address" class="form-input" rows="3" required><?php echo htmlspecialchars($student['address']); ?></textarea>
                    </div>
                </div>

                <div style="text-align: right;">
                    <button type="submit" name="update_student" class="btn btn-primary">
                        Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
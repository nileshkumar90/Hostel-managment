<?php
require_once 'includes/config.php';

$page_title = 'Admin Login - SBTE Bihar HMS';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM admin WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $admin = $result->fetch_assoc();

        if (password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];

            header("Location: admin/index.php");
            exit();
        } else {
            $error = "Invalid username or password";
        }
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/sbte-branding.css">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #002266 0%, #000428 50%, #003DA5 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }

        .login-container {
            max-width: 500px;
            width: 100%;
        }

        .login-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
            padding: 3rem;
            animation: slideUp 0.5s ease-out;
            border-top: 5px solid var(--sbte-saffron);
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-header {
            text-align: center;
            margin-bottom: 2.5rem;
        }

        .login-logo {
            margin-bottom: 1.5rem;
        }

        .login-title {
            font-size: 1.85rem;
            font-weight: 900;
            color: var(--sbte-dark-blue);
            margin-bottom: 0.5rem;
        }

        .login-subtitle {
            font-size: 1rem;
            color: #666;
            font-weight: 600;
        }

        .admin-badge {
            display: inline-block;
            background: var(--sbte-saffron);
            color: white;
            padding: 0.35rem 1rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: 0.5rem;
        }

        .form-group {
            margin-bottom: 1.75rem;
        }

        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 700;
            color: var(--sbte-dark-blue);
            font-size: 0.95rem;
        }

        .form-input {
            width: 100%;
            padding: 1rem 1.25rem;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s;
            font-family: 'Poppins', sans-serif;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--sbte-dark-blue);
            box-shadow: 0 0 0 4px rgba(0, 34, 102, 0.1);
        }

        .btn-submit {
            width: 100%;
            padding: 1rem 1.5rem;
            background: linear-gradient(135deg, var(--sbte-dark-blue) 0%, var(--sbte-blue) 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 800;
            cursor: pointer;
            transition: all 0.3s;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(0, 34, 102, 0.4);
        }

        .error-message {
            background: #fee2e2;
            color: #991b1b;
            padding: 1rem 1.25rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            font-weight: 600;
            border-left: 4px solid #dc2626;
        }

        .info-box {
            background: var(--sbte-light-blue);
            border-left: 4px solid var(--sbte-blue);
            padding: 1.25rem;
            border-radius: 10px;
            margin-top: 1.5rem;
        }

        .info-box-title {
            font-size: 0.9rem;
            font-weight: 700;
            color: var(--sbte-dark-blue);
            margin-bottom: 0.5rem;
        }

        .info-box-content {
            font-size: 0.9rem;
            color: #374151;
            font-family: 'Courier New', monospace;
            line-height: 1.8;
        }

        .form-footer {
            text-align: center;
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 2px solid #f3f4f6;
        }

        .form-footer a {
            color: var(--sbte-saffron);
            text-decoration: none;
            font-weight: 700;
            transition: all 0.3s;
        }

        .form-footer a:hover {
            color: var(--sbte-blue);
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            color: white;
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 1.5rem;
            padding: 0.75rem 1.5rem;
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            border-radius: 50px;
            transition: all 0.3s;
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: translateX(-5px);
        }

        .institutional-badge {
            text-align: center;
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 2px solid #f3f4f6;
        }

        .institutional-badge p {
            font-size: 0.8rem;
            color: #9ca3af;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        @media (max-width: 768px) {
            .login-card {
                padding: 2rem;
            }

            .login-title {
                font-size: 1.5rem;
            }
        }
    </style>
</head>

<body>
    <div class="login-container">
        <a href="index.php" class="back-link">← Back to Home</a>

        <div class="login-card">
            <div class="login-header">
                <div class="login-logo">
                    <div class="logo-icon large">S</div>
                </div>
                <h1 class="login-title">Admin Login</h1>
                <p class="login-subtitle">Secure access for administrators</p>
                <div class="admin-badge">Authorized Personnel Only</div>
            </div>

            <?php if (isset($error)): ?>
                <div class="error-message">
                    ⚠️ <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="username" class="form-label">Username</label>
                    <input type="text"
                        id="username"
                        name="username"
                        class="form-input"
                        placeholder="Enter admin username"
                        required autofocus>
                </div>

                <div class="form-group">
                    <label for="password" class="form-label">Secure Password</label>
                    <input type="password"
                        id="password"
                        name="password"
                        class="form-input"
                        placeholder="Enter admin password"
                        required>
                </div>

                <button type="submit" class="btn-submit">
                    🔑 Access Admin Panel
                </button>
            </form>

            <div class="info-box">
                <div class="info-box-title">📌 Default Credentials (Development)</div>
                <div class="info-box-content">
                    Username: <strong>admin</strong><br>
                    Password: <strong>student123</strong>
                </div>
            </div>

            <div class="form-footer">
                <a href="login.php">👨‍🎓 Student Login Portal</a>
            </div>

            <div class="institutional-badge">
                <p>🏛️ SBTE Bihar - Government of Bihar</p>
            </div>
        </div>
    </div>
</body>

</html>
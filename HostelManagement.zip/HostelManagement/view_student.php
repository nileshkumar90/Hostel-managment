<?php
require_once 'includes/config.php';
requireAdminLogin();

if (!isset($_GET['id'])) {
    header("Location: admin/manage_students.php");
    exit;
}

$student_id = (int)$_GET['id'];
$success_msg = '';
$error_msg = '';

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'reset_password') {
            $default_pass = password_hash('Student@123', PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE students SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $default_pass, $student_id);
            if ($stmt->execute()) {
                $success_msg = "Password reset to 'Student@123' successfully.";
            } else {
                $error_msg = "Failed to reset password.";
            }
        } elseif ($_POST['action'] === 'delete_student') {
            // Delete related records first (optional, depending on FK constraints, but good practice)
            $conn->query("DELETE FROM fees WHERE student_id = $student_id");
            $conn->query("DELETE FROM complaints WHERE student_id = $student_id");
            $conn->query("DELETE FROM room_allocation WHERE student_id = $student_id"); // Assuming table name

            // Free up room if allocated
            $conn->query("UPDATE rooms SET occupied = occupied - 1 WHERE id = (SELECT room_id FROM students WHERE id = $student_id)");

            $stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
            $stmt->bind_param("i", $student_id);
            if ($stmt->execute()) {
                header("Location: admin/manage_students.php?msg=deleted");
                exit;
            } else {
                $error_msg = "Failed to delete student.";
            }
        }
    }
}

// Fetch student details
$sql = "SELECT s.*, r.room_number, r.block, r.room_type 
        FROM students s 
        LEFT JOIN rooms r ON s.room_id = r.id 
        WHERE s.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

if (!$student) {
    die("Student not found");
}

// Fetch fees
$fees_sql = "SELECT * FROM fees WHERE student_id = ? ORDER BY due_date DESC";
$fees_stmt = $conn->prepare($fees_sql);
$fees_stmt->bind_param("i", $student_id);
$fees_stmt->execute();
$fees = $fees_stmt->get_result();

// Fetch complaints
$complaints_sql = "SELECT * FROM complaints WHERE student_id = ? ORDER BY created_at DESC";
$complaints_stmt = $conn->prepare($complaints_sql);
$complaints_stmt->bind_param("i", $student_id);
$complaints_stmt->execute();
$complaints = $complaints_stmt->get_result();

include 'includes/header.php';
?>

<style>
    :root {
        --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        --glass-bg: rgba(255, 255, 255, 0.95);
        --glass-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15);
        --card-border: 1px solid rgba(255, 255, 255, 0.18);
    }

    body {
        background: #f0f2f5;
        font-family: 'Inter', sans-serif;
    }

    .main-content {
        padding: 2rem;
        max-width: 1400px;
        margin: 0 auto;
    }

    /* Hero Section */
    .student-hero {
        background: var(--primary-gradient);
        border-radius: 20px;
        padding: 3rem 2rem;
        color: white;
        position: relative;
        overflow: hidden;
        margin-bottom: 2rem;
        box-shadow: 0 10px 30px rgba(118, 75, 162, 0.3);
        display: flex;
        align-items: center;
        gap: 2rem;
    }

    .student-hero::before {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background: url('assets/img/pattern.png');
        opacity: 0.1;
    }

    .hero-profile-img {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        border: 5px solid rgba(255, 255, 255, 0.3);
        object-fit: cover;
        background: white;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    }

    .hero-info h1 {
        font-size: 2.5rem;
        font-weight: 800;
        margin: 0 0 0.5rem 0;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .hero-badges {
        display: flex;
        gap: 1rem;
        margin-top: 1rem;
    }

    .hero-badge {
        background: rgba(255, 255, 255, 0.2);
        backdrop-filter: blur(5px);
        padding: 0.5rem 1rem;
        border-radius: 50px;
        font-size: 0.9rem;
        font-weight: 600;
        border: 1px solid rgba(255, 255, 255, 0.3);
    }

    /* Action Bar */
    .action-bar {
        background: white;
        padding: 1rem 2rem;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        margin-bottom: 2rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 1rem;
    }

    .action-btn {
        padding: 0.8rem 1.5rem;
        border-radius: 10px;
        font-weight: 600;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        transition: all 0.3s ease;
        border: none;
        cursor: pointer;
        font-size: 0.95rem;
    }

    .btn-primary {
        background: var(--primary-gradient);
        color: white;
    }

    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(118, 75, 162, 0.3);
    }

    .btn-warning {
        background: #f6e05e;
        color: #744210;
    }

    .btn-warning:hover {
        background: #ecc94b;
    }

    .btn-danger {
        background: #fc8181;
        color: #742a2a;
    }

    .btn-danger:hover {
        background: #f56565;
    }

    .btn-secondary {
        background: #edf2f7;
        color: #4a5568;
    }

    .btn-secondary:hover {
        background: #e2e8f0;
    }

    /* Grid Layout */
    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        gap: 2rem;
    }

    .info-card {
        background: white;
        border-radius: 15px;
        padding: 2rem;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        transition: transform 0.3s ease;
        height: 100%;
    }

    .info-card:hover {
        transform: translateY(-5px);
    }

    .card-header {
        display: flex;
        align-items: center;
        gap: 1rem;
        margin-bottom: 1.5rem;
        padding-bottom: 1rem;
        border-bottom: 2px solid #f0f2f5;
    }

    .card-icon {
        width: 40px;
        height: 40px;
        background: #ebf4ff;
        color: #5a67d8;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
    }

    .card-title {
        font-size: 1.2rem;
        font-weight: 700;
        color: #2d3748;
        margin: 0;
    }

    .data-row {
        display: flex;
        justify-content: space-between;
        padding: 0.8rem 0;
        border-bottom: 1px solid #f7fafc;
    }

    .data-row:last-child {
        border-bottom: none;
    }

    .data-label {
        color: #718096;
        font-weight: 500;
    }

    .data-value {
        color: #2d3748;
        font-weight: 600;
        text-align: right;
        max-width: 60%;
    }

    /* Table Styles */
    .custom-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 1rem;
    }

    .custom-table th {
        text-align: left;
        padding: 1rem;
        background: #f7fafc;
        color: #4a5568;
        font-weight: 600;
        border-radius: 8px;
    }

    .custom-table td {
        padding: 1rem;
        border-bottom: 1px solid #edf2f7;
        color: #2d3748;
    }

    .status-badge {
        padding: 0.25rem 0.75rem;
        border-radius: 50px;
        font-size: 0.85rem;
        font-weight: 600;
    }

    .status-paid {
        background: #c6f6d5;
        color: #22543d;
    }

    .status-pending {
        background: #feebc8;
        color: #744210;
    }

    .status-overdue {
        background: #fed7d7;
        color: #822727;
    }

    /* Modal */
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: 1000;
        justify-content: center;
        align-items: center;
    }

    .modal-content {
        background: white;
        padding: 2rem;
        border-radius: 15px;
        width: 90%;
        max-width: 400px;
        text-align: center;
        animation: slideUp 0.3s ease;
    }

    @keyframes slideUp {
        from {
            transform: translateY(20px);
            opacity: 0;
        }

        to {
            transform: translateY(0);
            opacity: 1;
        }
    }

    .alert {
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 1rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .alert-success {
        background: #c6f6d5;
        color: #22543d;
    }

    .alert-error {
        background: #fed7d7;
        color: #822727;
    }
</style>

<div class="main-content">

    <!-- Breadcrumb -->
    <div style="margin-bottom: 1rem;">
        <a href="admin/manage_students.php" style="color: #718096; text-decoration: none;">&larr; Back to Students</a>
    </div>

    <?php if ($success_msg): ?>
        <div class="alert alert-success">✅ <?php echo $success_msg; ?></div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div class="alert alert-error">⚠️ <?php echo $error_msg; ?></div>
    <?php endif; ?>

    <!-- Hero Section -->
    <div class="student-hero">
        <?php if (!empty($student['profile_image']) && file_exists($student['profile_image'])): ?>
            <img src="<?php echo htmlspecialchars($student['profile_image']); ?>" alt="Profile" class="hero-profile-img">
        <?php else: ?>
            <div class="hero-profile-img" style="display:flex;align-items:center;justify-content:center;font-size:3rem;color:#cbd5e0;">👤</div>
        <?php endif; ?>

        <div class="hero-info">
            <h1><?php echo htmlspecialchars($student['name']); ?></h1>
            <div style="font-size: 1.1rem; opacity: 0.9;">
                <?php echo htmlspecialchars($student['branch']); ?> • <?php echo htmlspecialchars($student['roll_number']); ?>
            </div>
            <div class="hero-badges">
                <div class="hero-badge">📅 Batch: <?php echo date('Y'); ?></div>
                <div class="hero-badge">
                    <?php if ($student['room_id']): ?>
                        🏠 Room: <?php echo $student['block'] . '-' . $student['room_number']; ?>
                    <?php else: ?>
                        ⚠️ No Room Allocated
                    <?php endif; ?>
                </div>
                <div class="hero-badge">📧 <?php echo htmlspecialchars($student['email']); ?></div>
            </div>
        </div>
    </div>

    <!-- Admin Actions Bar -->
    <div class="action-bar">
        <div style="font-weight: 700; font-size: 1.2rem; color: #2d3748;">⚡ Admin Actions</div>
        <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
            <a href="edit_student.php?id=<?php echo $student['id']; ?>" class="action-btn btn-secondary">
                ✏️ Edit Profile
            </a>
            <a href="admin/fees.php?search=<?php echo urlencode($student['roll_number']); ?>" class="action-btn btn-primary">
                💰 Manage Fees
            </a>
            <a href="admin/allocate_room.php?student_id=<?php echo $student['id']; ?>" class="action-btn btn-primary" style="background: #48bb78;">
                🏠 Allocate Room
            </a>
            <button onclick="confirmReset()" class="action-btn btn-warning">
                🔑 Reset Password
            </button>
            <button onclick="confirmDelete()" class="action-btn btn-danger">
                🗑️ Delete Student
            </button>
        </div>
    </div>

    <div class="info-grid">

        <!-- Personal Details -->
        <div class="info-card">
            <div class="card-header">
                <div class="card-icon">👤</div>
                <h3 class="card-title">Personal Information</h3>
            </div>
            <div class="data-row">
                <span class="data-label">Full Name</span>
                <span class="data-value"><?php echo htmlspecialchars($student['name']); ?></span>
            </div>
            <div class="data-row">
                <span class="data-label">Roll Number</span>
                <span class="data-value"><?php echo htmlspecialchars($student['roll_number']); ?></span>
            </div>
            <div class="data-row">
                <span class="data-label">Email</span>
                <span class="data-value"><?php echo htmlspecialchars($student['email']); ?></span>
            </div>
            <div class="data-row">
                <span class="data-label">Phone</span>
                <span class="data-value"><?php echo htmlspecialchars($student['phone']); ?></span>
            </div>
            <div class="data-row">
                <span class="data-label">Aadhaar No</span>
                <span class="data-value"><?php echo htmlspecialchars($student['aadhaar_no']); ?></span>
            </div>
            <div class="data-row">
                <span class="data-label">APAR ID</span>
                <span class="data-value"><?php echo htmlspecialchars($student['apar_id'] ?? 'N/A'); ?></span>
            </div>
        </div>

        <!-- Family Details -->
        <div class="info-card">
            <div class="card-header">
                <div class="card-icon">👨‍👩‍👦</div>
                <h3 class="card-title">Family & Guardian</h3>
            </div>
            <div class="data-row">
                <span class="data-label">Father's Name</span>
                <span class="data-value"><?php echo htmlspecialchars($student['father_name']); ?></span>
            </div>
            <div class="data-row">
                <span class="data-label">Mother's Name</span>
                <span class="data-value"><?php echo htmlspecialchars($student['mother_name']); ?></span>
            </div>
            <div class="data-row">
                <span class="data-label">Parents' Phone</span>
                <span class="data-value"><?php echo htmlspecialchars($student['parents_phone']); ?></span>
            </div>
            <div class="data-row">
                <span class="data-label">Permanent Address</span>
                <span class="data-value"><?php echo htmlspecialchars($student['address']); ?></span>
            </div>
            <?php if (!empty($student['local_guardian_name'])): ?>
                <div style="margin-top: 1rem; padding-top: 1rem; border-top: 1px dashed #e2e8f0;">
                    <div class="data-row">
                        <span class="data-label">Local Guardian</span>
                        <span class="data-value"><?php echo htmlspecialchars($student['local_guardian_name']); ?></span>
                    </div>
                    <div class="data-row">
                        <span class="data-label">Guardian Phone</span>
                        <span class="data-value"><?php echo htmlspecialchars($student['local_guardian_phone']); ?></span>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Fee History -->
        <div class="info-card" style="grid-column: 1 / -1;">
            <div class="card-header">
                <div class="card-icon">💳</div>
                <h3 class="card-title">Fee Payment History</h3>
            </div>
            <?php if ($fees->num_rows > 0): ?>
                <table class="custom-table">
                    <thead>
                        <tr>
                            <th>Fee Type</th>
                            <th>Amount</th>
                            <th>Due Date</th>
                            <th>Status</th>
                            <th>Payment Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($fee = $fees->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($fee['fee_type']); ?></td>
                                <td>₹<?php echo number_format($fee['amount'], 2); ?></td>
                                <td><?php echo date('d M Y', strtotime($fee['due_date'])); ?></td>
                                <td>
                                    <span class="status-badge <?php echo $fee['status'] == 'Paid' ? 'status-paid' : 'status-pending'; ?>">
                                        <?php echo $fee['status']; ?>
                                    </span>
                                </td>
                                <td><?php echo $fee['payment_date'] ? date('d M Y', strtotime($fee['payment_date'])) : '-'; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p style="color: #718096; text-align: center; padding: 2rem;">No fee records found for this student.</p>
            <?php endif; ?>
        </div>

    </div>
</div>

<!-- Reset Password Modal -->
<div id="resetModal" class="modal">
    <div class="modal-content">
        <h3 style="margin-top:0;">Confirm Password Reset</h3>
        <p>Are you sure you want to reset the password for <strong><?php echo htmlspecialchars($student['name']); ?></strong>?</p>
        <p style="color: #718096; font-size: 0.9rem;">The new password will be <code>Student@123</code></p>
        <div style="margin-top: 1.5rem; display: flex; justify-content: center; gap: 1rem;">
            <button onclick="closeModal('resetModal')" class="action-btn btn-secondary">Cancel</button>
            <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="reset_password">
                <button type="submit" class="action-btn btn-warning">Yes, Reset Password</button>
            </form>
        </div>
    </div>
</div>

<!-- Delete Modal -->
<div id="deleteModal" class="modal">
    <div class="modal-content">
        <h3 style="margin-top:0; color: #e53e3e;">⚠️ Delete Student</h3>
        <p>Are you sure you want to delete <strong><?php echo htmlspecialchars($student['name']); ?></strong>?</p>
        <p style="color: #e53e3e; font-size: 0.9rem;">This action is irreversible. All fees, complaints, and room allocations will also be deleted.</p>
        <div style="margin-top: 1.5rem; display: flex; justify-content: center; gap: 1rem;">
            <button onclick="closeModal('deleteModal')" class="action-btn btn-secondary">Cancel</button>
            <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="delete_student">
                <button type="submit" class="action-btn btn-danger">Yes, Delete Permanently</button>
            </form>
        </div>
    </div>
</div>

<script>
    function confirmReset() {
        document.getElementById('resetModal').style.display = 'flex';
    }

    function confirmDelete() {
        document.getElementById('deleteModal').style.display = 'flex';
    }

    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }

    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    }
</script>

<?php include 'includes/footer.php'; ?>
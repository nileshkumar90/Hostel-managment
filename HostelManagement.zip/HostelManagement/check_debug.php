<?php
echo "Checking Environment...\n";
echo "Fileinfo extension: " . (extension_loaded('fileinfo') ? 'Loaded' : 'Missing') . "\n";
echo "Uploads dir: " . (is_dir('uploads') ? 'Exists' : 'Missing') . "\n";
echo "Uploads/developers dir: " . (is_dir('uploads/developers') ? 'Exists' : 'Missing') . "\n";
echo "Writable: " . (is_writable('uploads') ? 'Yes' : 'No') . "\n";

// Test database connection
require_once 'includes/config.php';
if ($conn->ping()) {
    echo "Database: Connected\n";
} else {
    echo "Database: Error - " . $conn->error . "\n";
}

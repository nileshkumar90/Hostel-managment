<?php
require_once '../includes/config.php';
requireStudentLogin();

$page_title = 'My Room';
$student = getStudentById($_SESSION['student_id']);

if (!$student) {
    header("Location: ../logout.php");
    exit();
}

// Get room information if assigned
$room = null;
$roommates = [];

if (!empty($student['room_id'])) {
    $room = $conn->query("SELECT * FROM rooms WHERE id = " . $student['room_id'])->fetch_assoc();

    // Get roommates
    $roommates_result = $conn->query("SELECT id, name, roll_number, phone, branch, year FROM students WHERE room_id = " . $student['room_id'] . " AND id != " . $_SESSION['student_id']);
    if ($roommates_result) {
        while ($mate = $roommates_result->fetch_assoc()) {
            $roommates[] = $mate;
        }
    }
}

// Check for pending room
$pending_room = null;
if (!empty($student['pending_room_id'])) {
    $pending_room = $conn->query("SELECT * FROM rooms WHERE id = " . $student['pending_room_id'])->fetch_assoc();
}

include '../includes/header.php';
include '../includes/student-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            My Room
        </h1>
        <p style="color: var(--color-gray-600);">Your accommodation details</p>
    </div>

    <?php if ($room): ?>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-2xl);">
            <!-- Room Details -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">🏠 Room Information</h2>
                </div>
                <div class="card-body">
                    <div style="text-align: center; padding: var(--space-2xl); background: var(--gradient-primary); border-radius: var(--radius-xl); color: white; margin-bottom: var(--space-2xl);">
                        <div style="font-size: var(--text-sm); opacity: 0.9; margin-bottom: var(--space-xs);">Your Room Number</div>
                        <div style="font-size: var(--text-5xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
                            <?php echo $room['block'] . '-' . $room['room_number']; ?>
                        </div>
                        <div style="opacity: 0.9;"><?php echo $room['room_type']; ?></div>
                    </div>

                    <div style="display: grid; gap: var(--space-lg);">
                        <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                            <span style="color: var(--color-gray-600);">Block:</span>
                            <strong><?php echo $room['block']; ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                            <span style="color: var(--color-gray-600);">Floor:</span>
                            <strong><?php echo $room['floor']; ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                            <span style="color: var(--color-gray-600);">Room Type:</span>
                            <strong><?php echo $room['room_type']; ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                            <span style="color: var(--color-gray-600);">Capacity:</span>
                            <strong><?php echo $room['capacity']; ?> person(s)</strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                            <span style="color: var(--color-gray-600);">Monthly Fees:</span>
                            <strong style="color: var(--color-primary);">₹<?php echo number_format($room['fees'], 2); ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                            <span style="color: var(--color-gray-600);">Status:</span>
                            <?php echo getStatusBadge($room['status']); ?>
                        </div>
                        <div>
                            <div style="color: var(--color-gray-600); margin-bottom: var(--space-sm);">Facilities:</div>
                            <div style="background: var(--color-gray-50); padding: var(--space-lg); border-radius: var(--radius-lg);">
                                <?php echo htmlspecialchars($room['facilities'] ?? 'Standard facilities available'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Roommates -->
            <div>
                <div class="card" style="margin-bottom: var(--space-xl);">
                    <div class="card-header">
                        <h2 class="card-title">👥 Roommates</h2>
                    </div>
                    <div class="card-body">
                        <?php if (count($roommates) > 0): ?>
                            <div style="display: grid; gap: var(--space-lg);">
                                <?php foreach ($roommates as $mate): ?>
                                    <div style="padding: var(--space-lg); background: var(--color-gray-50); border-radius: var(--radius-lg); border-left: 4px solid var(--color-primary);">
                                        <div style="font-weight: var(--font-bold); font-size: var(--text-lg); margin-bottom: var(--space-xs);">
                                            <?php echo htmlspecialchars($mate['name']); ?>
                                        </div>
                                        <div style="font-size: var(--text-sm); color: var(--color-gray-600); margin-bottom: var(--space-sm);">
                                            Roll: <?php echo htmlspecialchars($mate['roll_number']); ?>
                                        </div>
                                        <div style="font-size: var(--text-sm); color: var(--color-gray-600);">
                                            📱 <?php echo htmlspecialchars($mate['phone']); ?><br>
                                            🎓 <?php echo htmlspecialchars($mate['branch'] ?? $mate['course'] ?? 'N/A'); ?> - Year <?php echo $mate['year']; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div style="padding: var(--space-3xl); text-align: center; color: var(--color-gray-500);">
                                <div style="font-size: 4rem; margin-bottom: var(--space-lg);">👤</div>
                                <h3>No Roommates</h3>
                                <p>You're the only one in this room currently.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Quick Info -->
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">📋 Important Information</h2>
                    </div>
                    <div class="card-body">
                        <div style="display: grid; gap: var(--space-md);">
                            <div style="padding: var(--space-md); background: var(--color-info-light); border-radius: var(--radius-lg);">
                                <div style="font-weight: var(--font-semibold); margin-bottom: var(--space-xs);">🔐 Room Security</div>
                                <div style="font-size: var(--text-sm); color: var(--color-gray-700);">
                                    Always lock your room when leaving. Report any security issues immediately.
                                </div>
                            </div>
                            <div style="padding: var(--space-md); background: var(--color-success-light); border-radius: var(--radius-lg);">
                                <div style="font-weight: var(--font-semibold); margin-bottom: var(--space-xs);">🧹 Cleanliness</div>
                                <div style="font-size: var(--text-sm); color: var(--color-gray-700);">
                                    Keep your room clean. Cleaning inspections are done weekly.
                                </div>
                            </div>
                            <div style="padding: var(--space-md); background: var(--color-warning-light); border-radius: var(--radius-lg);">
                                <div style="font-weight: var(--font-semibold); margin-bottom: var(--space-xs);">⏰ Quiet Hours</div>
                                <div style="font-size: var(--text-sm); color: var(--color-gray-700);">
                                    Maintain silence from 10:00 PM to 6:00 AM.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="card">
            <div class="card-body">
                <?php if ($pending_room): ?>
                    <div style="padding: var(--space-3xl); text-align: center;">
                        <div style="font-size: 6rem; margin-bottom: var(--space-lg);">⏳</div>
                        <h2 style="color: var(--color-warning);">Room Allocation Pending</h2>
                        <p style="font-size: var(--text-lg); margin-bottom: var(--space-xl); color: var(--color-gray-600);">
                            Room <strong><?php echo $pending_room['block'] . '-' . $pending_room['room_number']; ?></strong>
                            has been reserved for you.
                        </p>

                        <div style="background: var(--color-warning-light); padding: var(--space-xl); border-radius: var(--radius-lg); max-width: 600px; margin: 0 auto var(--space-xl);">
                            <div style="font-weight: var(--font-bold); margin-bottom: var(--space-sm); color: var(--color-warning-dark);">⚠️ Action Required</div>
                            <p style="margin-bottom: var(--space-lg);">
                                To finalize your room allocation, please complete the payment of
                                <strong>₹<?php echo number_format($pending_room['fees'], 2); ?></strong>.
                            </p>
                            <a href="fees.php" class="btn btn-primary">
                                💳 Go to Fees & Pay Now
                            </a>
                        </div>
                    </div>
                <?php else: ?>
                    <div style="padding: var(--space-3xl); text-align: center; color: var(--color-gray-500);">
                        <div style="font-size: 6rem; margin-bottom: var(--space-lg);">🏠</div>
                        <h2>No Room Assigned</h2>
                        <p style="font-size: var(--text-lg); margin-bottom: var(--space-xl);">You haven't booked a room yet.</p>

                        <div style="max-width: 500px; margin: 0 auto;">
                            <a href="book_room.php" class="btn btn-primary" style="justify-content: center; padding: var(--space-lg) var(--space-xl); font-size: var(--text-lg);">
                                📅 Book a Room Now
                            </a>
                            <p style="margin-top: var(--space-md); font-size: var(--text-sm); color: var(--color-gray-600);">
                                Browse available rooms and book instantly.
                            </p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
<?php
require_once '../includes/config.php';
requireStudentLogin();

$page_title = 'My Fees & Payments';
$student_id = $_SESSION['student_id'];

// Handle payment submission
$success = $_SESSION['success'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);

if (isset($_POST['submit_payment'])) {
    $fee_id = (int)$_POST['fee_id'];
    $payment_date = sanitize($_POST['payment_date']);
    $payment_method = sanitize($_POST['payment_method']);
    $transaction_id = sanitize($_POST['transaction_id']);

    $update = $conn->prepare("UPDATE fees SET transaction_id = ?, payment_method = ?, payment_date = ? WHERE id = ? AND student_id = ?");
    $update->bind_param("sssii", $transaction_id, $payment_method, $payment_date, $fee_id, $student_id);

    if ($update->execute()) {
        $_SESSION['success'] = "✅ Payment submitted successfully! Your payment is pending verification by admin.";
    } else {
        $_SESSION['error'] = "❌ Payment submission failed. Please try again.";
    }

    header("Location: fees.php");
    exit();
}

// Get all fees for this student
$fees = $conn->query("SELECT * FROM fees WHERE student_id = $student_id ORDER BY created_at DESC");

// Calculate totals
$totals = $conn->query("SELECT 
    COALESCE(SUM(amount), 0) as total_amount,
    COALESCE(SUM(paid_amount), 0) as total_paid,
    COALESCE(SUM(amount - paid_amount), 0) as total_pending
    FROM fees WHERE student_id = $student_id")->fetch_assoc();

$total_amount = $totals['total_amount'];
$total_paid = $totals['total_paid'];
$total_pending = $totals['total_pending'];

include '../includes/header.php';
include '../includes/student-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <?php if ($success): ?>
        <div style="background: #c6f6d5; color: #22543d; padding: 1rem; border-radius: 10px; margin-bottom: 2rem; border: 1px solid #9ae6b4;">
            <?php echo $success; ?>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div style="background: #fed7d7; color: #822727; padding: 1rem; border-radius: 10px; margin-bottom: 2rem; border: 1px solid #feb2b2;">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            My Fees & Payments
        </h1>
        <p style="color: var(--color-gray-600);">Manage your hostel fee payments and view history</p>
    </div>

    <!-- Stats Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-xl); margin-bottom: var(--space-2xl);">
        <div class="card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
            <div class="card-body">
                <div style="font-size: var(--text-sm); opacity: 0.9; margin-bottom: var(--space-xs);">Total Fees</div>
                <div style="font-size: var(--text-4xl); font-weight: var(--font-extrabold);">₹<?php echo number_format($total_amount); ?></div>
            </div>
        </div>
        <div class="card" style="background: linear-gradient(135deg, #48bb78 0%, #38a169 100%); color: white;">
            <div class="card-body">
                <div style="font-size: var(--text-sm); opacity: 0.9; margin-bottom: var(--space-xs);">Paid Amount</div>
                <div style="font-size: var(--text-4xl); font-weight: var(--font-extrabold);">₹<?php echo number_format($total_paid); ?></div>
            </div>
        </div>
        <div class="card" style="background: linear-gradient(135deg, #f6ad55 0%, #ed8936 100%); color: white;">
            <div class="card-body">
                <div style="font-size: var(--text-sm); opacity: 0.9; margin-bottom: var(--space-xs);">Pending Due</div>
                <div style="font-size: var(--text-4xl); font-weight: var(--font-extrabold);">₹<?php echo number_format($total_pending); ?></div>
            </div>
        </div>
    </div>

    <!-- Payment History Table -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📜 Payment History</h2>
        </div>
        <div class="card-body">
            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Fee Description</th>
                            <th>Due Date</th>
                            <th>Amount</th>
                            <th>Paid</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($fees->num_rows > 0): ?>
                            <?php while ($row = $fees->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <div style="font-weight: 600; color: var(--color-gray-900);"><?php echo htmlspecialchars($row['fee_type']); ?></div>
                                        <div style="font-size: var(--text-sm); color: var(--color-gray-600);">ID: #<?php echo $row['id']; ?></div>
                                    </td>
                                    <td><?php echo date('d M, Y', strtotime($row['due_date'])); ?></td>
                                    <td style="font-weight: 600;">₹<?php echo number_format($row['amount']); ?></td>
                                    <td style="color: var(--color-success);">₹<?php echo number_format($row['paid_amount']); ?></td>
                                    <td>
                                        <?php
                                        if ($row['status'] === 'Pending' && !empty($row['transaction_id'])) {
                                            echo '<span class="badge badge-info">⏳ Verification Pending</span>';
                                        } elseif ($row['status'] === 'Paid') {
                                            echo '<span class="badge badge-success">✓ Paid</span>';
                                        } else {
                                            echo '<span class="badge badge-warning">⚠️ Pending</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php if ($row['status'] == 'Paid' || !empty($row['transaction_id'])): ?>
                                            <span style="color: var(--color-success); font-weight: 600;">Done</span>
                                        <?php else: ?>
                                            <button onclick="openPaymentModal(<?php echo $row['id']; ?>, <?php echo $row['amount'] - $row['paid_amount']; ?>)" class="btn btn-primary btn-sm">
                                                Pay Now
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" style="text-align: center; padding: var(--space-3xl); color: var(--color-gray-500);">
                                    No fee records found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div class="modal" id="paymentModal" style="display: none;">
    <div class="modal-overlay" onclick="closePaymentModal()"></div>
    <div class="modal-container">
        <div class="modal-header">
            <h3 class="modal-title">Make Payment</h3>
            <button class="modal-close" onclick="closePaymentModal()">&times;</button>
        </div>

        <form method="POST" action="" class="modal-body">
            <input type="hidden" name="fee_id" id="modal_fee_id">

            <div class="form-group">
                <label class="form-label">Amount to Pay</label>
                <input type="text" class="form-input" id="modal_amount" readonly style="background: var(--color-gray-100);">
            </div>

            <div class="form-group">
                <label class="form-label">Payment Date</label>
                <input type="date" name="payment_date" class="form-input" required value="<?php echo date('Y-m-d'); ?>">
            </div>

            <div class="form-group">
                <label class="form-label">Payment Method</label>
                <select name="payment_method" class="form-input" required>
                    <option value="UPI">UPI / GPay / PhonePe</option>
                    <option value="Bank Transfer">Bank Transfer / NEFT</option>
                    <option value="Cash">Cash</option>
                    <option value="Cheque">Cheque</option>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Transaction ID / Reference No.</label>
                <input type="text" name="transaction_id" class="form-input" required placeholder="e.g. UPI1234567890">
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closePaymentModal()">Cancel</button>
                <button type="submit" name="submit_payment" class="btn btn-primary">Confirm Payment</button>
            </div>
        </form>
    </div>
</div>

<script>
    function openPaymentModal(feeId, amount) {
        document.getElementById('modal_fee_id').value = feeId;
        document.getElementById('modal_amount').value = '₹' + amount.toLocaleString();
        document.getElementById('paymentModal').style.display = 'flex';
    }

    function closePaymentModal() {
        document.getElementById('paymentModal').style.display = 'none';
    }
</script>

<?php include '../includes/footer.php'; ?>
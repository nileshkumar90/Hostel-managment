// Professional Chatbot JavaScript

const chatbot = {
    init() {
        this.createElements();
        this.attachEvents();
        this.showWelcomeMessage();
    },

    createElements() {
        // Toggle button
        const toggle = document.createElement('button');
        toggle.className = 'chatbot-toggle';
        toggle.innerHTML = '<span class="icon">💬</span><span class="close-icon">✕</span>';
        document.body.appendChild(toggle);

        // Chat window
        const window = document.createElement('div');
        window.className = 'chatbot-window';
        window.innerHTML = `
            <div class="chatbot-header">
                <div class="avatar">🤖</div>
                <div class="info">
                    <h3>SBTE Hostel Assistant</h3>
                    <p>Online • Here to help!</p>
                </div>
            </div>
            <div class="chatbot-body" id="chatbot-messages"></div>
            <div class="chatbot-input">
                <input type="text" id="chatbot-input" placeholder="Type your message or /help...">
                <button id="chatbot-send">➤</button>
            </div>
        `;
        document.body.appendChild(window);

        this.toggle = toggle;
        this.window = window;
        this.messagesContainer = document.getElementById('chatbot-messages');
        this.input = document.getElementById('chatbot-input');
        this.sendBtn = document.getElementById('chatbot-send');
    },

    attachEvents() {
        // Toggle chat window
        this.toggle.addEventListener('click', () => this.toggleChat());

        // Send message on button click
        this.sendBtn.addEventListener('click', () => this.sendMessage());

        // Send message on Enter key
        this.input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendMessage();
        });

        // Close on Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.window.classList.contains('active')) {
                this.toggleChat();
            }
        });
    },

    toggleChat() {
        this.toggle.classList.toggle('active');
        this.window.classList.toggle('active');
        if (this.window.classList.contains('active')) {
            this.input.focus();
        }
    },

    showWelcomeMessage() {
        const welcome = {
            response: "👋 **Welcome to SBTE Hostel!**\n\nI'm your virtual assistant. I can help you with:\n\n• Room booking\n• Fee information\n• Complaints & maintenance\n• Visitor registration\n• Mess menu\n• And more!\n\nType `/help` to see all commands or just ask me anything!",
            suggestions: ['Show Commands', 'Book Room', 'Check Fees', 'Contact Info']
        };
        this.addBotMessage(welcome.response, welcome.suggestions);
    },

    async sendMessage() {
        const message = this.input.value.trim();
        if (!message) return;

        // Add user message
        this.addUserMessage(message);
        this.input.value = '';

        // Show typing indicator
        this.showTyping();

        try {
            // Send to API
            const formData = new FormData();
            formData.append('message', message);

            const response = await fetch('/HostelManagement/student/chatbot_api.php', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            // Hide typing and show response
            this.hideTyping();
            this.addBotMessage(data.response, data.suggestions || []);
        } catch (error) {
            this.hideTyping();
            this.addBotMessage("❌ Sorry, I'm having trouble connecting. Please try again later.");
        }
    },

    addUserMessage(text) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message user';
        messageDiv.innerHTML = `
            <div class="avatar">👤</div>
            <div class="bubble">${this.escapeHtml(text)}</div>
        `;
        this.messagesContainer.appendChild(messageDiv);
        this.scrollToBottom();
    },

    addBotMessage(text, suggestions = []) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message';

        let html = `
            <div class="avatar">🤖</div>
            <div class="bubble">${this.formatMessage(text)}`;

        if (suggestions.length > 0) {
            html += '<div class="suggestions">';
            suggestions.forEach(suggestion => {
                html += `<span class="suggestion-chip" onclick="chatbot.handleSuggestion('${this.escapeHtml(suggestion)}')">${this.escapeHtml(suggestion)}</span>`;
            });
            html += '</div>';
        }

        html += '</div>';
        messageDiv.innerHTML = html;
        this.messagesContainer.appendChild(messageDiv);
        this.scrollToBottom();
    },

    handleSuggestion(text) {
        // Map suggestion text to actual commands/queries
        const suggestionMap = {
            'Show Help': '/help',
            'Show Commands': '/help',
            'Room Booking': '/rooms',
            'Book Room': '/rooms',
            'Book Now': '/rooms',
            'Check Fees': '/fees',
            'Pay Fees': '/fees',
            'File Complaint': '/complaint',
            'Contact Info': '/contact',
            'View Menu': '/menu',
            "Today's Menu": '/menu',
            'Maintenance': '/maintenance',
            'Register Visitor': '/visitor',
            'Edit Profile': '/profile',
            'Room Types': 'What are the room types?',
            'Fee Structure': 'What is the fee structure?',
            'Payment Methods': 'What are the payment methods?',
            'My Room': 'Show me my room',
            'My Complaints': 'Show my complaints',
            'My Requests': 'Show my maintenance requests',
            'Emergency': 'Emergency contact',
            'Visitor Rules': 'What are the visitor rules?',
            'Mess Timings': 'What are the mess timings?',
            'Facilities': 'What facilities are available?',
            'Rules': 'What are the hostel rules?',
            'About': '/about'
        };

        const message = suggestionMap[text] || text;
        this.input.value = message;
        this.sendMessage();
    },

    showTyping() {
        const indicator = document.createElement('div');
        indicator.className = 'typing-indicator active';
        indicator.id = 'typing-indicator';
        indicator.innerHTML = `
            <div class="avatar">🤖</div>
            <div class="bubble">
                <div class="dots">
                    <span class="dot"></span>
                    <span class="dot"></span>
                    <span class="dot"></span>
                </div>
            </div>
        `;
        this.messagesContainer.appendChild(indicator);
        this.scrollToBottom();
    },

    hideTyping() {
        const indicator = document.getElementById('typing-indicator');
        if (indicator) {
            indicator.remove();
        }
    },

    formatMessage(text) {
        // Format markdown-style bold
        text = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

        // Format links
        text = text.replace(/📍 \[([^\]]+)\]\(([^)]+)\)/g, '<br><br>📍 <a href="$2" target="_blank">$1</a>');

        // Convert newlines to <br>
        text = text.replace(/\n/g, '<br>');

        return text;
    },

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },

    scrollToBottom() {
        setTimeout(() => {
            this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
        }, 100);
    }
};

// Initialize chatbot when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => chatbot.init());
} else {
    chatbot.init();
}

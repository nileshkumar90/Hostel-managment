<?php
// Test script to check room booking flow
session_start();
require_once '../includes/config.php';

echo "<h2>Room Booking System Test</h2>";

// Check if fees table exists
echo "<h3>1. Checking fees table</h3>";
$result = $conn->query("SHOW TABLES LIKE 'fees'");
if ($result->num_rows > 0) {
    echo "✅ Fees table exists<br>";

    // Check fees table structure
    $structure = $conn->query("DESCRIBE fees");
    echo "<pre>";
    while ($row = $structure->fetch_assoc()) {
        echo $row['Field'] . " (" . $row['Type'] . ")\n";
    }
    echo "</pre>";
} else {
    echo "❌ Fees table does NOT exist<br>";
}

// Check if pending_room_id column exists in students table
echo "<h3>2. Checking students table for pending_room_id</h3>";
$check = $conn->query("SHOW COLUMNS FROM students LIKE 'pending_room_id'");
if ($check->num_rows > 0) {
    echo "✅ pending_room_id column exists in students table<br>";
} else {
    echo "❌ pending_room_id column does NOT exist in students table<br>";
    echo "<br><strong>FIX:</strong> Run this SQL:<br>";
    echo "<code>ALTER TABLE students ADD COLUMN pending_room_id INT DEFAULT NULL AFTER room_id;</code><br>";
}

// Check if there are available rooms
echo "<h3>3. Checking available rooms</h3>";
$rooms = $conn->query("SELECT COUNT(*) as count FROM rooms WHERE status = 'Available'");
$room_count = $rooms->fetch_assoc()['count'];
echo "Available rooms: " . $room_count . "<br>";

if ($room_count > 0) {
    echo "✅ There are available rooms<br>";
    $sample = $conn->query("SELECT id, block, room_number, room_type, fees, capacity, occupied FROM rooms WHERE status = 'Available' LIMIT 3");
    echo "<h4>Sample rooms:</h4>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Block</th><th>Room#</th><th>Type</th><th>Fees</th><th>Capacity</th><th>Occupied</th></tr>";
    while ($r = $sample->fetch_assoc()) {
        echo "<tr><td>{$r['id']}</td><td>{$r['block']}</td><td>{$r['room_number']}</td><td>{$r['room_type']}</td><td>₹{$r['fees']}</td><td>{$r['capacity']}</td><td>{$r['occupied']}</td></tr>";
    }
    echo "</table>";
} else {
    echo "❌ NO available rooms<br>";
}

//Check if student is logged in (session test)
echo "<h3>4. Session Test</h3>";
if (isset($_SESSION['student_id'])) {
    echo "✅ Student ID in session: " . $_SESSION['student_id'] . "<br>";
} else {
    echo "⚠️ No student logged in (this is normal if viewing directly)<br>";
}

echo "<hr>";
echo "<h3>Summary</h3>";
echo "<p>If all checks pass, the room booking should work. If not, use the SQL fix provided above.</p>";

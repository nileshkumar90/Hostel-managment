<?php
require_once '../includes/config.php';
requireStudentLogin();

$page_title = 'Announcements';
$student = getStudentById($_SESSION['student_id']);

// Get all active announcements (removed expires_at check)
$announcements = $conn->query("
    SELECT a.*, ad.username as posted_by 
    FROM announcements a 
    JOIN admin ad ON a.created_by = ad.id 
    WHERE a.is_active = 1 
    ORDER BY a.priority DESC, a.created_at DESC
");

include '../includes/header.php';
include '../includes/student-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            📢 Announcements
        </h1>
        <p style="color: var(--color-gray-600);">Stay updated with hostel announcements</p>
    </div>

    <?php if ($announcements->num_rows > 0): ?>
        <div style="display: grid; gap: var(--space-lg);">
            <?php while ($announcement = $announcements->fetch_assoc()): ?>
                <div class="card">
                    <div style="padding: var(--space-xl);">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: var(--space-lg);">
                            <div style="flex: 1;">
                                <div style="display: flex; gap: var(--space-md); align-items: center; margin-bottom: var(--space-sm);">
                                    <h3 style="font-size: var(--text-2xl); font-weight: var(--font-bold); margin: 0;">
                                        <?php echo htmlspecialchars($announcement['title']); ?>
                                    </h3>
                                    <?php if ($announcement['priority'] == 'High'): ?>
                                        <span class="badge badge-error">High Priority</span>
                                    <?php elseif ($announcement['priority'] == 'Medium'): ?>
                                        <span class="badge badge-warning">Medium Priority</span>
                                    <?php else: ?>
                                        <span class="badge badge-info">Low Priority</span>
                                    <?php endif; ?>
                                    <span class="badge badge-primary">
                                        <?php echo $announcement['category']; ?>
                                    </span>
                                </div>
                                <div style="font-size: var(--text-sm); color: var(--color-gray-600);">
                                    Posted by: <?php echo htmlspecialchars($announcement['posted_by']); ?> •
                                    <?php echo formatDateTime($announcement['created_at']); ?>
                                </div>
                            </div>
                        </div>

                        <div style="background: <?php
                                                echo match ($announcement['priority']) {
                                                    'High' => 'var(--color-error-light)',
                                                    'Medium' => 'var(--color-warning-light)',
                                                    default => 'var(--color-gray-50)'
                                                };
                                                ?>; padding: var(--space-xl); border-radius: var(--radius-lg); border-left: 4px solid <?php
                                                                                                                                        echo match ($announcement['priority']) {
                                                                                                                                            'High' => 'var(--color-error)',
                                                                                                                                            'Medium' => 'var(--color-warning)',
                                                                                                                                            default => 'var(--color-primary)'
                                                                                                                                        };
                                                                                                                                        ?>;">
                            <div style="font-size: var(--text-base); line-height: 1.6; color: var(--color-gray-800);">
                                <?php echo nl2br(htmlspecialchars($announcement['content'])); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="card">
            <div class="card-body">
                <div style="padding: var(--space-3xl); text-align: center; color: var(--color-gray-500);">
                    <div style="font-size: 6rem; margin-bottom: var(--space-lg);">📢</div>
                    <h3>No Announcements</h3>
                    <p>There are no active announcements at the moment. Check back later!</p>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
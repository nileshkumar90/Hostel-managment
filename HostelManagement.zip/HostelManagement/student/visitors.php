<?php
require_once '../includes/config.php';
requireStudentLogin();

$page_title = 'Register Visitor';
$student = getStudentById($_SESSION['student_id']);

// Handle visitor registration
if (isset($_POST['register_visitor'])) {
    $visitor_name = sanitize($_POST['visitor_name']);
    $visitor_phone = sanitize($_POST['visitor_contact']);
    $purpose = sanitize($_POST['purpose']);
    $relation = sanitize($_POST['relation']);

    $sql = "INSERT INTO visitors (student_id, visitor_name, visitor_phone, purpose, relation, visit_date, in_time) VALUES (?, ?, ?, ?, ?, CURDATE(), CURTIME())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issss", $_SESSION['student_id'], $visitor_name, $visitor_phone, $purpose, $relation);

    if ($stmt->execute()) {
        $success = "Visitor registered successfully!";
    } else {
        $error = "Error registering visitor: " . $conn->error;
    }
}

// Get student's visitor history
$visitors = $conn->query("SELECT * FROM visitors WHERE student_id = " . $_SESSION['student_id'] . " ORDER BY visit_date DESC, in_time DESC LIMIT 20");

// Get statistics
$total_visitors = $conn->query("SELECT COUNT(*) as count FROM visitors WHERE student_id = " . $_SESSION['student_id'])->fetch_assoc()['count'];
$active_visitors = $conn->query("SELECT COUNT(*) as count FROM visitors WHERE student_id = " . $_SESSION['student_id'] . " AND out_time IS NULL")->fetch_assoc()['count'];

include '../includes/header.php';
include '../includes/student-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            Visitor Registration
        </h1>
        <p style="color: var(--color-gray-600);">Register visitors and view visit history</p>
    </div>

    <?php if (isset($success)): ?>
        <div class="alert alert-success" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✓</span>
            <div class="alert-content"><?php echo $success; ?></div>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="alert alert-error" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✕</span>
            <div class="alert-content"><?php echo $error; ?></div>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-2xl);">
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-primary-light);">👥</div>
            <div class="stat-details">
                <div class="stat-label">Total Visitors</div>
                <div class="stat-value"><?php echo $total_visitors; ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-success-light);">🟢</div>
            <div class="stat-details">
                <div class="stat-label">Currently Visiting</div>
                <div class="stat-value"><?php echo $active_visitors; ?></div>
            </div>
        </div>
    </div>

    <!-- Register Visitor Form -->
    <div class="card" style="margin-bottom: var(--space-2xl);">
        <div class="card-header">
            <h2 class="card-title">👤 Register New Visitor</h2>
        </div>
        <div class="card-body">
            <form method="POST">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg);">
                    <div class="form-group">
                        <label class="form-label required">Visitor Name</label>
                        <input type="text" name="visitor_name" class="form-input" placeholder="Full name" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label required">Contact Number</label>
                        <input type="tel" name="visitor_contact" class="form-input" placeholder="Phone number" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label required">Relation</label>
                        <select name="relation" class="form-select" required>
                            <option value="Parent">Parent</option>
                            <option value="Sibling">Sibling</option>
                            <option value="Friend">Friend</option>
                            <option value="Relative">Relative</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label required">Purpose of Visit</label>
                        <select name="purpose" class="form-select" required>
                            <option value="Personal Visit">Personal Visit</option>
                            <option value="Emergency">Emergency</option>
                            <option value="Delivery">Delivery</option>
                            <option value="Official">Official Work</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                </div>

                <div style="margin-top: var(--space-lg); padding: var(--space-lg); background: var(--color-info-light); border-radius: var(--radius-lg); border-left: 4px solid var(--color-info);">
                    <div style="font-weight: var(--font-semibold); margin-bottom: var(--space-xs);">Important Notes:</div>
                    <ul style="margin: 0; padding-left: var(--space-xl); color: var(--color-gray-700);">
                        <li>Visitors must check in at the security gate</li>
                        <li>Valid ID is required for all visitors</li>
                        <li>Visiting hours: 9:00 AM - 8:00 PM</li>
                        <li>Overnight guests require prior approval</li>
                    </ul>
                </div>

                <button type="submit" name="register_visitor" class="btn btn-primary" style="margin-top: var(--space-lg);">
                    ✓ Register Visitor
                </button>
            </form>
        </div>
    </div>

    <!-- Visitor History -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Visitor History</h2>
        </div>
        <div class="card-body">
            <?php if ($visitors->num_rows > 0): ?>
                <div style="overflow-x: auto;">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Visitor Name</th>
                                <th>Contact</th>
                                <th>Relation</th>
                                <th>Purpose</th>
                                <th>Check In</th>
                                <th>Check Out</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($visitor = $visitors->fetch_assoc()): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($visitor['visitor_name']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($visitor['visitor_phone']); ?></td>
                                    <td><?php echo htmlspecialchars($visitor['relation']); ?></td>
                                    <td><?php echo htmlspecialchars($visitor['purpose']); ?></td>
                                    <td>
                                        <div style="font-size: var(--text-sm);">
                                            <?php echo date('d M Y', strtotime($visitor['visit_date'])); ?><br>
                                            <span style="color: var(--color-gray-600);"><?php echo date('h:i A', strtotime($visitor['in_time'])); ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ($visitor['out_time']): ?>
                                            <div style="font-size: var(--text-sm);">
                                                <?php echo date('d M Y', strtotime($visitor['visit_date'])); ?><br>
                                                <span style="color: var(--color-gray-600);"><?php echo date('h:i A', strtotime($visitor['out_time'])); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <span style="color: var(--color-gray-500);">Not checked out</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($visitor['out_time']): ?>
                                            <span class="badge badge-primary">Completed</span>
                                        <?php else: ?>
                                            <span class="badge badge-success">Currently Visiting</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div style="padding: var(--space-3xl); text-align: center; color: var(--color-gray-500);">
                    <div style="font-size: 4rem; margin-bottom: var(--space-lg);">👥</div>
                    <h3>No Visitor History</h3>
                    <p>You haven't registered any visitors yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
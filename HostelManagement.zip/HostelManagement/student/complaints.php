<?php
require_once '../includes/config.php';
requireStudentLogin();

$page_title = 'My Complaints';
$student = getStudentById($_SESSION['student_id']);

// Handle complaint submission
if (isset($_POST['submit_complaint'])) {
    $subject = sanitize($_POST['subject']);
    $category = sanitize($_POST['category']);
    $priority = sanitize($_POST['priority']);
    $description = sanitize($_POST['description']);

    $sql = "INSERT INTO complaints (student_id, subject, category, priority, description) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issss", $_SESSION['student_id'], $subject, $category, $priority, $description);

    if ($stmt->execute()) {
        $success = "Complaint submitted successfully!";
    } else {
        $error = "Error submitting complaint: " . $conn->error;
    }
}

// Get student's complaints
$complaints = $conn->query("SELECT * FROM complaints WHERE student_id = " . $_SESSION['student_id'] . " ORDER BY created_at DESC");

// Get statistics
$total_complaints = $conn->query("SELECT COUNT(*) as count FROM complaints WHERE student_id = " . $_SESSION['student_id'])->fetch_assoc()['count'];
$pending_complaints = $conn->query("SELECT COUNT(*) as count FROM complaints WHERE student_id = " . $_SESSION['student_id'] . " AND status = 'Pending'")->fetch_assoc()['count'];
$resolved_complaints = $conn->query("SELECT COUNT(*) as count FROM complaints WHERE student_id = " . $_SESSION['student_id'] . " AND status = 'Resolved'")->fetch_assoc()['count'];

include '../includes/header.php';
include '../includes/student-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            My Complaints
        </h1>
        <p style="color: var(--color-gray-600);">Submit and track your complaints</p>
    </div>

    <?php if (isset($success)): ?>
        <div class="alert alert-success" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✓</span>
            <div class="alert-content"><?php echo $success; ?></div>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="alert alert-error" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✕</span>
            <div class="alert-content"><?php echo $error; ?></div>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-2xl);">
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-primary-light);">📝</div>
            <div class="stat-details">
                <div class="stat-label">Total Complaints</div>
                <div class="stat-value"><?php echo $total_complaints; ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-warning-light);">⏳</div>
            <div class="stat-details">
                <div class="stat-label">Pending</div>
                <div class="stat-value"><?php echo $pending_complaints; ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-success-light);">✓</div>
            <div class="stat-details">
                <div class="stat-label">Resolved</div>
                <div class="stat-value"><?php echo $resolved_complaints; ?></div>
            </div>
        </div>
    </div>

    <!-- Submit Complaint Form -->
    <div class="card" style="margin-bottom: var(--space-2xl);">
        <div class="card-header">
            <h2 class="card-title">📝 Submit New Complaint</h2>
        </div>
        <div class="card-body">
            <form method="POST">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-lg);">
                    <div class="form-group">
                        <label class="form-label required">Subject</label>
                        <input type="text" name="subject" class="form-input" placeholder="Brief summary of issue" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label required">Category</label>
                        <select name="category" class="form-select" required>
                            <option value="Room">Room Issue</option>
                            <option value="Bathroom">Bathroom</option>
                            <option value="Electrical">Electrical</option>
                            <option value="Water">Water Supply</option>
                            <option value="Furniture">Furniture</option>
                            <option value="WiFi">WiFi/Internet</option>
                            <option value="Cleanliness">Cleanliness</option>
                            <option value="Security">Security</option>
                            <option value="Noise">Noise Complaint</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label required">Priority</label>
                        <select name="priority" class="form-select" required>
                            <option value="Low">Low</option>
                            <option value="Medium" selected>Medium</option>
                            <option value="High">High</option>
                            <option value="Urgent">Urgent</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label required">Description</label>
                    <textarea name="description" class="form-textarea" rows="5" placeholder="Provide detailed description of the issue..." required></textarea>
                </div>

                <button type="submit" name="submit_complaint" class="btn btn-primary">
                    📤 Submit Complaint
                </button>
            </form>
        </div>
    </div>

    <!-- Complaints History -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">My Complaint History</h2>
        </div>
        <div class="card-body">
            <?php if ($complaints->num_rows > 0): ?>
                <div style="display: grid; gap: var(--space-lg);">
                    <?php while ($complaint = $complaints->fetch_assoc()): ?>
                        <div style="padding: var(--space-xl); border: 2px solid var(--color-gray-200); border-radius: var(--radius-xl);">
                            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: var(--space-md);">
                                <div>
                                    <div style="display: flex; gap: var(--space-md); align-items: center; margin-bottom: var(--space-sm);">
                                        <h3 style="font-size: var(--text-xl); font-weight: var(--font-bold); margin: 0;">
                                            <?php echo htmlspecialchars($complaint['subject']); ?>
                                        </h3>
                                        <?php echo getStatusBadge($complaint['status']); ?>
                                        <span class="badge <?php
                                                            echo match ($complaint['priority']) {
                                                                'Urgent' => 'badge-error',
                                                                'High' => 'badge-warning',
                                                                'Medium' => 'badge-info',
                                                                default => 'badge-primary'
                                                            };
                                                            ?>">
                                            <?php echo $complaint['priority']; ?>
                                        </span>
                                        <span class="badge badge-primary">
                                            <?php echo $complaint['category']; ?>
                                        </span>
                                    </div>
                                    <div style="font-size: var(--text-sm); color: var(--color-gray-600);">
                                        Submitted: <?php echo formatDateTime($complaint['created_at']); ?>
                                        <?php if ($complaint['resolved_at']): ?>
                                            • Resolved: <?php echo formatDateTime($complaint['resolved_at']); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div style="background: var(--color-gray-50); padding: var(--space-lg); border-radius: var(--radius-lg); margin-bottom: var(--space-md);">
                                <div style="font-weight: var(--font-semibold); margin-bottom: var(--space-xs);">Description:</div>
                                <div style="color: var(--color-gray-700);">
                                    <?php echo nl2br(htmlspecialchars($complaint['description'])); ?>
                                </div>
                            </div>

                            <?php if ($complaint['admin_notes']): ?>
                                <div style="background: var(--color-info-light); padding: var(--space-lg); border-radius: var(--radius-lg); border-left: 4px solid var(--color-info);">
                                    <div style="font-weight: var(--font-semibold); margin-bottom: var(--space-xs);">
                                        Admin Response:
                                    </div>
                                    <div style="color: var(--color-gray-700);">
                                        <?php echo nl2br(htmlspecialchars($complaint['admin_notes'])); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div style="padding: var(--space-3xl); text-align: center; color: var(--color-gray-500);">
                    <div style="font-size: 4rem; margin-bottom: var(--space-lg);">📝</div>
                    <h3>No Complaints Submitted</h3>
                    <p>You haven't submitted any complaints yet. Use the form above to report any issues.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
<?php
require_once __DIR__ . '/../includes/config.php';

header('Content-Type: application/json');

// Get user message
$message = isset($_POST['message']) ? trim($_POST['message']) : '';

if (empty($message)) {
    echo json_encode(['response' => 'Please type a message!', 'suggestions' => []]);
    exit;
}

// Normalize message
$msg = strtolower($message);

// Command detection
if (strpos($msg, '/') === 0) {
    handleCommand($msg);
} else {
    handleQuery($msg);
}

function handleCommand($cmd)
{
    $cmd = trim($cmd);

    $commands = [
        '/help' => [
            'response' => "📋 **Available Commands:**\n\n" .
                "🏠 `/rooms` - Room booking information\n" .
                "💰 `/fees` - Fee structure and payment\n" .
                "📝 `/complaint` - File a complaint\n" .
                "🔧 `/maintenance` - Maintenance requests\n" .
                "👥 `/visitor` - Visitor registration\n" .
                "🍽️ `/menu` - Mess menu\n" .
                "👤 `/profile` - Manage your profile\n" .
                "📞 `/contact` - Contact information\n" .
                "ℹ️ `/about` - About the hostel\n\n" .
                "Or just ask me anything!",
            'suggestions' => ['Room Booking', 'Check Fees', 'File Complaint']
        ],
        '/rooms' => [
            'response' => "🏠 **Room Booking Information**\n\n" .
                "We offer various room types:\n" .
                "• Single Room - ₹12,000/semester\n" .
                "• Double Room - ₹8,000/semester\n" .
                "• Triple Room - ₹6,000/semester\n" .
                "• Quad Room - ₹5,000/semester\n\n" .
                "To book a room:\n" .
                "1. Go to 'Book Room' page\n" .
                "2. Browse available rooms\n" .
                "3. Select your preferred room\n" .
                "4. Complete payment\n\n" .
                "📍 [Book a Room](/HostelManagement/student/book_room.php)",
            'suggestions' => ['View My Room', 'Payment Info', 'Room Facilities']
        ],
        '/fees' => [
            'response' => "💰 **Fee Information**\n\n" .
                "**Payment Methods:**\n" .
                "• UPI (PhonePe, Google Pay, Paytm)\n" .
                "• Bank Transfer\n" .
                "• Online Banking\n\n" .
                "**Fee Structure:**\n" .
                "• Room Rent: ₹5,000 - ₹12,000/semester\n" .
                "• Security Deposit: ₹3,000 (refundable)\n" .
                "• Mess Fees: ₹4,000/month\n\n" .
                "📍 [View My Fees](/HostelManagement/student/fees.php)",
            'suggestions' => ['Pay Fees', 'Payment History', 'Fee Structure']
        ],
        '/complaint' => [
            'response' => "📝 **File a Complaint**\n\n" .
                "You can file complaints about:\n" .
                "• Room issues\n" .
                "• Cleanliness\n" .
                "• Food quality\n" .
                "• Facilities\n" .
                "• Noise/Disturbance\n\n" .
                "We respond within 24-48 hours.\n\n" .
                "📍 [File Complaint](/HostelManagement/student/complaints.php)",
            'suggestions' => ['My Complaints', 'Maintenance Request', 'Contact Admin']
        ],
        '/maintenance' => [
            'response' => "🔧 **Maintenance Requests**\n\n" .
                "Report maintenance issues:\n" .
                "• Electrical problems\n" .
                "• Plumbing issues\n" .
                "• Furniture repair\n" .
                "• AC/Fan problems\n" .
                "• Door/Window issues\n\n" .
                "Our team responds within 24 hours.\n\n" .
                "📍 [Request Maintenance](/HostelManagement/student/maintenance.php)",
            'suggestions' => ['My Requests', 'File Complaint', 'Emergency Contact']
        ],
        '/visitor' => [
            'response' => "👥 **Visitor Registration**\n\n" .
                "**Visitor Rules:**\n" .
                "• Register all visitors in advance\n" .
                "• Visiting hours: 9 AM - 6 PM\n" .
                "• Valid ID required\n" .
                "• Maximum 2 visitors at a time\n\n" .
                "📍 [Register Visitor](/HostelManagement/student/visitors.php)",
            'suggestions' => ['My Visitors', 'Visitor Rules', 'Contact Info']
        ],
        '/menu' => [
            'response' => "🍽️ **Mess Menu**\n\n" .
                "View the weekly mess menu for:\n" .
                "• Breakfast (7-9 AM)\n" .
                "• Lunch (12-2 PM)\n" .
                "• Snacks (4-5 PM)\n" .
                "• Dinner (7-9 PM)\n\n" .
                "Special meals on weekends!\n\n" .
                "📍 [View Menu](/HostelManagement/student/mess-menu.php)",
            'suggestions' => ["Today's Menu", 'Mess Timings', 'Food Complaint']
        ],
        '/profile' => [
            'response' => "👤 **Profile Management**\n\n" .
                "Update your profile:\n" .
                "• Personal information\n" .
                "• Contact details\n" .
                "• Emergency contacts\n" .
                "• Profile photo\n\n" .
                "📍 [Edit Profile](/HostelManagement/student/profile.php)",
            'suggestions' => ['View Profile', 'Change Password', 'Update Photo']
        ],
        '/contact' => [
            'response' => "📞 **Contact Information**\n\n" .
                "**Hostel Office:**\n" .
                "📧 Email: hostel@sbte.bihar.gov.in\n" .
                "📱 Phone: +91-XXX-XXXXXXX\n\n" .
                "**Emergency:**\n" .
                "🚨 24/7 Helpline: +91-XXX-XXXXXXX\n\n" .
                "**Address:**\n" .
                "SBTE Bihar Hostel\n" .
                "Patna, Bihar",
            'suggestions' => ['File Complaint', 'Maintenance', 'Emergency']
        ],
        '/about' => [
            'response' => "ℹ️ **About SBTE Hostel**\n\n" .
                "Welcome to State Board of Technical Education Bihar Hostel!\n\n" .
                "**Facilities:**\n" .
                "• 24/7 Security\n" .
                "• WiFi Connectivity\n" .
                "• Mess Services\n" .
                "• Common Room\n" .
                "• Study Hall\n" .
                "• Laundry Service\n\n" .
                "**Rules:**\n" .
                "• Curfew: 10 PM\n" .
                "• No outside guests after 6 PM\n" .
                "• Maintain cleanliness",
            'suggestions' => ['Facilities', 'Rules', 'Contact Info']
        ]
    ];

    if (isset($commands[$cmd])) {
        echo json_encode($commands[$cmd]);
    } else {
        echo json_encode([
            'response' => "❌ Unknown command. Type `/help` to see all available commands.",
            'suggestions' => ['Show Help', 'Room Booking', 'Check Fees']
        ]);
    }
}

function handleQuery($msg)
{
    // Keyword-based response system
    $responses = [
        'greeting' => [
            'keywords' => ['hi', 'hello', 'hey', 'namaste', 'good morning', 'good afternoon', 'good evening'],
            'response' => "👋 Hello! I'm your SBTE Hostel Assistant. How can I help you today?",
            'suggestions' => ['Room Booking', 'Check Fees', 'File Complaint', 'View Menu']
        ],
        'room_booking' => [
            'keywords' => ['room', 'book', 'booking', 'reserve', 'accommodation'],
            'response' => "🏠 Looking for room information? We have Single, Double, Triple, and Quad rooms available.\n\nType `/rooms` for detailed information or visit the booking page.",
            'suggestions' => ['Room Types', 'Book Now', 'Fee Structure']
        ],
        'fees' => [
            'keywords' => ['fee', 'payment', 'pay', 'charge', 'cost', 'price', 'money'],
            'response' => "💰 Fee information:\n• Room fees range from ₹5,000 to ₹12,000/semester\n• Mess fees: ₹4,000/month\n\nType `/fees` for complete details.",
            'suggestions' => ['Pay Fees', 'Fee Structure', 'Payment Methods']
        ],
        'complaint' => [
            'keywords' => ['complaint', 'problem', 'issue', 'complain'],
            'response' => "📝 I can help you file a complaint. Type `/complaint` for details or go directly to the complaints page.",
            'suggestions' => ['File Complaint', 'My Complaints', 'Contact Admin']
        ],
        'maintenance' => [
            'keywords' => ['repair', 'fix', 'broken', 'maintenance', 'not working'],
            'response' => "🔧 Need maintenance? Report electrical, plumbing, or other issues. Type `/maintenance` for more info.",
            'suggestions' => ['Request Maintenance', 'My Requests', 'Emergency']
        ],
        'visitor' => [
            'keywords' => ['visitor', 'guest', 'visit', 'parent'],
            'response' => "👥 Visitor registration info:\n• Hours: 9 AM - 6 PM\n• ID required\n\nType `/visitor` for complete rules.",
            'suggestions' => ['Register Visitor', 'Visitor Rules', 'Contact']
        ],
        'menu' => [
            'keywords' => ['food', 'menu', 'mess', 'meal', 'breakfast', 'lunch', 'dinner', 'eat'],
            'response' => "🍽️ Our mess serves breakfast, lunch, snacks, and dinner. Type `/menu` to view the weekly menu.",
            'suggestions' => ["Today's Menu", 'Mess Timings', 'Food Quality']
        ],
        'profile' => [
            'keywords' => ['profile', 'account', 'details', 'information', 'update'],
            'response' => "👤 You can update your profile, contact details, and photo. Type `/profile` for more options.",
            'suggestions' => ['Edit Profile', 'Change Password', 'View Profile']
        ],
        'contact' => [
            'keywords' => ['contact', 'phone', 'email', 'call', 'reach'],
            'response' => "📞 Contact information:\n📧 hostel@sbte.bihar.gov.in\n📱 24/7 Helpline available\n\nType `/contact` for complete details.",
            'suggestions' => ['Contact Info', 'Emergency', 'Office Hours']
        ],
        'help' => [
            'keywords' => ['help', 'guide', 'how', 'what', 'commands'],
            'response' => "ℹ️ I can help you with:\n• Room booking\n• Fee payments\n• Complaints\n• Maintenance\n• Visitors\n• Mess menu\n\nType `/help` to see all commands.",
            'suggestions' => ['Show Commands', 'Room Booking', 'Contact Info']
        ]
    ];

    // Find matching response
    foreach ($responses as $category => $data) {
        foreach ($data['keywords'] as $keyword) {
            if (strpos($msg, $keyword) !== false) {
                echo json_encode([
                    'response' => $data['response'],
                    'suggestions' => $data['suggestions']
                ]);
                return;
            }
        }
    }

    // Default fallback
    echo json_encode([
        'response' => "I'm here to help! You can ask me about:\n\n" .
            "• Room booking and availability\n" .
            "• Fee structure and payments\n" .
            "• Filing complaints\n" .
            "• Maintenance requests\n" .
            "• Visitor registration\n" .
            "• Mess menu and timings\n\n" .
            "Type `/help` to see all available commands!",
        'suggestions' => ['Show Help', 'Room Booking', 'Check Fees', 'Contact Info']
    ]);
}

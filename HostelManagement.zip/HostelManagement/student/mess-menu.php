<?php
require_once '../includes/config.php';
requireStudentLogin();

$page_title = 'Mess Menu';

// Get current day of week
$current_day = date('l');

// Get all mess menu items
$menu_items = $conn->query("SELECT * FROM mess_menu ORDER BY FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), meal_type");

// Group by day and meal type
$menu = [];
while ($item = $menu_items->fetch_assoc()) {
    $menu[$item['day_of_week']][$item['meal_type']] = $item;
}

$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
$meals = ['Breakfast', 'Lunch', 'Snacks', 'Dinner'];

// Define standard meal timings
$meal_timings = [
    'Breakfast' => '7:30 AM - 9:00 AM',
    'Lunch' => '12:30 PM - 2:00 PM',
    'Snacks' => '4:30 PM - 5:30 PM',
    'Dinner' => '7:30 PM - 9:00 PM'
];

include '../includes/header.php';
include '../includes/student-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            🍽️ Mess Menu
        </h1>
        <p style="color: var(--color-gray-600);">Weekly meal schedule</p>
    </div>

    <!-- Current Day Highlight -->
    <div class="card" style="margin-bottom: var(--space-2xl); background: var(--gradient-primary); color: white;">
        <div class="card-body" style="text-align: center;">
            <h2 style="font-size: var(--text-2xl); margin-bottom: var(--space-sm);">Today's Menu - <?php echo $current_day; ?></h2>
            <?php if (isset($menu[$current_day])): ?>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: var(--space-lg); margin-top: var(--space-lg);">
                    <?php foreach ($meals as $meal): ?>
                        <?php if (isset($menu[$current_day][$meal])): ?>
                            <div style="background: rgba(255,255,255,0.2); padding: var(--space-lg); border-radius: var(--radius-lg); backdrop-filter: blur(10px);">
                                <div style="font-weight: var(--font-bold); margin-bottom: var(--space-sm); opacity: 0.9;">
                                    <?php
                                    echo match ($meal) {
                                        'Breakfast' => '🌅',
                                        'Lunch' => '☀️',
                                        'Snacks' => '🍪',
                                        'Dinner' => '🌙',
                                        default => '🍽️'
                                    };
                                    ?> <?php echo $meal; ?>
                                </div>
                                <div style="font-size: var(--text-lg);">
                                    <?php echo nl2br(htmlspecialchars($menu[$current_day][$meal]['menu_items'])); ?>
                                </div>
                                <div style="margin-top: var(--space-sm); font-size: var(--text-sm); opacity: 0.8;">
                                    <?php echo $meal_timings[$meal]; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>No menu available for today.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Weekly Menu -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">📅 Weekly Menu Schedule</h2>
        </div>
        <div class="card-body">
            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th style="min-width: 120px;">Day</th>
                            <th>🌅 Breakfast</th>
                            <th>☀️ Lunch</th>
                            <th>🍪 Snacks</th>
                            <th>🌙 Dinner</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($days as $day): ?>
                            <tr style="<?php echo ($day == $current_day) ? 'background: var(--color-primary-light);' : ''; ?>">
                                <td>
                                    <strong><?php echo $day; ?></strong>
                                    <?php if ($day == $current_day): ?>
                                        <span class="badge badge-primary" style="margin-left: var(--space-xs);">Today</span>
                                    <?php endif; ?>
                                </td>
                                <?php foreach ($meals as $meal): ?>
                                    <td>
                                        <?php if (isset($menu[$day][$meal])): ?>
                                            <div style="font-weight: var(--font-semibold); margin-bottom: var(--space-xs);">
                                                <?php echo nl2br(htmlspecialchars($menu[$day][$meal]['menu_items'])); ?>
                                            </div>
                                            <div style="font-size: var(--text-xs); color: var(--color-gray-600);">
                                                <?php echo $meal_timings[$meal]; ?>
                                            </div>
                                        <?php else: ?>
                                            <span style="color: var(--color-gray-400);">–</span>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Meal Timings Info -->
    <div style="margin-top: var(--space-2xl); display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg);">
        <div style="padding: var(--space-lg); background: var(--color-info-light); border-radius: var(--radius-lg); border-left: 4px solid var(--color-info);">
            <div style="font-weight: var(--font-bold); margin-bottom: var(--space-sm);">📋 Important Notes:</div>
            <ul style="margin: 0; padding-left: var(--space-xl); font-size: var(--text-sm);">
                <li>Please arrive on time for meals</li>
                <li>Wastage should be minimized</li>
                <li>Mess card is mandatory</li>
                <li>Maintain cleanliness</li>
            </ul>
        </div>

        <div style="padding: var(--space-lg); background: var(--color-success-light); border-radius: var(--radius-lg); border-left: 4px solid var(--color-success);">
            <div style="font-weight: var(--font-bold); margin-bottom: var(--space-sm);">🍽️ Mess Facilities:</div>
            <ul style="margin: 0; padding-left: var(--space-xl); font-size: var(--text-sm);">
                <li>Hygienic food preparation</li>
                <li>Nutritious balanced diet</li>
                <li>Spacious dining hall</li>
                <li>Water purifier available</li>
            </ul>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
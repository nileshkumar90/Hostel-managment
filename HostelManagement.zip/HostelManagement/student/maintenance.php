<?php
require_once '../includes/config.php';
requireStudentLogin();

$page_title = 'Maintenance Requests';
$student = getStudentById($_SESSION['student_id']);

// Handle maintenance request submission
if (isset($_POST['submit_request'])) {
    $category = sanitize($_POST['category']);
    $priority = sanitize($_POST['priority']);
    $description = sanitize($_POST['description']);

    // Get student's room_id
    $room_id = $student['room_id'] ? $student['room_id'] : 0;

    $sql = "INSERT INTO maintenance_requests (student_id, room_id, category, priority, description) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iisss", $_SESSION['student_id'], $room_id, $category, $priority, $description);

    if ($stmt->execute()) {
        $success = "Maintenance request submitted successfully!";
    } else {
        $error = "Error submitting request: " . $conn->error;
    }
}

// Get student's maintenance requests
$requests = $conn->query("SELECT * FROM maintenance_requests WHERE student_id = " . $_SESSION['student_id'] . " ORDER BY created_at DESC");

// Get statistics
$total_requests = $conn->query("SELECT COUNT(*) as count FROM maintenance_requests WHERE student_id = " . $_SESSION['student_id'])->fetch_assoc()['count'];
$pending_requests = $conn->query("SELECT COUNT(*) as count FROM maintenance_requests WHERE student_id = " . $_SESSION['student_id'] . " AND status = 'Pending'")->fetch_assoc()['count'];
$completed_requests = $conn->query("SELECT COUNT(*) as count FROM maintenance_requests WHERE student_id = " . $_SESSION['student_id'] . " AND status = 'Completed'")->fetch_assoc()['count'];

include '../includes/header.php';
include '../includes/student-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            🔧 Maintenance Requests
        </h1>
        <p style="color: var(--color-gray-600);">Submit and track maintenance requests</p>
    </div>

    <?php if (isset($success)): ?>
        <div class="alert alert-success" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✓</span>
            <div class="alert-content"><?php echo $success; ?></div>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="alert alert-error" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✕</span>
            <div class="alert-content"><?php echo $error; ?></div>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-2xl);">
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-primary-light);">🔧</div>
            <div class="stat-details">
                <div class="stat-label">Total Requests</div>
                <div class="stat-value"><?php echo $total_requests; ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-warning-light);">⏳</div>
            <div class="stat-details">
                <div class="stat-label">Pending</div>
                <div class="stat-value"><?php echo $pending_requests; ?></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon" style="background: var(--color-success-light);">✓</div>
            <div class="stat-details">
                <div class="stat-label">Completed</div>
                <div class="stat-value"><?php echo $completed_requests; ?></div>
            </div>
        </div>
    </div>

    <!-- Submit Request Form -->
    <div class="card" style="margin-bottom: var(--space-2xl);">
        <div class="card-header">
            <h2 class="card-title">🔧 Submit New Maintenance Request</h2>
        </div>
        <div class="card-body">
            <form method="POST">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg); margin-bottom: var(--space-lg);">
                    <div class="form-group">
                        <label class="form-label required">Issue Type</label>
                        <select name="category" class="form-select" required>
                            <option value="Electrical">Electrical Issue</option>
                            <option value="Plumbing">Plumbing</option>
                            <option value="Furniture">Furniture Repair</option>
                            <option value="Appliance">AC/Fan/Appliance</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label required">Priority</label>
                        <select name="priority" class="form-select" required>
                            <option value="Low">Low</option>
                            <option value="Medium" selected>Medium</option>
                            <option value="High">High</option>
                            <option value="Urgent">Urgent</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label required">Description</label>
                    <textarea name="description" class="form-textarea" rows="4" placeholder="Describe the issue in detail..." required></textarea>
                </div>

                <button type="submit" name="submit_request" class="btn btn-primary">
                    📤 Submit Request
                </button>
            </form>
        </div>
    </div>

    <!-- Request History -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Request History</h2>
        </div>
        <div class="card-body">
            <?php if ($requests->num_rows > 0): ?>
                <div style="display: grid; gap: var(--space-lg);">
                    <?php while ($request = $requests->fetch_assoc()): ?>
                        <div style="padding: var(--space-xl); border: 2px solid var(--color-gray-200); border-radius: var(--radius-xl);">
                            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: var(--space-md);">
                                <div>
                                    <div style="display: flex; gap: var(--space-md); align-items: center; margin-bottom: var(--space-sm);">
                                        <h3 style="font-size: var(--text-xl); font-weight: var(--font-bold); margin: 0;">
                                            <?php echo htmlspecialchars($request['category']); ?>
                                        </h3>
                                        <?php echo getStatusBadge($request['status']); ?>
                                        <span class="badge <?php
                                                            echo match ($request['priority']) {
                                                                'Urgent' => 'badge-error',
                                                                'High' => 'badge-warning',
                                                                'Medium' => 'badge-info',
                                                                default => 'badge-primary'
                                                            };
                                                            ?>">
                                            <?php echo $request['priority']; ?>
                                        </span>
                                    </div>
                                    <div style="font-size: var(--text-sm); color: var(--color-gray-600);">
                                        Submitted: <?php echo formatDateTime($request['created_at']); ?>
                                        <?php if ($request['completed_at']): ?>
                                            • Completed: <?php echo formatDateTime($request['completed_at']); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div style="background: var(--color-gray-50); padding: var(--space-lg); border-radius: var(--radius-lg); margin-bottom: var(--space-md);">
                                <div style="font-weight: var(--font-semibold); margin-bottom: var(--space-xs);">Issue Description:</div>
                                <div style="color: var(--color-gray-700);">
                                    <?php echo nl2br(htmlspecialchars($request['description'])); ?>
                                </div>
                            </div>

                            <?php if ($request['admin_notes']): ?>
                                <div style="background: var(--color-info-light); padding: var(--space-lg); border-radius: var(--radius-lg); border-left: 4px solid var(--color-info);">
                                    <div style="font-weight: var(--font-semibold); margin-bottom: var(--space-xs);">
                                        Admin Response:
                                    </div>
                                    <div style="color: var(--color-gray-700);">
                                        <?php echo nl2br(htmlspecialchars($request['admin_notes'])); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div style="padding: var(--space-3xl); text-align: center; color: var(--color-gray-500);">
                    <div style="font-size: 4rem; margin-bottom: var(--space-lg);">🔧</div>
                    <h3>No Maintenance Requests</h3>
                    <p>You haven't submitted any maintenance requests yet. Use the form above to report any issues.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
<?php
require_once '../includes/config.php';
requireStudentLogin();

$page_title = 'Student Dashboard';
$student_id = $_SESSION['student_id'];

// Get student data
$student = getStudentById($student_id);

if (!$student) {
    session_unset();
    session_destroy();
    header("Location: ../login.php?error=Session invalid. Please login again.");
    exit();
}

// Get fee status
$fee_query = "SELECT * FROM fees WHERE student_id = ? ORDER BY due_date DESC LIMIT 1";
$stmt = $conn->prepare($fee_query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$latest_fee = $stmt->get_result()->fetch_assoc();

// Get pending complaints count
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM complaints WHERE student_id = ? AND status != 'Resolved'");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$pending_complaints = $stmt->get_result()->fetch_assoc()['count'];

// Get recent announcements
$announcements = $conn->query("SELECT * FROM announcements WHERE is_active = 1 ORDER BY created_at DESC LIMIT 5");

include '../includes/header.php';
include '../includes/student-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <!-- Professional Page Header -->
    <div class="page-header">
        <div style="display: flex; align-items: center; gap: var(--space-lg); margin-bottom: var(--space-md);">
            <div style="width: 64px; height: 64px; background: linear-gradient(135deg, var(--sbte-blue), var(--sbte-saffron)); border-radius: var(--radius-xl); display: flex; align-items: center; justify-content: center; color: white; font-size: 2rem; box-shadow: var(--shadow-lg);">
                🎓
            </div>
            <div>
                <h1 class="page-title">Student Dashboard</h1>
                <p class="page-subtitle">
                    Welcome back, <strong><?php echo htmlspecialchars(explode(' ', $student['name'] ?? 'Student')[0]); ?></strong>! 👋 Here's your overview.
                </p>
            </div>
        </div>
        <div style="display: flex; gap: var(--space-md); align-items: center; margin-top: var(--space-lg);">
            <span style="padding: 0.5rem 1rem; background: var(--sbte-light-blue); color: var(--sbte-dark-blue); border-radius: var(--radius-full); font-size: var(--text-sm); font-weight: var(--font-bold);">
                🏛️ SBTE Bihar HMS
            </span>
            <span style="color: var(--color-gray-500); font-size: var(--text-sm);">
                📅 <?php echo date('l, F j, Y'); ?>
            </span>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <!-- Fee Status -->
        <div class="stat-card animate-fadeInUp">
            <div class="stat-icon icon-primary">💳</div>
            <div class="stat-content">
                <div class="stat-label">Fee Status</div>
                <div class="stat-value" style="font-size: var(--text-2xl);">
                    <?php
                    if ($latest_fee) {
                        echo getStatusBadge($latest_fee['status']);
                    } else {
                        echo '<span class="badge badge-info">No Fee Due</span>';
                    }
                    ?>
                </div>
            </div>
        </div>

        <!-- Active Complaints -->
        <div class="stat-card animate-fadeInUp" style="animation-delay: 0.1s;">
            <div class="stat-icon icon-warning">📝</div>
            <div class="stat-content">
                <div class="stat-label">Active Complaints</div>
                <div class="stat-value" data-target="<?php echo $pending_complaints; ?>">
                    <?php echo $pending_complaints; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Two Column Layout -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(500px, 1fr)); gap: var(--space-2xl);">
        <!-- Recent Announcements -->
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">📢 Recent Announcements</h2>
                <a href="announcements.php" class="btn btn-sm btn-secondary">View All</a>
            </div>
            <div class="card-body">
                <?php if ($announcements->num_rows > 0): ?>
                    <div style="display: flex; flex-direction: column; gap: var(--space-md);">
                        <?php while ($announcement = $announcements->fetch_assoc()): ?>
                            <div style="padding: var(--space-md); border-radius: var(--radius-lg); background: var(--color-gray-50); border-left: 4px solid 
                                    <?php
                                    echo match ($announcement['priority']) {
                                        'High' => 'var(--color-error)',
                                        'Medium' => 'var(--color-warning)',
                                        default => 'var(--color-info)'
                                    };
                                    ?>;">
                                <div style="font-weight: var(--font-semibold); color: var(--color-gray-900); margin-bottom: var(--space-xs);">
                                    <?php echo htmlspecialchars($announcement['title']); ?>
                                </div>
                                <div style="font-size: var(--text-sm); color: var(--color-gray-600); margin-bottom: var(--space-sm);">
                                    <?php echo nl2br(htmlspecialchars(substr($announcement['content'], 0, 150))); ?>
                                    <?php if (strlen($announcement['content']) > 150) echo '...'; ?>
                                </div>
                                <div style="display: flex; gap: var(--space-md); font-size: var(--text-xs); color: var(--color-gray-500);">
                                    <span>📁 <?php echo $announcement['category']; ?></span>
                                    <span>🕐 <?php echo formatDate($announcement['created_at']); ?></span>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <p style="text-align: center; color: var(--color-gray-500); padding: var(--space-xl);">
                        No announcements available
                    </p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quick Actions & Profile -->
        <div style="display: flex; flex-direction: column; gap: var(--space-2xl);">
            <!-- Quick Actions -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">⚡ Quick Actions</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: var(--space-md);">
                        <a href="fees.php" class="btn btn-primary" style="justify-content: center;">
                            💳 Pay Fees
                        </a>
                        <a href="complaints.php" class="btn btn-primary" style="justify-content: center;">
                            📝 Complaint
                        </a>
                        <a href="visitors.php" class="btn btn-primary" style="justify-content: center;">
                            👥 Visitor
                        </a>
                        <a href="maintenance.php" class="btn btn-primary" style="justify-content: center;">
                            🔧 Maintenance
                        </a>
                        <a href="mess-menu.php" class="btn btn-primary" style="justify-content: center;">
                            🍽️ Mess Menu
                        </a>
                        <a href="profile.php" class="btn btn-secondary" style="justify-content: center;">
                            👤 Profile
                        </a>
                    </div>
                </div>
            </div>

            <!-- Profile Summary -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">👤 My Profile</h2>
                    <a href="profile.php" class="btn btn-sm btn-secondary">Edit</a>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: var(--space-lg);">
                        <div>
                            <div style="font-size: var(--text-sm); color: var(--color-gray-600); margin-bottom: var(--space-xs);">Roll Number</div>
                            <div style="font-weight: var(--font-semibold);"><?php echo htmlspecialchars($student['roll_number'] ?? 'N/A'); ?></div>
                        </div>
                        <div>
                            <div style="font-size: var(--text-sm); color: var(--color-gray-600); margin-bottom: var(--space-xs);">Branch</div>
                            <div style="font-weight: var(--font-semibold);"><?php echo htmlspecialchars($student['branch'] ?? 'N/A'); ?></div>
                        </div>
                        <div>
                            <div style="font-size: var(--text-sm); color: var(--color-gray-600); margin-bottom: var(--space-xs);">Email</div>
                            <div style="font-weight: var(--font-semibold);"><?php echo htmlspecialchars($student['email'] ?? 'N/A'); ?></div>
                        </div>
                        <div>
                            <div style="font-size: var(--text-sm); color: var(--color-gray-600); margin-bottom: var(--space-xs);">Phone</div>
                            <div style="font-weight: var(--font-semibold);"><?php echo htmlspecialchars($student['phone'] ?? 'N/A'); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
<?php
require_once '../includes/config.php';
requireStudentLogin();

$student_id = $_SESSION['student_id'];
$student = getStudentById($student_id);

// Check if student already has a room or pending room
if (!empty($student['room_id'])) {
    $_SESSION['error'] = "You already have a room assigned.";
    header("Location: room.php");
    exit();
}

if (!empty($student['pending_room_id'])) {
    $_SESSION['error'] = "You already have a pending room booking. Please complete the payment first.";
    header("Location: fees.php");
    exit();
}

// Get room_id from request
$room_id = isset($_GET['room_id']) ? (int)$_GET['room_id'] : 0;

if ($room_id <= 0) {
    $_SESSION['error'] = "Invalid room selected.";
    header("Location: book_room.php");
    exit();
}

// Get room details
$room_query = $conn->prepare("SELECT * FROM rooms WHERE id = ? AND status = 'Available'");
$room_query->bind_param("i", $room_id);
$room_query->execute();
$room = $room_query->get_result()->fetch_assoc();

if (!$room) {
    $_SESSION['error'] = "Room not available or doesn't exist.";
    header("Location: book_room.php");
    exit();
}

// Check if room has available capacity (including pending bookings)
$pending_count_query = $conn->query("SELECT COUNT(*) as count FROM students WHERE pending_room_id = " . $room_id);
$pending_count = $pending_count_query->fetch_assoc()['count'];

if (($room['occupied'] + $pending_count) >= $room['capacity']) {
    $_SESSION['error'] = "Room is fully occupied (including pending bookings).";
    header("Location: book_room.php");
    exit();
}

// Start transaction
$conn->begin_transaction();

try {
    // 1. Update student's pending_room_id
    $update_student = $conn->prepare("UPDATE students SET pending_room_id = ? WHERE id = ?");
    $update_student->bind_param("ii", $room_id, $student_id);

    if (!$update_student->execute()) {
        throw new Exception("Failed to update student record.");
    }

    // 2. Update room status to Reserved
    $new_status = ($room['occupied'] + 1 >= $room['capacity']) ? 'Reserved' : 'Available';
    $update_room = $conn->prepare("UPDATE rooms SET status = ? WHERE id = ?");
    $update_room->bind_param("si", $new_status, $room_id);

    if (!$update_room->execute()) {
        throw new Exception("Failed to update room status.");
    }

    // 3. Create fee entry for room booking
    $fee_type = "Hostel - " . $room['block'] . "-" . $room['room_number'];
    $due_date = date('Y-m-d', strtotime('+7 days')); // 7 days to pay
    $amount = $room['fees'];

    $create_fee = $conn->prepare("INSERT INTO fees (student_id, fee_type, amount, paid_amount, due_date, status, created_at) VALUES (?, ?, ?, 0, ?, 'Pending', NOW())");
    $create_fee->bind_param("isds", $student_id, $fee_type, $amount, $due_date);

    if (!$create_fee->execute()) {
        throw new Exception("Failed to create fee entry.");
    }

    // Commit transaction
    $conn->commit();

    $_SESSION['success'] = "🎉 Room " . $room['block'] . "-" . $room['room_number'] . " has been reserved for you! Please complete the payment within 7 days to confirm your booking.";
    header("Location: fees.php");
    exit();
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();

    $_SESSION['error'] = "❌ Booking failed: " . $e->getMessage();
    header("Location: book_room.php");
    exit();
}

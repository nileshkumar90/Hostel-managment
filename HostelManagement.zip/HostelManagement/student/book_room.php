<?php
require_once '../includes/config.php';
requireStudentLogin();

$page_title = 'Book a Room';
$student_id = $_SESSION['student_id'];
$student = getStudentById($student_id);

// Redirect if already has a room
if (!empty($student['room_id'])) {
    header("Location: room.php");
    exit();
}

// Filter Logic
$block_filter = $_GET['block'] ?? '';
$type_filter = $_GET['type'] ?? '';
$price_min = $_GET['price_min'] ?? 0;
$price_max = $_GET['price_max'] ?? 10000;

// Modified query to include pending bookings count
$query = "SELECT r.*, 
          (SELECT COUNT(*) FROM students s WHERE s.pending_room_id = r.id) as pending_count 
          FROM rooms r 
          WHERE r.status = 'Available'";
$params = [];
$types = "";

if ($block_filter) {
    $query .= " AND r.block = ?";
    $params[] = $block_filter;
    $types .= "s";
}

if ($type_filter) {
    $query .= " AND r.room_type = ?";
    $params[] = $type_filter;
    $types .= "s";
}

if ($price_min > 0) {
    $query .= " AND r.fees >= ?";
    $params[] = $price_min;
    $types .= "d";
}

if ($price_max < 10000) {
    $query .= " AND r.fees <= ?";
    $params[] = $price_max;
    $types .= "d";
}

// Filter out fully booked rooms (occupied + pending >= capacity)
$query .= " AND (r.occupied + (SELECT COUNT(*) FROM students s WHERE s.pending_room_id = r.id)) < r.capacity";

$query .= " ORDER BY r.block, r.room_number";

if (!empty($types)) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $rooms = $stmt->get_result();
} else {
    $rooms = $conn->query($query);
}

include '../includes/header.php';
include '../includes/student-nav.php';
?>

<style>
    .room-card {
        transition: all var(--transition-base);
        border: none;
        display: flex;
        flex-direction: column;
        height: 100%;
    }

    .room-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15) !important;
    }

    .room-card-header {
        text-align: center;
        padding: var(--space-2xl);
        color: white;
        position: relative;
        overflow: hidden;
        background-size: 200% 200%;
        animation: gradientShift 5s ease infinite;
    }

    @keyframes gradientShift {

        0%,
        100% {
            background-position: 0% 50%;
        }

        50% {
            background-position: 100% 50%;
        }
    }

    .room-icon {
        font-size: 3rem;
        margin-bottom: var(--space-sm);
        filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.2));
    }

    .amenity-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        background: white;
        padding: 4px 10px;
        border-radius: 20px;
        font-size: var(--text-xs);
        color: var(--color-gray-700);
        margin: 2px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
    }

    .price-tag {
        position: absolute;
        top: 10px;
        right: 10px;
        background: rgba(255, 255, 255, 0.95);
        padding: var(--space-sm) var(--space-md);
        border-radius: var(--radius-lg);
        font-weight: bold;
        font-size: var(--text-lg);
        color: var(--color-primary);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    .filter-section {
        background: linear-gradient(135deg, rgba(99, 102, 241, 0.05) 0%, rgba(79, 70, 229, 0.05) 100%);
        padding: var(--space-xl);
        border-radius: var(--radius-xl);
        margin-bottom: var(--space-2xl);
        border: 2px solid rgba(99, 102, 241, 0.1);
    }

    .room-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 4px 12px;
        border-radius: 20px;
        background: rgba(255, 255, 255, 0.2);
        color: white;
        font-size: var(--text-sm);
        font-weight: 500;
    }
</style>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl); text-align: center;">
        <h1 style="font-size: var(--text-5xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm); background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">
            🏠 Book Your Dream Room
        </h1>
        <p style="color: var(--color-gray-600); font-size: var(--text-lg);">Find the perfect room that suits your style and budget</p>
    </div>

    <!-- Enhanced Filters -->
    <div class="filter-section">
        <form method="GET" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: var(--space-lg); align-items: end;">
            <div>
                <label style="display: block; margin-bottom: var(--space-xs); font-weight: var(--font-semibold); color: var(--color-gray-700);">
                    🏢 Block
                </label>
                <select name="block" class="form-control" style="padding: var(--space-md);">
                    <option value="">All Blocks</option>
                    <option value="A" <?php echo $block_filter == 'A' ? 'selected' : ''; ?>>Block A - Premium</option>
                    <option value="B" <?php echo $block_filter == 'B' ? 'selected' : ''; ?>>Block B - Standard</option>
                    <option value="C" <?php echo $block_filter == 'C' ? 'selected' : ''; ?>>Block C - Budget</option>
                    <option value="D" <?php echo $block_filter == 'D' ? 'selected' : ''; ?>>Block D - Economy</option>
                </select>
            </div>
            <div>
                <label style="display: block; margin-bottom: var(--space-xs); font-weight: var(--font-semibold); color: var(--color-gray-700);">
                    🛏️ Room Type
                </label>
                <select name="type" class="form-control" style="padding: var(--space-md);">
                    <option value="">All Types</option>
                    <option value="Single" <?php echo $type_filter == 'Single' ? 'selected' : ''; ?>>Single (AC)</option>
                    <option value="Double" <?php echo $type_filter == 'Double' ? 'selected' : ''; ?>>Double</option>
                    <option value="Triple" <?php echo $type_filter == 'Triple' ? 'selected' : ''; ?>>Triple</option>
                    <option value="Dorm" <?php echo $type_filter == 'Dorm' ? 'selected' : ''; ?>>Dormitory</option>
                </select>
            </div>
            <div>
                <label style="display: block; margin-bottom: var(--space-xs); font-weight: var(--font-semibold); color: var(--color-gray-700);">
                    💰 Min Price
                </label>
                <input type="number" name="price_min" class="form-control" value="<?php echo $price_min; ?>" min="0" step="500" placeholder="₹0" style="padding: var(--space-md);">
            </div>
            <div>
                <label style="display: block; margin-bottom: var(--space-xs); font-weight: var(--font-semibold); color: var(--color-gray-700);">
                    💰 Max Price
                </label>
                <input type="number" name="price_max" class="form-control" value="<?php echo $price_max; ?>" max="10000" step="500" placeholder="₹10000" style="padding: var(--space-md);">
            </div>
            <button type="submit" class="btn btn-primary" style="padding: var(--space-md); font-weight: var(--font-semibold);">
                🔍 Apply Filters
            </button>
            <a href="book_room.php" class="btn btn-secondary" style="padding: var(--space-md); text-align: center;">
                ↺ Reset
            </a>
        </form>
    </div>

    <!-- Room Count -->
    <?php if ($rooms->num_rows > 0): ?>
        <div style="margin-bottom: var(--space-lg); padding: var(--space-md); background: rgba(16, 185, 129, 0.1); border-left: 4px solid #10b981; border-radius: var(--radius-md);">
            <strong style="color: #059669;">✓ <?php echo $rooms->num_rows; ?> rooms available</strong> matching your criteria
        </div>

        <!-- Room Grid -->
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: var(--space-2xl);">
            <?php while ($room = $rooms->fetch_assoc()):
                // Define block-specific styles
                $block_styles = [
                    'A' => [
                        'gradient' => 'linear-gradient(135deg, #6366f1 0%, #4f46e5 100%)',
                        'icon' => '👑',
                        'label' => 'Premium'
                    ],
                    'B' => [
                        'gradient' => 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
                        'icon' => '⭐',
                        'label' => 'Standard'
                    ],
                    'C' => [
                        'gradient' => 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                        'icon' => '💎',
                        'label' => 'Budget'
                    ],
                    'D' => [
                        'gradient' => 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
                        'icon' => '🎯',
                        'label' => 'Economy'
                    ]
                ];

                $style = $block_styles[$room['block']] ?? $block_styles['A'];
            ?>
                <div class="card room-card" style="box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
                    <!-- Card Header with Gradient -->
                    <div class="room-card-header" style="background: <?php echo $style['gradient']; ?>;">
                        <div class="price-tag">₹<?php echo number_format($room['fees']); ?></div>

                        <div class="room-icon"><?php echo $style['icon']; ?></div>

                        <h3 style="margin: 0; font-size: var(--text-2xl); font-weight: var(--font-bold);">
                            Room <?php echo $room['block'] . '-' . $room['room_number']; ?>
                        </h3>

                        <div style="margin-top: var(--space-sm); display: flex; gap: var(--space-xs); flex-wrap: wrap; justify-content: center;">
                            <span class="room-badge">
                                <?php echo $style['label']; ?>
                            </span>
                            <span class="room-badge">
                                Floor <?php echo $room['floor']; ?>
                            </span>
                        </div>
                    </div>

                    <!-- Card Body -->
                    <div class="card-body" style="flex: 1; display: flex; flex-direction: column; padding: var(--space-xl);">
                        <!-- Room Info -->
                        <div style="margin-bottom: var(--space-lg);">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--space-md); padding-bottom: var(--space-md); border-bottom: 2px dashed var(--color-gray-200);">
                                <span style="color: var(--color-gray-600); font-weight: 500;">Room Type:</span>
                                <strong style="font-size: var(--text-lg); color: var(--color-primary);">
                                    <?php echo $room['room_type']; ?>
                                </strong>
                            </div>

                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--space-md); padding-bottom: var(--space-md); border-bottom: 2px dashed var(--color-gray-200);">
                                <span style="color: var(--color-gray-600); font-weight: 500;">Capacity:</span>
                                <strong style="font-size: var(--text-lg);">
                                    <?php echo $room['capacity']; ?> Person<?php echo $room['capacity'] > 1 ? 's' : ''; ?>
                                </strong>
                            </div>

                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <span style="color: var(--color-gray-600); font-weight: 500;">Available Seats:</span>
                                <strong style="font-size: var(--text-lg); color: #10b981;">
                                    <?php
                                    $available_seats = $room['capacity'] - ($room['occupied'] + $room['pending_count']);
                                    echo max(0, $available_seats);
                                    ?> / <?php echo $room['capacity']; ?>
                                </strong>
                            </div>
                        </div>

                        <!-- Amenities -->
                        <?php if (!empty($room['amenities'])): ?>
                            <div style="margin-bottom: var(--space-lg);">
                                <div style="font-weight: var(--font-semibold); margin-bottom: var(--space-sm); color: var(--color-gray-700);">
                                    ✨ Amenities:
                                </div>
                                <div style="display: flex; flex-wrap: wrap; gap: 4px;">
                                    <?php
                                    $amenities = explode(',', $room['amenities']);
                                    foreach ($amenities as $amenity):
                                    ?>
                                        <span class="amenity-badge"><?php echo trim($amenity); ?></span>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <!-- Action Buttons -->
                        <div style="display: flex; gap: var(--space-md); margin-top: auto;">
                            <a href="book_room_action.php?room_id=<?php echo $room['id']; ?>"
                                class="btn btn-primary"
                                style="flex: 1; text-align: center;"
                                onclick="return confirm('Are you sure you want to book this room? You will need to complete payment within 7 days.')">
                                🏠 Book Now & Pay
                            </a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div style="padding: var(--space-3xl); text-align: center; color: var(--color-gray-500);">
            <div style="font-size: 5rem; margin-bottom: var(--space-lg);">🏠</div>
            <h3>No Available Rooms</h3>
            <p>Sorry, there are no rooms matching your criteria. Please try different filters.</p>
        </div>
    <?php endif; ?>

    <!-- Help Section -->
    <div style="margin-top: var(--space-3xl); padding: var(--space-2xl); background: linear-gradient(135deg, rgba(245, 158, 11, 0.1) 0%, rgba(217, 119, 6, 0.1) 100%); border-radius: var(--radius-xl); border-left: 4px solid #f59e0b;">
        <h3 style="margin-bottom: var(--space-md); color: #d97706; font-size: var(--text-2xl);">
            💡 Need Help Choosing?
        </h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: var(--space-lg);">
            <div>
                <strong style="color: #6366f1;">👑 Block A - Premium:</strong>
                <p style="margin: var(--space-xs) 0 0; color: var(--color-gray-700);">Single occupancy with AC. Perfect for students who value privacy and comfort.</p>
            </div>
            <div>
                <strong style="color: #3b82f6;">⭐ Block B - Standard:</strong>
                <p style="margin: var(--space-xs) 0 0; color: var(--color-gray-700);">Double sharing rooms. Great balance between cost and comfort.</p>
            </div>
            <div>
                <strong style="color: #10b981;">💎 Block C - Budget:</strong>
                <p style="margin: var(--space-xs) 0 0; color: var(--color-gray-700);">Triple sharing. Economical option with all basic amenities.</p>
            </div>
            <div>
                <strong style="color: #f59e0b;">🎯 Block D - Economy:</strong>
                <p style="margin: var(--space-xs) 0 0; color: var(--color-gray-700);">Dormitory style. Most affordable with a vibrant community feel.</p>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
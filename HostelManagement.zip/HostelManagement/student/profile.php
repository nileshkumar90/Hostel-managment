<?php
require_once '../includes/config.php';
requireStudentLogin();

$page_title = 'My Profile';
$student = getStudentById($_SESSION['student_id']);

if (!$student) {
    // Student record not found (deleted or invalid session)
    session_unset();
    session_destroy();
    header("Location: ../login.php?error=Session invalid. Please login again.");
    exit();
}

// Handle profile update
if (isset($_POST['update_profile'])) {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $guardian_name = sanitize($_POST['guardian_name']);
    $guardian_contact = sanitize($_POST['guardian_contact']);
    $emergency_contact = sanitize($_POST['emergency_contact']);
    $blood_group = sanitize($_POST['blood_group']);

    $sql = "UPDATE students SET name=?, email=?, phone=?, guardian_name=?, guardian_contact=?, emergency_contact=?, blood_group=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssi", $name, $email, $phone, $guardian_name, $guardian_contact, $emergency_contact, $blood_group, $_SESSION['student_id']);

    if ($stmt->execute()) {
        $success = "Profile updated successfully!";
        $student = getStudentById($_SESSION['student_id']); // Refresh data
    } else {
        $error = "Error updating profile: " . $conn->error;
    }
}

// Handle password change
if (isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if (password_verify($current_password, $student['password'])) {
        if ($new_password === $confirm_password) {
            if (strlen($new_password) >= 6) {
                $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                $conn->query("UPDATE students SET password='$hashed' WHERE id=" . $_SESSION['student_id']);
                $success = "Password changed successfully!";
            } else {
                $error = "New password must be at least 6 characters!";
            }
        } else {
            $error = "New passwords do not match!";
        }
    } else {
        $error = "Current password is incorrect!";
    }
}

// Get room information
$room = null;
if ($student['room_id']) {
    $room = $conn->query("SELECT * FROM rooms WHERE id = " . $student['room_id'])->fetch_assoc();
}

include '../includes/header.php';
include '../includes/student-nav.php';
?>

<div class="container-fluid" style="padding: var(--space-2xl);">
    <div style="margin-bottom: var(--space-2xl);">
        <h1 style="font-size: var(--text-4xl); font-weight: var(--font-extrabold); margin-bottom: var(--space-sm);">
            My Profile
        </h1>
        <p style="color: var(--color-gray-600);">Manage your personal information</p>
    </div>

    <?php if (isset($success)): ?>
        <div class="alert alert-success" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✓</span>
            <div class="alert-content"><?php echo $success; ?></div>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="alert alert-error" style="margin-bottom: var(--space-lg);">
            <span class="alert-icon">✕</span>
            <div class="alert-content"><?php echo $error; ?></div>
        </div>
    <?php endif; ?>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-2xl);">
        <!-- Profile Information -->
        <div>
            <div class="card" style="margin-bottom: var(--space-2xl);">
                <div class="card-header">
                    <h2 class="card-title">👤 Personal Information</h2>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="form-group">
                            <label class="form-label required">Full Name</label>
                            <input type="text" name="name" class="form-input" value="<?php echo htmlspecialchars($student['name']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label required">Email</label>
                            <input type="email" name="email" class="form-input" value="<?php echo htmlspecialchars($student['email']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label required">Phone</label>
                            <input type="tel" name="phone" class="form-input" value="<?php echo htmlspecialchars($student['phone']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Blood Group</label>
                            <select name="blood_group" class="form-select">
                                <option value="">Select Blood Group</option>
                                <?php
                                $blood_groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
                                foreach ($blood_groups as $bg):
                                ?>
                                    <option value="<?php echo $bg; ?>" <?php echo ($student['blood_group'] == $bg) ? 'selected' : ''; ?>>
                                        <?php echo $bg; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Guardian Name</label>
                            <input type="text" name="guardian_name" class="form-input" value="<?php echo htmlspecialchars($student['guardian_name'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Guardian Contact</label>
                            <input type="tel" name="guardian_contact" class="form-input" value="<?php echo htmlspecialchars($student['guardian_contact'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Emergency Contact</label>
                            <input type="tel" name="emergency_contact" class="form-input" value="<?php echo htmlspecialchars($student['emergency_contact'] ?? ''); ?>">
                        </div>

                        <button type="submit" name="update_profile" class="btn btn-primary">
                            💾 Update Profile
                        </button>
                    </form>
                </div>
            </div>

            <!-- Change Password -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">🔒 Change Password</h2>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="form-group">
                            <label class="form-label required">Current Password</label>
                            <input type="password" name="current_password" class="form-input" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label required">New Password</label>
                            <input type="password" name="new_password" class="form-input" placeholder="At least 6 characters" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label required">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-input" required>
                        </div>

                        <button type="submit" name="change_password" class="btn btn-primary">
                            🔑 Change Password
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Profile Summary & Room Info -->
        <div>
            <!-- Profile Summary -->
            <div class="card" style="margin-bottom: var(--space-2xl);">
                <div class="card-header">
                    <h2 class="card-title">📋 Profile Summary</h2>
                </div>
                <div class="card-body">
                    <div style="display: grid; gap: var(--space-lg);">
                        <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                            <span style="color: var(--color-gray-600);">Roll Number:</span>
                            <strong><?php echo htmlspecialchars($student['roll_number']); ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                            <span style="color: var(--color-gray-600);">Gender:</span>
                            <strong><?php echo htmlspecialchars($student['gender'] ?? 'Not specified'); ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                            <span style="color: var(--color-gray-600);">Date of Birth:</span>
                            <strong><?php echo isset($student['dob']) ? formatDate($student['dob']) : 'Not specified'; ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                            <span style="color: var(--color-gray-600);">Branch:</span>
                            <strong><?php echo htmlspecialchars($student['branch'] ?? 'Not specified'); ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                            <span style="color: var(--color-gray-600);">Year:</span>
                            <strong><?php echo $student['year']; ?><?php echo match ($student['year']) {
                                                                        1 => 'st',
                                                                        2 => 'nd',
                                                                        3 => 'rd',
                                                                        default => 'th'
                                                                    }; ?> Year</strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                            <span style="color: var(--color-gray-600);">Joined:</span>
                            <strong><?php echo isset($student['registration_date']) ? formatDate($student['registration_date']) : 'Not available'; ?></strong>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span style="color: var(--color-gray-600);">Status:</span>
                            <?php echo isset($student['is_active']) && $student['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-warning">Inactive</span>'; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Room Information -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">🏠 Room Information</h2>
                </div>
                <div class="card-body">
                    <?php if ($room): ?>
                        <div style="display: grid; gap: var(--space-lg);">
                            <div style="text-align: center; padding: var(--space-xl); background: var(--gradient-primary); border-radius: var(--radius-xl); color: white;">
                                <div style="font-size: var(--text-sm); opacity: 0.9; margin-bottom: var(--space-xs);">Your Room</div>
                                <div style="font-size: var(--text-4xl); font-weight: var(--font-extrabold);">
                                    <?php echo $room['block'] . '-' . $room['room_number']; ?>
                                </div>
                            </div>

                            <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                                <span style="color: var(--color-gray-600);">Block:</span>
                                <strong><?php echo $room['block']; ?></strong>
                            </div>
                            <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                                <span style="color: var(--color-gray-600);">Floor:</span>
                                <strong><?php echo $room['floor']; ?></strong>
                            </div>
                            <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                                <span style="color: var(--color-gray-600);">Room Type:</span>
                                <strong><?php echo $room['room_type']; ?></strong>
                            </div>
                            <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                                <span style="color: var(--color-gray-600);">Capacity:</span>
                                <strong><?php echo $room['capacity']; ?> person(s)</strong>
                            </div>
                            <div style="display: flex; justify-content: space-between; padding-bottom: var(--space-md); border-bottom: 1px solid var(--color-gray-200);">
                                <span style="color: var(--color-gray-600);">Monthly Fees:</span>
                                <strong>₹<?php echo number_format($room['fees'], 2); ?></strong>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <span style="color: var(--color-gray-600);">Facilities:</span>
                                <strong style="text-align: right; max-width: 60%;"><?php echo htmlspecialchars($room['facilities'] ?? 'N/A'); ?></strong>
                            </div>
                        </div>
                    <?php else: ?>
                        <div style="padding: var(--space-3xl); text-align: center; color: var(--color-gray-500);">
                            <div style="font-size: 4rem; margin-bottom: var(--space-lg);">🏠</div>
                            <h3>No Room Assigned</h3>
                            <p>You haven't been assigned a room yet. Please contact the admin.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
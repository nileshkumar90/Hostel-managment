<?php
require_once "../includes/config.php";

// Step 1: Ensure student is logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
    exit();
}

// Step 2: Get fee ID from query parameter
if (isset($_GET['id'])) {
    $fee_id = intval($_GET['id']);   // sanitize input
    $student_id = $_SESSION['student_id'];

    // Step 3: Update fee status for this student
    $stmt = $conn->prepare("UPDATE fees SET status = 'Paid' WHERE id = ? AND student_id = ?");
    $stmt->bind_param("ii", $fee_id, $student_id);

    if ($stmt->execute() && $stmt->affected_rows > 0) {
        echo "✅ Payment Successful! <a href='dashboard.php'>Back to Dashboard</a>";
    } else {
        echo "⚠️ Payment update failed. Either the fee record doesn’t exist or it’s already paid.";
    }

    $stmt->close();
} else {
    echo "❌ Invalid request. No fee selected.";
}

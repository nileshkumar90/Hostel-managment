<!-- footer.php -->
<div class="bottom-strip">
</div>

<style>
.bottom-strip {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  background: #004b8d;
  padding: 12px 20px;
  display: none;
}

.back-btn {
  background: #ffffff;
  color: #004b8d;
  border: none;
  border-radius: 6px;
  padding: 8px 16px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  transition: 0.3s;
}

.back-btn:hover {
  background: #e0e0e0;
}
</style>

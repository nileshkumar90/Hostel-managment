<?php
require_once 'includes/config.php';

$page_title = 'Student Registration - Hostel Management System';
$success = false;
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect and sanitize input
    $name = sanitize($_POST['name']);
    $roll_number = sanitize($_POST['roll_number']);
    $phone = sanitize($_POST['phone']);
    $branch = sanitize($_POST['branch']);
    $email = sanitize($_POST['email']);
    $father_name = sanitize($_POST['father_name']);
    $aadhaar_no = sanitize($_POST['aadhaar_no']);
    $apar_id = sanitize($_POST['apar_id']);
    $mother_name = sanitize($_POST['mother_name']);
    $parents_phone = sanitize($_POST['parents_phone']);
    $address = sanitize($_POST['address']);
    $local_guardian_name = isset($_POST['local_guardian_name']) && !empty($_POST['local_guardian_name']) ? sanitize($_POST['local_guardian_name']) : NULL;
    $local_guardian_phone = isset($_POST['local_guardian_phone']) && !empty($_POST['local_guardian_phone']) ? sanitize($_POST['local_guardian_phone']) : NULL;
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Simple validation
    if ($password !== $confirm_password) {
        $error = "Passwords do not match";
    } else if (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Handle image upload
        $profile_image = NULL;
        if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
            $upload_dir = 'uploads/students/';

            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $file_extension = strtolower(pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION));
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];

            if (in_array($file_extension, $allowed_extensions)) {
                if ($_FILES['profile_image']['size'] <= 2097152) {
                    $new_filename = uniqid('student_') . '.' . $file_extension;
                    $upload_path = $upload_dir . $new_filename;

                    if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_path)) {
                        $profile_image = $upload_path;
                    }
                } else {
                    $error = "Profile image must be less than 2MB";
                }
            } else {
                $error = "Only JPG, JPEG, PNG, and GIF files are allowed";
            }
        }

        if (empty($error)) {
            // Check if email or roll number already exists
            $check = $conn->prepare("SELECT id FROM students WHERE email = ? OR roll_number = ?");
            $check->bind_param("ss", $email, $roll_number);
            $check->execute();
            $check->store_result();

            if ($check->num_rows > 0) {
                $error = "Email or Roll Number already registered";
            } else {
                // Insert new student
                $sql = "INSERT INTO students 
                (name, roll_number, phone, branch, email, father_name, aadhaar_no, apar_id, mother_name, parents_phone, address, guardian_name, guardian_contact, password, profile_image)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                $stmt = $conn->prepare($sql);
                $stmt->bind_param(
                    "sssssssssssssss",
                    $name,
                    $roll_number,
                    $phone,
                    $branch,
                    $email,
                    $father_name,
                    $aadhaar_no,
                    $apar_id,
                    $mother_name,
                    $parents_phone,
                    $address,
                    $local_guardian_name,
                    $local_guardian_phone,
                    $hashed_password,
                    $profile_image
                );

                if ($stmt->execute()) {
                    $success = true;
                } else {
                    $error = "Registration failed: " . $stmt->error;
                }
                $stmt->close();
            }
            $check->close();
        }
    }
}

include 'includes/header.php';
?>

<style>
    body {
        background: var(--gradient-hero);
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: var(--space-2xl) var(--space-md);
    }

    .register-container {
        max-width: 900px;
        width: 100%;
    }

    .register-card {
        background: var(--color-white);
        border-radius: var(--radius-2xl);
        box-shadow: var(--shadow-2xl);
        overflow: hidden;
        animation: scaleIn var(--transition-base) ease-out;
    }

    .register-header {
        background: var(--gradient-primary);
        color: var(--color-white);
        padding: var(--space-2xl);
        text-align: center;
        position: relative;
        overflow: hidden;
    }

    .register-header::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
        animation: pulse 3s ease-in-out infinite;
    }

    .register-title {
        font-size: var(--text-4xl);
        font-weight: var(--font-extrabold);
        margin-bottom: var(--space-sm);
        position: relative;
        z-index: 1;
    }

    .register-subtitle {
        font-size: var(--text-lg);
        opacity: 0.95;
        position: relative;
        z-index: 1;
    }

    .register-body {
        padding: var(--space-3xl);
    }

    .back-link {
        display: inline-flex;
        align-items: center;
        gap: var(--space-xs);
        color: var(--color-white);
        text-decoration: none;
        margin-bottom: var(--space-xl);
        font-weight: var(--font-medium);
        transition: gap var(--transition-fast);
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }

    .back-link:hover {
        gap: var(--space-sm);
        color: var(--color-white);
    }

    .step-progress {
        display: flex;
        justify-content: space-between;
        margin-bottom: var(--space-3xl);
        position: relative;
    }

    .step-progress::before {
        content: '';
        position: absolute;
        top: 20px;
        left: 0;
        right: 0;
        height: 3px;
        background: var(--color-gray-200);
        z-index: 0;
    }

    .step-progress-line {
        position: absolute;
        top: 20px;
        left: 0;
        height: 3px;
        background: var(--gradient-primary);
        transition: width var(--transition-slow);
        z-index: 1;
    }

    .step {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: var(--space-sm);
        position: relative;
        z-index: 2;
        flex: 1;
    }

    .step-number {
        width: 40px;
        height: 40px;
        border-radius: var(--radius-full);
        background: var(--color-white);
        border: 3px solid var(--color-gray-300);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: var(--font-bold);
        color: var(--color-gray-500);
        transition: all var(--transition-base);
    }

    .step.active .step-number {
        border-color: var(--color-primary);
        color: var(--color-primary);
        background: var(--color-primary-lighter);
        transform: scale(1.1);
        box-shadow: var(--shadow-glow);
    }

    .step.completed .step-number {
        background: var(--gradient-primary);
        border-color: var(--color-primary);
        color: var(--color-white);
    }

    .step-label {
        font-size: var(--text-sm);
        font-weight: var(--font-medium);
        color: var(--color-gray-600);
        text-align: center;
    }

    .step.active .step-label {
        color: var(--color-primary);
        font-weight: var(--font-semibold);
    }

    .form-step {
        display: none;
        animation: fadeInUp var(--transition-base) ease-out;
    }

    .form-step.active {
        display: block;
    }

    .form-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: var(--space-lg);
    }

    .form-grid-full {
        grid-column: 1 / -1;
    }

    .profile-upload {
        text-align: center;
        margin-bottom: var(--space-2xl);
    }

    .profile-preview {
        width: 150px;
        height: 150px;
        border-radius: var(--radius-full);
        border: 4px solid var(--color-primary);
        margin: 0 auto var(--space-lg);
        overflow: hidden;
        background: var(--color-gray-100);
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        box-shadow: var(--shadow-lg);
        transition: all var(--transition-base);
    }

    .profile-preview:hover {
        transform: scale(1.05);
        box-shadow: var(--shadow-xl), var(--shadow-glow);
    }

    .profile-preview img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .profile-placeholder {
        font-size: 4rem;
        color: var(--color-gray-400);
    }

    .upload-btn {
        display: inline-flex;
        align-items: center;
        gap: var(--space-sm);
        padding: var(--space-md) var(--space-xl);
        background: var(--gradient-primary);
        color: var(--color-white);
        border-radius: var(--radius-lg);
        cursor: pointer;
        font-weight: var(--font-semibold);
        transition: all var(--transition-base);
        box-shadow: var(--shadow-md);
    }

    .upload-btn:hover {
        box-shadow: var(--shadow-lg), var(--shadow-glow);
        transform: translateY(-2px);
    }

    #profileImage {
        display: none;
    }

    .upload-hint {
        font-size: var(--text-sm);
        color: var(--color-gray-600);
        margin-top: var(--space-sm);
    }

    .form-navigation {
        display: flex;
        gap: var(--space-md);
        margin-top: var(--space-2xl);
        justify-content: space-between;
    }

    .btn-prev {
        background: var(--color-white);
        color: var(--color-primary);
        border: 2px solid var(--color-primary);
    }

    .btn-prev:hover {
        background: var(--color-gray-50);
    }

    .success-message {
        text-align: center;
        padding: var(--space-3xl);
        animation: scaleIn var(--transition-base) ease-out;
    }

    .success-icon {
        width: 100px;
        height: 100px;
        border-radius: var(--radius-full);
        background: var(--gradient-success);
        color: var(--color-white);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 3rem;
        margin: 0 auto var(--space-xl);
        box-shadow: var(--shadow-2xl);
        animation: scaleIn 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    }

    .success-title {
        font-size: var(--text-3xl);
        font-weight: var(--font-extrabold);
        color: var(--color-gray-900);
        margin-bottom: var(--space-md);
    }

    .success-text {
        font-size: var(--text-lg);
        color: var(--color-gray-600);
        margin-bottom: var(--space-2xl);
    }

    .login-footer {
        text-align: center;
        margin-top: var(--space-2xl);
        padding-top: var(--space-2xl);
        border-top: 1px solid var(--color-gray-200);
    }

    .login-footer a {
        color: var(--color-primary);
        font-weight: var(--font-semibold);
        transition: color var(--transition-fast);
    }

    .login-footer a:hover {
        color: var(--color-primary-dark);
        text-decoration: underline;
    }

    .password-strength {
        height: 4px;
        border-radius: var(--radius-full);
        background: var(--color-gray-200);
        margin-top: var(--space-sm);
        overflow: hidden;
    }

    .password-strength-bar {
        height: 100%;
        width: 0%;
        transition: all var(--transition-base);
        border-radius: var(--radius-full);
    }

    .strength-weak {
        background: var(--color-error);
        width: 33%;
    }

    .strength-medium {
        background: var(--color-warning);
        width: 66%;
    }

    .strength-strong {
        background: var(--color-success);
        width: 100%;
    }

    @media (max-width: 768px) {
        .form-grid {
            grid-template-columns: 1fr;
        }

        .register-title {
            font-size: var(--text-2xl);
        }

        .register-body {
            padding: var(--space-xl);
        }

        .step-label {
            font-size: var(--text-xs);
        }

        .step-number {
            width: 35px;
            height: 35px;
            font-size: var(--text-sm);
        }
    }
</style>

<div class="register-container">
    <a href="index.php" class="back-link">← Back to Home</a>

    <div class="register-card">
        <div class="register-header">
            <div class="logo-icon large" style="background: rgba(255,255,255,0.2); margin-bottom: 1rem;">S</div>
            <h1 class="register-title">Student Registration</h1>
            <p class="register-subtitle">Join our hostel community today</p>
        </div>

        <div class="register-body">
            <?php if ($success): ?>
                <div class="success-message">
                    <div class="success-icon">✓</div>
                    <h2 class="success-title">Registration Successful!</h2>
                    <p class="success-text">
                        Your account has been created successfully.<br>
                        You can now login with your credentials.
                    </p>
                    <a href="login.php" class="btn btn-primary">Go to Login</a>
                </div>
            <?php else: ?>
                <?php if ($error): ?>
                    <div class="alert alert-error" style="margin-bottom: 2rem;">
                        <strong>⚠️ Error:</strong>
                        <div style="margin-top: 0.5rem;"><?php echo htmlspecialchars($error); ?></div>
                    </div>
                <?php endif; ?>

                <div class="step-progress">
                    <div class="step-progress-line" id="progressLine"></div>
                    <div class="step active" data-step="1">
                        <div class="step-number">1</div>
                        <div class="step-label">Personal Info</div>
                    </div>
                    <div class="step" data-step="2">
                        <div class="step-number">2</div>
                        <div class="step-label">Family Details</div>
                    </div>
                    <div class="step" data-step="3">
                        <div class="step-number">3</div>
                        <div class="step-label">Account Setup</div>
                    </div>
                </div>

                <form method="POST" action="" enctype="multipart/form-data" id="registrationForm">
                    <div class="form-step active" data-step="1">
                        <div class="profile-upload">
                            <div class="profile-preview" id="profilePreview">
                                <span class="profile-placeholder">📷</span>
                            </div>
                            <label for="profileImage" class="upload-btn">
                                📤 Upload Photo
                            </label>
                            <input type="file" id="profileImage" name="profile_image" accept="image/*">
                            <p class="upload-hint">JPG, PNG or GIF (Max 2MB)</p>
                        </div>

                        <div class="form-grid">
                            <div class="form-group form-grid-full">
                                <label class="form-label">Full Name <span class="required">*</span></label>
                                <input type="text" name="name" class="form-input" placeholder="Enter your full name" required>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Roll Number <span class="required">*</span></label>
                                <input type="text" name="roll_number" class="form-input" placeholder="Enter roll number" required>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Email Address <span class="required">*</span></label>
                                <input type="email" name="email" class="form-input" placeholder="your.email@example.com" required>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Phone Number <span class="required">*</span></label>
                                <input type="tel" name="phone" class="form-input" placeholder="Enter phone number" required>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Branch/Department <span class="required">*</span></label>
                                <input type="text" name="branch" class="form-input" placeholder="e.g., Computer Science" required>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Aadhaar Number <span class="required">*</span></label>
                                <input type="text" name="aadhaar_no" class="form-input" placeholder="Enter Aadhaar number" required>
                            </div>

                            <div class="form-group">
                                <label class="form-label">APAR ID <span class="required">*</span></label>
                                <input type="text" name="apar_id" class="form-input" placeholder="Enter APAR ID" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-step" data-step="2">
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Father's Name <span class="required">*</span></label>
                                <input type="text" name="father_name" class="form-input" placeholder="Enter father's name" required>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Mother's Name <span class="required">*</span></label>
                                <input type="text" name="mother_name" class="form-input" placeholder="Enter mother's name" required>
                            </div>

                            <div class="form-group form-grid-full">
                                <label class="form-label">Parents' Phone Number <span class="required">*</span></label>
                                <input type="tel" name="parents_phone" class="form-input" placeholder="Enter parents' phone number" required>
                            </div>

                            <div class="form-group form-grid-full">
                                <label class="form-label">Address <span class="required">*</span></label>
                                <textarea name="address" class="form-input" rows="3" placeholder="Enter complete address" required></textarea>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Local Guardian Name</label>
                                <input type="text" name="local_guardian_name" class="form-input" placeholder="Enter local guardian name (Optional)">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Local Guardian Phone</label>
                                <input type="tel" name="local_guardian_phone" class="form-input" placeholder="Enter phone number (Optional)">
                            </div>
                        </div>
                    </div>

                    <div class="form-step" data-step="3">
                        <div class="alert alert-info">
                            <strong>ℹ️ Almost Done!</strong><br>
                            Please review your information and create a secure password to complete your registration.
                        </div>

                        <div class="form-grid">
                            <div class="form-group form-grid-full">
                                <label class="form-label">Password <span class="required">*</span></label>
                                <input type="password" name="password" id="password" class="form-input" placeholder="Create a strong password" required>
                                <div class="password-strength">
                                    <div class="password-strength-bar" id="strengthBar"></div>
                                </div>
                                <small class="form-hint">Use at least 6 characters with a mix of letters and numbers</small>
                            </div>

                            <div class="form-group form-grid-full">
                                <label class="form-label">Confirm Password <span class="required">*</span></label>
                                <input type="password" name="confirm_password" id="confirmPassword" class="form-input" placeholder="Re-enter your password" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-navigation">
                        <button type="button" class="btn btn-prev" id="prevBtn" style="display: none;">← Previous</button>
                        <button type="button" class="btn btn-primary" id="nextBtn">Next →</button>
                        <button type="submit" class="btn btn-success" id="submitBtn" style="display: none;">Complete Registration ✓</button>
                    </div>
                </form>

                <div class="login-footer">
                    <p>Already have an account? <a href="login.php">Login here</a></p>
                    <p style="margin-top: 0.5rem; font-size: 0.9em;">Are you an administrator? <a href="admin/index.php">Admin Login</a></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    let currentStep = 1;
    const totalSteps = 3;

    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const submitBtn = document.getElementById('submitBtn');
    const progressLine = document.getElementById('progressLine');

    const profileImage = document.getElementById('profileImage');
    const profilePreview = document.getElementById('profilePreview');

    profileImage.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                profilePreview.innerHTML = `<img src="${e.target.result}" alt="Profile Preview">`;
            };
            reader.readAsDataURL(file);
        }
    });

    const password = document.getElementById('password');
    const strengthBar = document.getElementById('strengthBar');

    password.addEventListener('input', function() {
        const value = this.value;
        const length = value.length;

        strengthBar.className = 'password-strength-bar';

        if (length === 0) {
            strengthBar.style.width = '0%';
        } else if (length < 6) {
            strengthBar.classList.add('strength-weak');
        } else if (length < 10) {
            strengthBar.classList.add('strength-medium');
        } else {
            strengthBar.classList.add('strength-strong');
        }
    });

    function showStep(step) {
        document.querySelectorAll('.form-step').forEach(el => el.classList.remove('active'));
        document.querySelector(`.form-step[data-step="${step}"]`).classList.add('active');

        document.querySelectorAll('.step').forEach((el, index) => {
            el.classList.remove('active', 'completed');
            if (index + 1 < step) el.classList.add('completed');
            if (index + 1 === step) el.classList.add('active');
        });

        const progress = ((step - 1) / (totalSteps - 1)) * 100;
        progressLine.style.width = progress + '%';

        prevBtn.style.display = step === 1 ? 'none' : 'inline-flex';
        nextBtn.style.display = step === totalSteps ? 'none' : 'inline-flex';
        submitBtn.style.display = step === totalSteps ? 'inline-flex' : 'none';
    }

    nextBtn.addEventListener('click', () => {
        const currentStepEl = document.querySelector(`.form-step[data-step="${currentStep}"]`);
        const inputs = currentStepEl.querySelectorAll('input[required], select[required], textarea[required]');
        let isValid = true;

        inputs.forEach(input => {
            if (!input.value.trim()) {
                isValid = false;
                input.style.borderColor = 'var(--color-error)';

                input.addEventListener('input', function() {
                    this.style.borderColor = '';
                }, {
                    once: true
                });
            }
        });

        if (isValid) {
            if (currentStep < totalSteps) {
                currentStep++;
                showStep(currentStep);
            }
        } else {
            alert('Please fill in all required fields.');
        }
    });

    prevBtn.addEventListener('click', () => {
        if (currentStep > 1) {
            currentStep--;
            showStep(currentStep);
        }
    });

    showStep(currentStep);
</script>

<?php include 'includes/footer.php'; ?>
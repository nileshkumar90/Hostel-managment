<?php
require_once 'includes/config.php';

echo "<h1>Admin Account Reset Tool</h1>";

$username = 'admin';
$password = 'student123';
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Check if admin exists
$check = $conn->prepare("SELECT id FROM admin WHERE username = ?");
$check->bind_param("s", $username);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    // Update existing admin
    $update = $conn->prepare("UPDATE admin SET password = ? WHERE username = ?");
    $update->bind_param("ss", $hashed_password, $username);
    if ($update->execute()) {
        echo "<div style='color: green; padding: 20px; border: 1px solid green; background: #e6fffa;'>
            ✅ Admin password updated successfully!<br>
            <strong>Username:</strong> admin<br>
            <strong>Password:</strong> student123
        </div>";
    } else {
        echo "<div style='color: red;'>❌ Failed to update password: " . $conn->error . "</div>";
    }
} else {
    // Create new admin
    $insert = $conn->prepare("INSERT INTO admin (username, password, email) VALUES (?, ?, 'admin@hostel.com')");
    $insert->bind_param("ss", $username, $hashed_password);
    if ($insert->execute()) {
        echo "<div style='color: green; padding: 20px; border: 1px solid green; background: #e6fffa;'>
            ✅ Admin account created successfully!<br>
            <strong>Username:</strong> admin<br>
            <strong>Password:</strong> student123
        </div>";
    } else {
        echo "<div style='color: red;'>❌ Failed to create admin: " . $conn->error . "</div>";
    }
}

echo "<br><a href='admin-login.php' style='padding: 10px 20px; background: blue; color: white; text-decoration: none; border-radius: 5px;'>Go to Admin Login</a>";
